/**
 * Shared API client for the FocusGuard frontend.
 *
 * Keeps the base URL and token handling in one place so pages do not each
 * invent their own storage key and drift apart.
 */
const API_BASE = "http://127.0.0.1:8000";
const TOKEN_KEY = "focusguard_token";
const USER_KEY = "focusguard_user";

const auth = {
  get token() {
    // sessionStorage first: an un-remembered sign-in should win over a stale
    // remembered one left behind in localStorage.
    return sessionStorage.getItem(TOKEN_KEY) || localStorage.getItem(TOKEN_KEY);
  },
  get user() {
    const raw =
      sessionStorage.getItem(USER_KEY) || localStorage.getItem(USER_KEY);
    try {
      return JSON.parse(raw || "null");
    } catch {
      return null;
    }
  },
  /** `remember` picks localStorage (persists) over sessionStorage (tab-only). */
  save(token, user, remember = true) {
    this.clear();
    const store = remember ? localStorage : sessionStorage;
    store.setItem(TOKEN_KEY, token);
    store.setItem(USER_KEY, JSON.stringify(user ?? null));
  },
  clear() {
    for (const store of [localStorage, sessionStorage]) {
      store.removeItem(TOKEN_KEY);
      store.removeItem(USER_KEY);
    }
  },
};

/** Fetch wrapper that attaches the bearer token and unwraps API errors. */
async function apiGet(path) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: auth.token ? { Authorization: `Bearer ${auth.token}` } : {},
  });

  if (res.status === 401) {
    auth.clear();
    throw new Error("Your session expired. Please sign in again.");
  }
  if (!res.ok) {
    // FastAPI puts the human-readable reason in `detail`.
    let detail = `Request failed (HTTP ${res.status})`;
    try {
      const body = await res.json();
      if (body.detail) detail = body.detail;
    } catch {
      /* non-JSON error body; keep the status message */
    }
    throw new Error(detail);
  }
  return res.json();
}

async function apiPost(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(auth.token ? { Authorization: `Bearer ${auth.token}` } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Request failed (HTTP ${res.status})`);
  return res.json();
}

/** Seconds -> "2h 15m" / "45m". */
function formatDuration(seconds) {
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes}m`;
  return `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
}

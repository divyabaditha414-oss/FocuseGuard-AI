"""End-to-end smoke test for the Weeks 1-2 API.

Exercises every module built so far against a running server:
registration -> login -> profile -> goals -> focus session -> activity
ingestion -> notifications -> aggregates -> device rollup.

Run (server must be up):  python backend/scripts/smoke_test.py
"""
from __future__ import annotations

import sys
import uuid
from datetime import datetime, timedelta

import httpx

BASE = "http://127.0.0.1:8000"
failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    status = "PASS" if condition else "FAIL"
    print(f"  [{status}] {name}{(' -> ' + detail) if detail else ''}")
    if not condition:
        failures.append(name)


def main() -> None:
    client = httpx.Client(base_url=BASE, timeout=30)
    suffix = uuid.uuid4().hex[:8]

    print("\n1. Health")
    r = client.get("/health")
    check("GET /health", r.status_code == 200 and r.json()["status"] == "healthy")

    print("\n2. Registration + login")
    reg = {
        "username": f"smoke_{suffix}",
        "first_name": "Smoke",
        "last_name": "Test",
        "email": f"smoke_{suffix}@focusguard.com",
        "user_type": "Professional",
        "password": "SmokeTest@123",
    }
    r = client.post("/auth/register", json=reg)
    check("POST /auth/register", r.status_code == 201, f"HTTP {r.status_code} {r.text[:120]}")
    if r.status_code != 201:
        sys.exit("Cannot continue without a registered user.")

    check("register returns user_type", r.json()["user"]["user_type"] == "Professional")

    r = client.post("/auth/register", json=reg)
    check("duplicate register rejected", r.status_code == 409)

    # Login by username, then by email — both paths must work.
    r = client.post("/auth/login", json={"identifier": reg["username"], "password": reg["password"]})
    check("POST /auth/login (username)", r.status_code == 200, f"HTTP {r.status_code}")
    token = r.json()["access_token"]

    r = client.post("/auth/login", json={"identifier": reg["email"], "password": reg["password"]})
    check("POST /auth/login (email)", r.status_code == 200)

    r = client.post("/auth/login", json={"identifier": reg["email"], "password": "wrong-password"})
    check("bad password rejected", r.status_code == 401)

    auth = {"Authorization": f"Bearer {token}"}
    r = client.get("/auth/me", headers=auth)
    check("GET /auth/me", r.status_code == 200 and r.json()["username"] == reg["username"])

    r = client.get("/auth/me")
    check("unauthenticated request rejected", r.status_code == 401)

    print("\n3. Profile management")
    r = client.get("/users/me/profile", headers=auth)
    check("GET /users/me/profile", r.status_code == 200)

    r = client.put(
        "/users/me/profile",
        headers=auth,
        json={"occupation": "Data Engineer", "work_start_hour": 9, "work_end_hour": 18},
    )
    check("PUT /users/me/profile", r.status_code == 200 and r.json()["occupation"] == "Data Engineer")

    r = client.put("/users/me/profile", headers=auth, json={"work_start_hour": 20, "work_end_hour": 8})
    check("invalid work window rejected", r.status_code == 422)

    print("\n4. Goal configuration")
    r = client.post(
        "/goals",
        headers=auth,
        json={
            "title": "Daily deep work",
            "goal_type": "focus_minutes",
            "target_value": 180,
            "unit": "minutes",
            "period": "daily",
            "start_date": str(datetime.utcnow().date()),
        },
    )
    check("POST /goals", r.status_code == 201, f"HTTP {r.status_code} {r.text[:120]}")
    goal_id = r.json()["id"] if r.status_code == 201 else None

    r = client.get("/goals", headers=auth)
    check("GET /goals", r.status_code == 200 and len(r.json()) == 1)

    if goal_id:
        r = client.patch(f"/goals/{goal_id}", headers=auth, json={"status": "paused"})
        check("PATCH /goals/{id}", r.status_code == 200 and r.json()["status"] == "paused")

    print("\n5. Focus session recording")
    r = client.post("/sessions/start", headers=auth, json={"label": "Smoke block", "planned_minutes": 25})
    check("POST /sessions/start", r.status_code == 201, f"HTTP {r.status_code} {r.text[:120]}")
    session_id = r.json()["id"] if r.status_code == 201 else None

    r = client.post("/sessions/start", headers=auth, json={"planned_minutes": 25})
    check("overlapping session rejected", r.status_code == 409)

    print("\n6. Activity ingestion")
    now = datetime.utcnow().replace(microsecond=0)
    r = client.post(
        "/activity/logs",
        headers=auth,
        json={
            "app_name": "CodeChef",
            "opened_at": (now - timedelta(minutes=45)).isoformat(),
            "closed_at": (now - timedelta(minutes=5)).isoformat(),
            "tab_switch_count": 3,
            "device": "Desktop",
            "session_id": session_id,
        },
    )
    check("POST /activity/logs", r.status_code == 201, f"HTTP {r.status_code} {r.text[:120]}")
    if r.status_code == 201:
        body = r.json()
        check("duration derived server-side", body["duration_seconds"] == 2400, f"{body['duration_seconds']}s")
        check("productivity auto-classified", body["productivity"] == "Productive")
        check("url auto-filled from catalog", body["url"] == "codechef.com")

    r = client.post(
        "/activity/logs",
        headers=auth,
        json={
            "app_name": "Instagram",
            "opened_at": now.isoformat(),
            "closed_at": (now - timedelta(minutes=10)).isoformat(),
        },
    )
    check("closed_at before opened_at rejected", r.status_code == 422)

    bulk = [
        {
            "app_name": name,
            "opened_at": (now - timedelta(hours=h + 1)).isoformat(),
            "closed_at": (now - timedelta(hours=h, minutes=30)).isoformat(),
            "tab_switch_count": h * 2,
        }
        for h, name in enumerate(["Instagram", "YouTube", "GitHub", "Notion"])
    ]
    r = client.post("/activity/logs/bulk", headers=auth, json=bulk)
    check("POST /activity/logs/bulk", r.status_code == 201 and r.json()["inserted"] == 4)

    r = client.get("/activity/logs", headers=auth, params={"limit": 10})
    check("GET /activity/logs", r.status_code == 200 and r.json()["total"] == 5, f"total={r.json().get('total')}")

    r = client.get("/activity/logs", headers=auth, params={"productivity": "NonProductive"})
    check("filter by productivity", r.status_code == 200 and r.json()["total"] == 2, f"total={r.json().get('total')}")

    print("\n7. Notifications")
    r = client.post(
        "/notifications",
        headers=auth,
        json={"source_app": "WhatsApp Web", "received_at": now.isoformat(), "session_id": session_id},
    )
    check("POST /notifications", r.status_code == 201)

    r = client.get("/notifications/by-app", headers=auth)
    check("GET /notifications/by-app", r.status_code == 200 and len(r.json()) == 1)

    print("\n8. Aggregates")
    r = client.get("/activity/summary/daily", headers=auth, params={"days": 7})
    check("GET /activity/summary/daily", r.status_code == 200 and len(r.json()) >= 1)

    r = client.get("/activity/summary/top-apps", headers=auth, params={"days": 7})
    check("GET /activity/summary/top-apps", r.status_code == 200 and len(r.json()) == 5)

    r = client.post("/stats/rebuild", headers=auth)
    check("POST /stats/rebuild", r.status_code == 200 and r.json()["rows_written"] >= 1)

    r = client.get("/stats/devices", headers=auth)
    check("GET /stats/devices", r.status_code == 200 and len(r.json()) >= 1)

    r = client.get("/stats/overview", headers=auth)
    ok = r.status_code == 200 and r.json()["activity_count"] == 5
    check("GET /stats/overview", ok, f"{r.json()}" if r.status_code == 200 else "")

    print("\n9. Ending focus session")
    if session_id:
        r = client.post(
            f"/sessions/{session_id}/end",
            headers=auth,
            json={"interruption_count": 2, "tab_switch_count": 3},
        )
        check("POST /sessions/{id}/end", r.status_code == 200 and r.json()["ended_at"] is not None)

        r = client.post(f"/sessions/{session_id}/end", headers=auth, json={})
        check("double-end rejected", r.status_code == 409)

    print("\n10. Seeded demo data")
    r = client.post("/auth/login", json={"identifier": "user1", "password": "FocusGuard@123"})
    check("seeded user1 can log in", r.status_code == 200, f"HTTP {r.status_code}")
    if r.status_code == 200:
        seeded = {"Authorization": f"Bearer {r.json()['access_token']}"}
        r = client.get("/stats/overview", headers=seeded, params={"days": 60})
        ov = r.json()
        check("user1 has seeded activity", ov["activity_count"] > 100, f"{ov['activity_count']} rows")
        check(
            "user1 productive ratio is plausible",
            0.3 < ov["productive_ratio"] < 0.95,
            f"{ov['productive_ratio']:.1%}",
        )

    print("\n11. Weeks 3-4 analytics (seeded user with real history)")
    r = client.post("/auth/login", json={"identifier": "user1", "password": "FocusGuard@123"})
    if r.status_code != 200:
        check("analytics: seeded login", False, "cannot test analytics without user1")
    else:
        an = {"Authorization": f"Bearer {r.json()['access_token']}"}

        r = client.get("/analytics/features", headers=an, params={"days": 30})
        feats = r.json() if r.status_code == 200 else []
        check("GET /analytics/features", r.status_code == 200 and len(feats) > 20, f"{len(feats)} days")
        if feats:
            f = feats[-1]
            check(
                "features are internally consistent",
                f["productive_seconds"] + f["nonproductive_seconds"] == f["total_seconds"],
                f"{f['productive_seconds']}+{f['nonproductive_seconds']} vs {f['total_seconds']}",
            )

        r = client.get("/analytics/scores", headers=an, params={"days": 30})
        scores = r.json() if r.status_code == 200 else []
        check("GET /analytics/scores", r.status_code == 200 and len(scores) > 20, f"{len(scores)} days")
        if scores:
            in_range = all(
                0 <= s[k] <= 100
                for s in scores
                for k in ("focus_score", "productivity_score", "attention_stability_score")
            )
            check("all scores within 0-100", in_range)
            check(
                "score components present",
                set(scores[-1]["components"]) == {"focus", "productivity", "attention_stability"},
            )

        r = client.get("/analytics/trend", headers=an, params={"days": 30})
        check(
            "GET /analytics/trend",
            r.status_code == 200 and r.json()["direction"] in {"improving", "declining", "stable"},
            r.json().get("direction") if r.status_code == 200 else "",
        )

        r = client.get("/analytics/distraction", headers=an, params={"days": 30})
        d = r.json() if r.status_code == 200 else {}
        check(
            "GET /analytics/distraction",
            r.status_code == 200
            and {"frequent_interruptions", "context_switching", "notification_impact", "focus_loss"}
            <= set(d),
        )
        if d:
            fl = d["focus_loss"]
            check(
                "focus-loss split accounts for every event",
                fl["notification_triggered"] + fl["self_initiated"] == fl["focus_loss_events"],
                f"{fl['focus_loss_events']} events",
            )

        r = client.get("/analytics/attention-leaks", headers=an, params={"days": 30})
        leaks = r.json() if r.status_code == 200 else []
        check("GET /analytics/attention-leaks", r.status_code == 200, f"{len(leaks)} leaks")
        if len(leaks) > 1:
            check(
                "leaks ranked by leak_score",
                all(a["leak_score"] >= b["leak_score"] for a, b in zip(leaks, leaks[1:])),
            )

        r = client.get("/analytics/predictions", headers=an, params={"days": 30})
        preds = r.json() if r.status_code == 200 else []
        kinds = {p["kind"] for p in preds}
        check(
            "GET /analytics/predictions",
            r.status_code == 200
            and kinds == {"focus_degradation", "productivity_risk", "attention_fatigue"},
            ", ".join(f"{p['kind']}={p['label']}" for p in preds),
        )
        trained = [p for p in preds if p["kind"] != "attention_fatigue"]
        check(
            "predictions report their model source",
            all(p["model_version"] for p in trained),
            ", ".join(f"{p['kind']}:{p['model_version']}" for p in trained),
        )

        r = client.get("/analytics/insights", headers=an, params={"days": 30})
        ins = r.json() if r.status_code == 200 else []
        check("GET /analytics/insights", r.status_code == 200 and len(ins) >= 2, f"{len(ins)} insights")
        check("every insight carries evidence", all("evidence" in i for i in ins))
        check("insights end with a daily summary", bool(ins) and ins[-1]["kind"] == "summary")

        r = client.get("/analytics/dashboard", headers=an, params={"days": 30})
        check("GET /analytics/dashboard", r.status_code == 200, f"HTTP {r.status_code}")

        r = client.post("/analytics/compute", headers=an, params={"days": 30})
        written = r.json() if r.status_code == 200 else {}
        check(
            "POST /analytics/compute",
            r.status_code == 200 and written.get("scores_written", 0) > 20,
            str(written),
        )

        r = client.get("/analytics/stored/scores", headers=an, params={"days": 30})
        check("GET /analytics/stored/scores", r.status_code == 200 and len(r.json()) > 20)

        # Re-running must update in place, not duplicate rows.
        before = len(r.json())
        client.post("/analytics/compute", headers=an, params={"days": 30})
        after = len(client.get("/analytics/stored/scores", headers=an, params={"days": 30}).json())
        check("compute is idempotent", before == after, f"{before} -> {after}")

    print("\n12. Weeks 5-6 coaching platform")
    r = client.post("/auth/login", json={"identifier": "user1", "password": "FocusGuard@123"})
    if r.status_code != 200:
        check("coaching: seeded login", False)
    else:
        co = {"Authorization": f"Bearer {r.json()['access_token']}"}

        # --- Smart focus planner ---
        r = client.get("/coaching/plan", headers=co, params={"days": 30})
        plan = r.json() if r.status_code == 200 else {}
        check("GET /coaching/plan", r.status_code == 200, f"HTTP {r.status_code}")
        blocks = plan.get("blocks", [])
        check("plan produces focus blocks", any(b["kind"] == "focus" for b in blocks), f"{len(blocks)} blocks")
        if blocks:
            # Blocks are laid end to end; a gap or overlap means bad arithmetic.
            contiguous = all(a["end"] == b["start"] for a, b in zip(blocks, blocks[1:]))
            check("plan blocks are contiguous", contiguous)
            check(
                "focus and break blocks alternate",
                all(
                    a["kind"] != b["kind"]
                    for a, b in zip(blocks, blocks[1:])
                    if a["kind"] == "focus"
                ),
            )
            check(
                "total_focus_minutes matches the blocks",
                plan["total_focus_minutes"]
                == sum(b["minutes"] for b in blocks if b["kind"] == "focus"),
            )

        r = client.get("/coaching/high-focus-hours", headers=co, params={"days": 30})
        hours = r.json() if r.status_code == 200 else []
        check("GET /coaching/high-focus-hours", r.status_code == 200, f"{len(hours)} hours")
        if len(hours) > 1:
            check(
                "focus hours ranked by productive ratio",
                all(a["productive_ratio"] >= b["productive_ratio"] for a, b in zip(hours, hours[1:])),
            )

        # --- Recommendation engine ---
        r = client.get("/coaching/recommendations", headers=co, params={"days": 30})
        recos = r.json() if r.status_code == 200 else []
        check("GET /coaching/recommendations", r.status_code == 200 and len(recos) >= 2, f"{len(recos)} recos")
        if len(recos) > 1:
            check(
                "recommendations ranked by priority",
                all(a["priority"] >= b["priority"] for a, b in zip(recos, recos[1:])),
            )
        check("every recommendation cites evidence", all(r_["evidence"] for r_ in recos))
        check(
            "every recommendation has an action and rationale",
            all(r_["action"] and r_["rationale"] for r_ in recos),
        )
        check(
            "priority equals gain x confidence",
            all(
                abs(r_["priority"] - r_["expected_gain_minutes"] * r_["confidence"]) < 0.05
                for r_ in recos
            ),
        )

        r = client.get(
            "/coaching/recommendations", headers=co, params={"days": 30, "category": "attention_recovery"}
        )
        check(
            "recommendations filter by category",
            r.status_code == 200
            and all(x["category"] == "attention_recovery" for x in r.json()),
        )

        # --- Goal management ---
        r = client.get("/coaching/goals", headers=co, params={"days": 30})
        tracked = r.json() if r.status_code == 200 else []
        check("GET /coaching/goals", r.status_code == 200 and len(tracked) >= 1, f"{len(tracked)} goals")
        if tracked:
            g = tracked[0]
            check("days_met never exceeds days_tracked", g["days_met"] <= g["days_tracked"])
            check("current streak never exceeds longest", g["current_streak"] <= g["longest_streak"])
            check(
                "consistency matches days_met/days_tracked",
                abs(g["consistency"] - g["days_met"] / g["days_tracked"]) < 0.01,
            )
            check(
                "habit stage is a known value",
                g["habit_stage"] in {"inconsistent", "forming", "establishing", "established"},
                g["habit_stage"],
            )

        r = client.get("/coaching/goals/adjustments", headers=co, params={"days": 30})
        check("GET /coaching/goals/adjustments", r.status_code == 200)

        # --- Notification intelligence ---
        r = client.get("/coaching/alerts", headers=co, params={"days": 30})
        alerts = r.json() if r.status_code == 200 else []
        check("GET /coaching/alerts", r.status_code == 200, f"{len(alerts)} alerts")
        # The platform's own premise is that alert spam fragments attention.
        check("alerts are capped at 5/day", len(alerts) <= 5, f"{len(alerts)}")

        # --- Reporting ---
        r = client.get("/coaching/reports/weekly", headers=co, params={"days": 30})
        wr = r.json() if r.status_code == 200 else {}
        check("GET /coaching/reports/weekly", r.status_code == 200 and wr.get("available"), str(wr.get("reason", "")))
        if wr.get("available"):
            check("weekly report has a headline", bool(wr["headline"]))
            check(
                "week-on-week comparison is flagged honestly",
                wr["comparable"] == bool(wr["previous"]),
            )

        r = client.get("/coaching/reports/trends", headers=co, params={"days": 30})
        tr = r.json() if r.status_code == 200 else {}
        check("GET /coaching/reports/trends", r.status_code == 200 and tr.get("available"))
        check("trends cover every headline metric", len(tr.get("trends", {})) == 6, f"{len(tr.get('trends', {}))}")

        # --- Dashboard + persistence ---
        r = client.get("/coaching/dashboard", headers=co, params={"days": 30})
        check("GET /coaching/dashboard", r.status_code == 200, f"HTTP {r.status_code}")

        r = client.post("/coaching/compute", headers=co, params={"days": 30})
        written = r.json() if r.status_code == 200 else {}
        check(
            "POST /coaching/compute",
            r.status_code == 200 and written.get("recommendations_written", 0) > 0,
            str(written),
        )

        # --- Dismissal must actually suppress ---
        if recos:
            # Use the lowest-priority reco so the PATCH-without-a-stored-row
            # path is exercised on something /coaching/compute may not have
            # written under today's date.
            target = recos[-1]["key"]
            r = client.patch(
                f"/coaching/recommendations/{target}", headers=co, json={"status": "dismissed"}
            )
            check("PATCH recommendation status", r.status_code == 200, f"HTTP {r.status_code}")
            after = client.get("/coaching/recommendations", headers=co, params={"days": 30}).json()
            check(
                "dismissed recommendation is not re-shown",
                target not in {x["key"] for x in after},
                f"dismissed '{target}', {len(after)} remain",
            )
            # Restore so re-runs start clean.
            client.patch(
                f"/coaching/recommendations/{target}", headers=co, json={"status": "suggested"}
            )

    print("\n13. Analytics on an account with genuinely no history")
    # A brand-new account, not the one above — that one accumulated activity in
    # section 6 and would pass this check without ever exercising the path.
    fresh = uuid.uuid4().hex[:8]
    r = client.post(
        "/auth/register",
        json={
            "username": f"empty_{fresh}",
            "first_name": "Empty",
            "last_name": "Account",
            "email": f"empty_{fresh}@focusguard.com",
            "password": "SmokeTest@123",
        },
    )
    if r.status_code == 201:
        empty_auth = {"Authorization": f"Bearer {r.json()['access_token']}"}
        r = client.get("/analytics/dashboard", headers=empty_auth)
        check("empty account: dashboard returns 404", r.status_code == 404, f"HTTP {r.status_code}")
        check(
            "empty account: 404 explains why",
            "nothing to analyse" in r.text,
            r.json().get("detail", "")[:60],
        )
        # These must degrade to empty lists, not raise.
        r = client.get("/analytics/scores", headers=empty_auth)
        check("empty account: scores returns []", r.status_code == 200 and r.json() == [])
        r = client.get("/analytics/insights", headers=empty_auth)
        check(
            "empty account: insights explains the gap",
            r.status_code == 200 and len(r.json()) == 1 and r.json()[0]["kind"] == "summary",
        )
        r = client.get("/analytics/trend", headers=empty_auth)
        check(
            "empty account: trend returns unknown",
            r.status_code == 200 and r.json()["direction"] == "unknown",
        )
        # Weeks 5-6 must degrade the same way rather than dividing by zero.
        r = client.get("/coaching/plan", headers=empty_auth)
        check("empty account: plan returns 404", r.status_code == 404, f"HTTP {r.status_code}")
        r = client.get("/coaching/recommendations", headers=empty_auth)
        check("empty account: recommendations returns []", r.status_code == 200 and r.json() == [])
        r = client.get("/coaching/goals", headers=empty_auth)
        check("empty account: goal tracking returns []", r.status_code == 200 and r.json() == [])
        r = client.get("/coaching/alerts", headers=empty_auth)
        check("empty account: alerts returns []", r.status_code == 200 and r.json() == [])
        r = client.get("/coaching/reports/weekly", headers=empty_auth)
        check(
            "empty account: weekly report says why it is unavailable",
            r.status_code == 200 and r.json().get("available") is False and r.json().get("reason"),
        )
    else:
        check("empty account: registration", False, f"HTTP {r.status_code}")

    client.close()

    print("\n" + "=" * 58)
    if failures:
        print(f"{len(failures)} FAILED: {', '.join(failures)}")
        sys.exit(1)
    print("All smoke-test checks passed.")


if __name__ == "__main__":
    main()

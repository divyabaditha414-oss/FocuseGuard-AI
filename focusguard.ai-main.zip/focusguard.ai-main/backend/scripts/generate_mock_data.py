"""Generate the 2500-row mock activity dataset.

Writes ../../data/mock_activity_2500.csv with the columns required by the
project spec:

    User | UserType | App/Website Name | URL | OpenedDateTime | ClosedTime |
    Duration (Closed-Opened) | Productive/NonProductive | TabSwitchCount

Two properties make this data usable rather than merely plausible:

1. Visits within a day never overlap, so screen-time and switch aggregates
   actually sum to something meaningful.

2. Days are *correlated*, not independent. Each user carries a latent "energy"
   level that follows an AR(1) walk, plus a weekday rhythm, a slow personal
   trend, and a fatigue penalty carried over from late-night usage the night
   before. Without that structure there is nothing for a next-day predictor to
   learn — days drawn independently make focus degradation unpredictable *by
   construction*, and the Weeks 3-4 models would be measuring noise.

Run:  python backend/scripts/generate_mock_data.py
"""
from __future__ import annotations

import csv
import os
import random
import sys
from datetime import date, datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.catalog import NONPRODUCTIVE_APPS, PRODUCTIVE_APPS  # noqa: E402

TARGET_ROWS = 2500
DAYS = 30
SEED = 42
DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "data"))
CSV_PATH = os.path.join(DATA_DIR, "mock_activity_2500.csv")

MIN_VISIT_SECONDS = 60
DAY_END_HOUR, DAY_END_MINUTE = 23, 59

# --- Temporal dynamics ----------------------------------------------------
# AR(1) persistence: how much of yesterday's energy carries into today.
# 0.65 gives a visible multi-day run without the series locking up.
AR_PHI = 0.65
AR_SIGMA = 0.07
# Per-day multiplier on productive bias by weekday (Mon=0 .. Sun=6).
WEEKDAY_EFFECT = [0.03, 0.04, 0.02, 0.00, -0.05, -0.11, -0.08]
# Each late-night hour costs this much productive bias the following day.
FATIGUE_COEF = 0.06
# Spread of the slow per-user drift across the month.
TREND_SIGMA = 0.09

# --- Habitual app preference ---------------------------------------------
# Real users return to a handful of tools and a handful of time sinks; they do
# not sample uniformly across 65 apps. Without this concentration, every user's
# distraction time smears thinly across 25 apps and no single app ever clears
# the attention-leak threshold — the detector would look broken when it is the
# data that is wrong.
FAVOURITE_PRODUCTIVE = 6
FAVOURITE_DISTRACTIONS = 3
FAVOURITE_PROBABILITY = 0.78

# (username, user_type, base_productive_bias, devices)
USERS: list[tuple[str, str, float, list[str]]] = [
    ("User1", "Student", 0.72, ["Desktop", "Mobile"]),
    ("User2", "Student", 0.55, ["Desktop", "Mobile", "Tablet"]),
    ("User3", "Professional", 0.80, ["Desktop", "Mobile"]),
    ("User4", "Professional", 0.63, ["Desktop"]),
    ("User5", "Researcher", 0.85, ["Desktop", "Tablet"]),
    ("User6", "Freelancer", 0.60, ["Desktop", "Mobile"]),
    ("User7", "Student", 0.48, ["Mobile", "Desktop"]),
    ("User8", "Educator", 0.75, ["Desktop", "Tablet"]),
    ("User9", "Professional", 0.68, ["Desktop", "Mobile"]),
    ("User10", "Freelancer", 0.52, ["Mobile", "Desktop"]),
]

CSV_HEADER = [
    "User",
    "UserType",
    "App/Website Name",
    "URL",
    "Category",
    "OpenedDateTime",
    "ClosedTime",
    "Duration (Closed-Opened)",
    "DurationSeconds",
    "Productive/NonProductive",
    "TabSwitchCount",
    "Device",
]


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _tab_switches(
    productivity: str, duration_seconds: int, energy: float, rng: random.Random
) -> int:
    """Switch count scales with time on screen, and far faster when distracted.

    Low-energy days also fragment more, which is what ties the switch rate to
    the same latent state that drives the productive/non-productive mix.
    """
    minutes = duration_seconds / 60
    restlessness = 1.0 - _clamp(energy, -0.35, 0.35)
    if productivity == "Productive":
        base = minutes * rng.uniform(0.05, 0.35) * restlessness
    else:
        base = minutes * rng.uniform(0.6, 2.2) * restlessness
    return max(0, int(round(rng.gauss(base, base * 0.3 + 0.5))))


def _duration_seconds(productivity: str, energy: float, rng: random.Random) -> int:
    """Higher energy stretches productive blocks and shortens distracted ones."""
    stretch = 1.0 + _clamp(energy, -0.4, 0.4)
    if productivity == "Productive":
        minutes = rng.choice(
            [rng.uniform(4, 15), rng.uniform(15, 45), rng.uniform(45, 95)]
        ) * stretch
    else:
        minutes = rng.choice(
            [rng.uniform(1, 6), rng.uniform(6, 20), rng.uniform(20, 55)]
        ) / stretch
    return max(MIN_VISIT_SECONDS, int(minutes * 60))


def allocate_visits(days: list[date], rng: random.Random) -> dict[tuple[str, date], int]:
    """Split TARGET_ROWS across every (user, day) pair.

    Uses largest-remainder rounding on weekday-weighted shares so the file
    lands on exactly TARGET_ROWS without truncating anyone's timeline — a
    trailing cut would leave the last user with fewer days than the rest and
    quietly bias every per-user aggregate.
    """
    weights: dict[tuple[str, date], float] = {}
    for username, _type, _bias, _devices in USERS:
        for day in days:
            base = 0.55 if day.weekday() >= 5 else 1.0
            weights[(username, day)] = base * rng.uniform(0.8, 1.2)

    total_weight = sum(weights.values())
    exact = {k: TARGET_ROWS * w / total_weight for k, w in weights.items()}
    allocation = {k: int(v) for k, v in exact.items()}

    # Hand out the rounding remainder to the largest fractional parts.
    shortfall = TARGET_ROWS - sum(allocation.values())
    remainders = sorted(exact, key=lambda k: exact[k] - allocation[k], reverse=True)
    for key in remainders[:shortfall]:
        allocation[key] += 1

    return allocation


def generate_rows() -> list[dict]:
    rng = random.Random(SEED)

    end_day = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    start_day = end_day - timedelta(days=DAYS - 1)
    days = [(start_day + timedelta(days=d)).date() for d in range(DAYS)]

    allocation = allocate_visits(days, rng)
    rows: list[dict] = []

    for username, user_type, base_bias, devices in USERS:
        # Each user drifts slowly over the month — some improving, some not.
        trend = rng.gauss(0, TREND_SIGMA)
        energy = 0.0
        late_night_hours_yesterday = 0.0

        # This user's habitual tools and time sinks, fixed for the month.
        favourite_productive = rng.sample(PRODUCTIVE_APPS, FAVOURITE_PRODUCTIVE)
        favourite_distractions = rng.sample(NONPRODUCTIVE_APPS, FAVOURITE_DISTRACTIONS)

        for day_index, day in enumerate(days):
            # AR(1): today's energy is mostly yesterday's, plus a shock.
            energy = AR_PHI * energy + rng.gauss(0, AR_SIGMA)

            bias = _clamp(
                base_bias
                + energy
                + WEEKDAY_EFFECT[day.weekday()]
                + trend * (day_index / DAYS)
                - FATIGUE_COEF * late_night_hours_yesterday,
                0.05,
                0.97,
            )

            visits = allocation[(username, day)]
            if visits == 0:
                late_night_hours_yesterday = 0.0
                continue

            is_weekend = day.weekday() >= 5
            day_start = datetime.combine(day, datetime.min.time())
            cursor = day_start + timedelta(
                hours=rng.randint(10, 12) if is_weekend else rng.randint(7, 9),
                minutes=rng.randint(0, 59),
            )
            end_of_day = day_start.replace(hour=DAY_END_HOUR, minute=DAY_END_MINUTE)
            device = rng.choice(devices)
            late_night_seconds = 0

            for i in range(visits):
                productive = rng.random() < bias
                if rng.random() < FAVOURITE_PROBABILITY:
                    pool = favourite_productive if productive else favourite_distractions
                else:
                    pool = PRODUCTIVE_APPS if productive else NONPRODUCTIVE_APPS
                app_name, url, category, productivity = rng.choice(pool)

                duration = _duration_seconds(productivity, energy, rng)

                # Never spill past midnight: reserve a minimum slot for each
                # visit still to be placed, then fit this one into what is left.
                reserve = (visits - i - 1) * MIN_VISIT_SECONDS
                available = (end_of_day - cursor).total_seconds() - reserve
                duration = max(MIN_VISIT_SECONDS, min(duration, int(available)))

                opened_at = cursor
                closed_at = opened_at + timedelta(seconds=duration)

                if opened_at.hour >= 22:
                    late_night_seconds += duration

                rows.append(
                    {
                        "User": username,
                        "UserType": user_type,
                        "App/Website Name": app_name,
                        "URL": url,
                        "Category": category,
                        "OpenedDateTime": opened_at.strftime("%Y-%m-%d %H:%M:%S"),
                        "ClosedTime": closed_at.strftime("%Y-%m-%d %H:%M:%S"),
                        "Duration (Closed-Opened)": str(timedelta(seconds=duration)),
                        "DurationSeconds": duration,
                        "Productive/NonProductive": productivity,
                        "TabSwitchCount": _tab_switches(
                            productivity, duration, energy, rng
                        ),
                        "Device": device,
                    }
                )

                gap = timedelta(minutes=rng.randint(0, 12), seconds=rng.randint(0, 59))
                if rng.random() < 0.12:  # lunch, commute, a walk
                    gap += timedelta(minutes=rng.randint(25, 90))

                remaining_reserve = (visits - i - 2) * MIN_VISIT_SECONDS
                room = (end_of_day - closed_at).total_seconds() - remaining_reserve
                cursor = closed_at + min(gap, timedelta(seconds=max(0, room)))

            late_night_hours_yesterday = late_night_seconds / 3600

    rows.sort(key=lambda r: (r["User"], r["OpenedDateTime"]))
    return rows


def main() -> None:
    rows = generate_rows()
    if len(rows) != TARGET_ROWS:
        raise SystemExit(
            f"Expected {TARGET_ROWS} rows but generated {len(rows)}."
        )

    os.makedirs(DATA_DIR, exist_ok=True)
    with open(CSV_PATH, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=CSV_HEADER)
        writer.writeheader()
        writer.writerows(rows)

    productive = sum(1 for r in rows if r["Productive/NonProductive"] == "Productive")
    total_hours = sum(r["DurationSeconds"] for r in rows) / 3600
    print(f"Wrote {len(rows)} rows -> {CSV_PATH}")
    print(f"  Productive    : {productive} ({productive / len(rows):.1%})")
    print(f"  NonProductive : {len(rows) - productive}")
    print(f"  Total tracked : {total_hours:.1f} hours")
    print(f"  Date range    : {rows[0]['OpenedDateTime']} .. {max(r['ClosedTime'] for r in rows)}")
    print(f"  Users         : {len({r['User'] for r in rows})}")


if __name__ == "__main__":
    main()

"""Load the mock dataset into PostgreSQL.

Creates the schema, seeds User1..User10 (profiles + goals), imports every row of
data/mock_activity_2500.csv into activity_logs, derives focus sessions and
notification events from that timeline, then rebuilds the daily device rollup.

Re-runnable: it wipes previously seeded activity for the same users first, so
running it twice does not double-count screen time.

Run:  python backend/scripts/load_mock_data.py
"""
from __future__ import annotations

import csv
import os
import random
import sys
from collections import defaultdict
from datetime import date, datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sqlalchemy import case, func  # noqa: E402

from app.core.database import Base, SessionLocal, engine  # noqa: E402
from app.models import (  # noqa: E402
    ActivityLog,
    Application,
    DeviceUsageStat,
    FocusSession,
    Goal,
    NotificationEvent,
    User,
    UserProfile,
)
from app.core.catalog import APP_CATALOG  # noqa: E402
from app.core.security import hash_password  # noqa: E402

CSV_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "data", "mock_activity_2500.csv")
)
DEFAULT_PASSWORD = "FocusGuard@123"
SEED = 7
# Not ".local" — RFC 6762 reserves it, and email validators reject the domain.
EMAIL_DOMAIN = "focusguard.com"

# Apps whose arrivals plausibly generate push notifications.
NOTIFY_APPS = [
    "WhatsApp Web",
    "Telegram",
    "Discord",
    "Instagram",
    "Gmail",
    "Slack",
    "Microsoft Teams",
    "LinkedIn Feed",
]


def seed_applications(db) -> None:
    """Populate the app catalogue table (idempotent)."""
    existing = {name for (name,) in db.query(Application.name).all()}
    new = [
        Application(name=name, url=url, category=category, default_productivity=prod)
        for name, url, category, prod in APP_CATALOG
        if name not in existing
    ]
    db.add_all(new)
    db.commit()
    print(f"  applications      : {len(new)} inserted, {len(existing)} already present")


def seed_users(db, rows: list[dict]) -> dict[str, User]:
    """Create one User (+ profile + goals) per distinct User column value."""
    rng = random.Random(SEED)
    user_types = {r["User"]: r["UserType"] for r in rows}
    users: dict[str, User] = {}

    for username in sorted(user_types, key=lambda u: int(u.replace("User", ""))):
        user_type = user_types[username]
        handle = username.lower()
        user = db.query(User).filter(User.username == handle).first()

        if not user:
            user = User(
                username=handle,
                first_name=username,
                last_name="Demo",
                email=f"{handle}@{EMAIL_DOMAIN}",
                user_type=user_type,
                role="admin" if handle == "user1" else "user",
                hashed_password=hash_password(DEFAULT_PASSWORD),
            )
            db.add(user)
            db.flush()
            db.add(
                UserProfile(
                    user_id=user.id,
                    occupation=user_type,
                    organization="FocusGuard Demo Cohort",
                    work_start_hour=rng.randint(8, 10),
                    work_end_hour=rng.randint(17, 20),
                    bio=f"Seeded {user_type.lower()} account for Weeks 1-2 demo data.",
                )
            )
            db.add_all(
                [
                    Goal(
                        user_id=user.id,
                        title="Daily deep-work target",
                        goal_type="focus_minutes",
                        target_value=float(rng.choice([120, 180, 240])),
                        unit="minutes",
                        period="daily",
                        start_date=date.today() - timedelta(days=30),
                    ),
                    Goal(
                        user_id=user.id,
                        title="Keep productive time above target",
                        goal_type="productive_ratio",
                        target_value=float(rng.choice([65, 70, 75])),
                        unit="percent",
                        period="weekly",
                        start_date=date.today() - timedelta(days=30),
                    ),
                ]
            )
        else:
            user.user_type = user_type
            user.email = f"{handle}@{EMAIL_DOMAIN}"

        users[username] = user

    db.commit()
    for user in users.values():
        db.refresh(user)
    print(f"  users             : {len(users)} ready (password: {DEFAULT_PASSWORD})")
    return users


def clear_previous_seed(db, user_ids: list[int]) -> None:
    """Drop prior seeded rows so re-running the loader stays idempotent."""
    deleted = (
        db.query(ActivityLog).filter(ActivityLog.user_id.in_(user_ids)).delete(
            synchronize_session=False
        )
    )
    db.query(NotificationEvent).filter(
        NotificationEvent.user_id.in_(user_ids)
    ).delete(synchronize_session=False)
    db.query(FocusSession).filter(FocusSession.user_id.in_(user_ids)).delete(
        synchronize_session=False
    )
    db.query(DeviceUsageStat).filter(DeviceUsageStat.user_id.in_(user_ids)).delete(
        synchronize_session=False
    )
    db.commit()
    if deleted:
        print(f"  cleared           : {deleted} previously seeded activity rows")


def load_activity(db, rows: list[dict], users: dict[str, User]) -> list[ActivityLog]:
    logs = [
        ActivityLog(
            user_id=users[r["User"]].id,
            user_type=r["UserType"],
            app_name=r["App/Website Name"],
            url=r["URL"],
            category=r["Category"],
            opened_at=datetime.strptime(r["OpenedDateTime"], "%Y-%m-%d %H:%M:%S"),
            closed_at=datetime.strptime(r["ClosedTime"], "%Y-%m-%d %H:%M:%S"),
            duration_seconds=int(r["DurationSeconds"]),
            productivity=r["Productive/NonProductive"],
            tab_switch_count=int(r["TabSwitchCount"]),
            device=r["Device"],
        )
        for r in rows
    ]
    db.add_all(logs)
    db.commit()
    print(f"  activity_logs     : {len(logs)} inserted")
    return logs


def derive_focus_sessions(db, logs: list[ActivityLog]) -> int:
    """Turn each run of consecutive productive visits into a focus session.

    This is how the real tracker will reconstruct sessions from raw activity
    when the user never pressed "start focus" explicitly.
    """
    by_user_day: dict[tuple[int, date], list[ActivityLog]] = defaultdict(list)
    for log in logs:
        by_user_day[(log.user_id, log.opened_at.date())].append(log)

    created = 0
    for (user_id, _day), day_logs in by_user_day.items():
        day_logs.sort(key=lambda x: x.opened_at)

        run: list[ActivityLog] = []
        for log in day_logs + [None]:  # sentinel flushes the final run
            if log is not None and log.productivity == "Productive":
                run.append(log)
                continue

            # A run only counts as a session at 20+ minutes of real work.
            if run and sum(x.duration_seconds for x in run) >= 20 * 60:
                started_at = run[0].opened_at
                ended_at = run[-1].closed_at
                actual = int((ended_at - started_at).total_seconds())
                planned = max(25, round(actual / 60 / 5) * 5)

                session = FocusSession(
                    user_id=user_id,
                    label=f"{run[0].category} block",
                    started_at=started_at,
                    ended_at=ended_at,
                    planned_minutes=planned,
                    actual_seconds=actual,
                    interruption_count=0,  # filled in by the notification pass
                    tab_switch_count=sum(x.tab_switch_count for x in run),
                    completed=actual >= planned * 60,
                )
                db.add(session)
                db.flush()
                for x in run:
                    x.session_id = session.id
                created += 1
            run = []

    db.commit()
    print(f"  focus_sessions    : {created} derived")
    return created


def derive_notifications(db, logs: list[ActivityLog]) -> int:
    """Emit a notification shortly before each messaging/social app is opened.

    Notifications that land inside a focus session are attributed to it, which
    is what makes "notification impact" measurable in Weeks 3-4.
    """
    rng = random.Random(SEED)

    sessions_by_user: dict[int, list[FocusSession]] = defaultdict(list)
    for session in db.query(FocusSession).all():
        sessions_by_user[session.user_id].append(session)

    events: list[NotificationEvent] = []
    interruptions: dict[int, int] = defaultdict(int)

    for log in logs:
        if log.app_name not in NOTIFY_APPS:
            continue
        for _ in range(rng.randint(1, 3)):
            received_at = log.opened_at - timedelta(seconds=rng.randint(5, 240))
            session_id = None
            for session in sessions_by_user.get(log.user_id, []):
                if session.started_at <= received_at <= (session.ended_at or received_at):
                    session_id = session.id
                    interruptions[session.id] += 1
                    break

            events.append(
                NotificationEvent(
                    user_id=log.user_id,
                    source_app=log.app_name,
                    received_at=received_at,
                    acknowledged_at=log.opened_at,
                    was_dismissed=rng.random() < 0.35,
                    session_id=session_id,
                )
            )

    db.add_all(events)
    db.flush()

    for session_id, count in interruptions.items():
        db.query(FocusSession).filter(FocusSession.id == session_id).update(
            {"interruption_count": count}, synchronize_session=False
        )

    db.commit()
    print(
        f"  notifications     : {len(events)} inserted "
        f"({sum(interruptions.values())} during focus sessions)"
    )
    return len(events)


def rebuild_device_stats(db, user_ids: list[int]) -> int:
    day = func.date(ActivityLog.opened_at).label("day")
    rows = (
        db.query(
            ActivityLog.user_id,
            day,
            ActivityLog.device,
            func.sum(ActivityLog.duration_seconds),
            func.sum(
                case(
                    (ActivityLog.productivity == "Productive", ActivityLog.duration_seconds),
                    else_=0,
                )
            ),
            func.sum(
                case(
                    (
                        ActivityLog.productivity == "NonProductive",
                        ActivityLog.duration_seconds,
                    ),
                    else_=0,
                )
            ),
            func.sum(ActivityLog.tab_switch_count),
            func.count(ActivityLog.id),
        )
        .filter(ActivityLog.user_id.in_(user_ids))
        .group_by(ActivityLog.user_id, day, ActivityLog.device)
        .all()
    )

    db.add_all(
        [
            DeviceUsageStat(
                user_id=user_id,
                stat_date=d if isinstance(d, date) else date.fromisoformat(str(d)),
                device=device,
                total_screen_seconds=int(total or 0),
                productive_seconds=int(prod or 0),
                nonproductive_seconds=int(nonprod or 0),
                app_switch_count=int(switches or 0),
                unlock_count=int(visits or 0),
            )
            for user_id, d, device, total, prod, nonprod, switches, visits in rows
        ]
    )
    db.commit()
    print(f"  device_usage_stats: {len(rows)} daily rollup rows")
    return len(rows)


def main() -> None:
    if not os.path.exists(CSV_PATH):
        raise SystemExit(
            f"{CSV_PATH} not found. Run generate_mock_data.py first."
        )

    with open(CSV_PATH, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    print(f"Read {len(rows)} rows from {CSV_PATH}\n")

    print("Creating schema...")
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        seed_applications(db)
        users = seed_users(db, rows)
        user_ids = [u.id for u in users.values()]

        clear_previous_seed(db, user_ids)
        logs = load_activity(db, rows, users)
        derive_focus_sessions(db, logs)
        derive_notifications(db, logs)
        rebuild_device_stats(db, user_ids)

        total, prod_secs, switches = db.query(
            func.count(ActivityLog.id),
            func.sum(ActivityLog.duration_seconds),
            func.sum(ActivityLog.tab_switch_count),
        ).one()
        print(
            f"\nDone. {total} activity rows | "
            f"{int(prod_secs) / 3600:.1f} tracked hours | {int(switches)} tab switches."
        )
    finally:
        db.close()


if __name__ == "__main__":
    main()

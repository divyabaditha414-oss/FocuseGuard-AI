# FocusGuard AI — Backend

FastAPI + SQLAlchemy + PostgreSQL. Weeks 1–2: User Activity Monitoring & Data
Collection System.

See the [root README](../README.md) for the full setup, schema and dataset notes.

## Run

From VS Code: press `Ctrl+Shift+B` (runs the whole chain) or `F5` (debug the API).

From a terminal — double-click `run.bat`, or:

```powershell
cd C:\Users\palem\FocusGuard\backend
..\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

Server: http://localhost:8000 · Interactive docs: http://localhost:8000/docs

The database must be up first (`docker compose up -d` from the repo root).

## Layout

| Path                | Purpose                                            |
| ------------------- | -------------------------------------------------- |
| `app/main.py`       | App entrypoint, CORS, router registration          |
| `app/config.py`     | Env-driven settings (reads `../.env`)              |
| `app/database.py`   | Engine, session factory, `get_db` dependency       |
| `app/models.py`     | The 8 ORM tables                                   |
| `app/schemas.py`    | Pydantic request/response models                   |
| `app/security.py`   | bcrypt hashing, JWT encode/decode                  |
| `app/catalog.py`    | App/website catalogue + productivity classification |
| `app/routers/`      | One module per endpoint group                      |
| `scripts/`          | Mock data generation, loading, smoke test          |
| `api.http`          | REST Client requests for every endpoint            |

## Endpoints

Grouped under `/auth`, `/users`, `/goals`, `/activity`, `/sessions`,
`/notifications`, `/stats`. Full table in the [root README](../README.md#api-endpoints),
or browse http://localhost:8000/docs.

## Database

PostgreSQL, configured via `../.env`. `docker compose up -d` from the repo root
starts it on **host port 5433** (5432 inside the container), so it cannot collide
with a locally installed PostgreSQL.

`DATABASE_URL` overrides the individual `POSTGRES_*` variables if set.

Tables are created with `Base.metadata.create_all` on startup — fine for
development, but introduce Alembic migrations before production.

## Security notes

- Passwords are hashed with bcrypt; plaintext is never stored.
- `SECRET_KEY` in `.env` is a development default. Generate a real one before
  deploying: `python -c "import secrets; print(secrets.token_urlsafe(48))"`.
- `duration_seconds` on activity rows is always derived server-side from
  `closed_at - opened_at`; clients cannot set it directly.

@echo off
REM Start the FocusGuard AI FastAPI backend on http://localhost:8000
REM Uses the project venv — Anaconda's base environment has no FastAPI installed.
cd /d "%~dp0"
"%~dp0..\.venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload

"""FocusGuard AI — FastAPI application entrypoint."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .core.config import CORS_ORIGINS
from .core.database import Base, engine
from .routers import (
    activity,
    analytics,
    auth,
    coaching,
    goals,
    notifications,
    sessions,
    stats,
    users,
)

# Create tables on startup (fine for dev; use Alembic migrations in production).
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="FocusGuard AI API",
    description=(
        "Human Attention Preservation & Digital Distraction Intelligence Platform "
        "— Weeks 1-2: User Activity Monitoring & Data Collection System."
    ),
    version="0.2.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for router in (
    auth,
    users,
    goals,
    activity,
    sessions,
    notifications,
    stats,
    analytics,
    coaching,
):
    app.include_router(router.router)


@app.get("/", tags=["health"])
def root():
    return {"status": "ok", "service": "FocusGuard AI API", "docs": "/docs"}


@app.get("/health", tags=["health"])
def health():
    return {"status": "healthy"}

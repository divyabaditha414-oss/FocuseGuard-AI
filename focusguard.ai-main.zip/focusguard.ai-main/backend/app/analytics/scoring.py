"""AI-Based Focus Scoring — daily focus, productivity and stability scores.

The scores are transparent weighted composites rather than a black box. Every
score returns its component breakdown, so the UI can answer "why is my focus
score 62?" with the four numbers that produced it. That explainability is the
point: an opaque score the user cannot act on does not preserve any attention.

All scores are 0-100, higher is better.
"""
from __future__ import annotations

import statistics
from dataclasses import dataclass

from .features import DailyFeatures

# --- Tuning constants -----------------------------------------------------
# A focus block at or above this length scores full marks for depth.
IDEAL_FOCUS_BLOCK_SECONDS = 90 * 60
# Tab switches per hour at or above this are treated as maximally fragmented.
SWITCH_SATURATION_PER_HOUR = 40.0
# Productive/non-productive flips per hour at which the context-switch term hits zero.
CONTEXT_SWITCH_SATURATION_PER_HOUR = 8.0
# Default daily deep-work target when the user has set no goal.
DEFAULT_DEEP_WORK_TARGET_SECONDS = 240 * 60
INTERRUPTION_SATURATION_PER_HOUR = 6.0


@dataclass
class ScoreBreakdown:
    """A score plus the weighted components that produced it."""

    score: float
    components: dict[str, float]

    def rounded(self) -> "ScoreBreakdown":
        return ScoreBreakdown(
            score=round(self.score, 1),
            components={k: round(v, 4) for k, v in self.components.items()},
        )


def _clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def _decay(value: float, saturation: float) -> float:
    """Map 0..saturation onto 1..0 linearly, clamped outside that range."""
    if saturation <= 0:
        return 1.0
    return _clamp01(1.0 - value / saturation)


def focus_score(f: DailyFeatures) -> ScoreBreakdown:
    """How well attention was *sustained* over the day.

    Deliberately weights fragmentation as heavily as productive share: eight
    hours of productive apps consumed in 90-second slices is not a focused day,
    and a score that ignored switching would call it one.
    """
    if f.total_seconds == 0:
        return ScoreBreakdown(0.0, {})

    components = {
        # What share of the day went to productive work.
        "productive_share": _clamp01(f.productive_ratio),
        # How long the deepest unbroken block was.
        "focus_depth": _clamp01(f.longest_focus_seconds / IDEAL_FOCUS_BLOCK_SECONDS),
        # How little the user bounced between tabs.
        "switch_discipline": _decay(f.switches_per_hour, SWITCH_SATURATION_PER_HOUR),
        # How little they crossed the productive/distraction boundary.
        "context_stability": _decay(
            f.context_switches_per_hour, CONTEXT_SWITCH_SATURATION_PER_HOUR
        ),
    }
    weights = {
        "productive_share": 0.35,
        "focus_depth": 0.25,
        "switch_discipline": 0.22,
        "context_stability": 0.18,
    }
    score = 100 * sum(components[k] * w for k, w in weights.items())
    return ScoreBreakdown(score, components)


def productivity_score(
    f: DailyFeatures, deep_work_target_seconds: int | None = None
) -> ScoreBreakdown:
    """How much real output the day contained, relative to the user's target."""
    if f.total_seconds == 0:
        return ScoreBreakdown(0.0, {})

    target = deep_work_target_seconds or DEFAULT_DEEP_WORK_TARGET_SECONDS
    components = {
        "target_attainment": _clamp01(f.productive_seconds / target) if target else 0.0,
        "productive_share": _clamp01(f.productive_ratio),
        # Three or more genuine deep-work blocks is a full day's worth.
        "deep_work_blocks": _clamp01(f.deep_work_blocks / 3),
        "session_completion": _clamp01(f.session_completion_rate),
    }
    weights = {
        "target_attainment": 0.40,
        "productive_share": 0.25,
        "deep_work_blocks": 0.20,
        "session_completion": 0.15,
    }
    score = 100 * sum(components[k] * w for k, w in weights.items())
    return ScoreBreakdown(score, components)


def attention_stability_score(f: DailyFeatures) -> ScoreBreakdown:
    """How *consistent* attention was, independent of how productive it was.

    A user can be highly productive and highly unstable — constantly yanked
    between tasks but still shipping. This score isolates that instability,
    because the remedy for it is different from the remedy for low output.
    """
    if f.total_seconds == 0:
        return ScoreBreakdown(0.0, {})

    components = {
        # Even visit lengths mean a steady rhythm; wild variance means churn.
        "duration_consistency": _decay(f.visit_duration_cv, 2.0),
        "interruption_resistance": _decay(
            f.interruptions_per_hour, INTERRUPTION_SATURATION_PER_HOUR
        ),
        "context_stability": _decay(
            f.context_switches_per_hour, CONTEXT_SWITCH_SATURATION_PER_HOUR
        ),
        # Longer average visits indicate the user settled into tasks.
        "settle_depth": _clamp01(f.avg_visit_seconds / (30 * 60)),
    }
    weights = {
        "duration_consistency": 0.30,
        "interruption_resistance": 0.28,
        "context_stability": 0.24,
        "settle_depth": 0.18,
    }
    score = 100 * sum(components[k] * w for k, w in weights.items())
    return ScoreBreakdown(score, components)


def score_day(
    f: DailyFeatures, deep_work_target_seconds: int | None = None
) -> dict[str, ScoreBreakdown]:
    return {
        "focus": focus_score(f).rounded(),
        "productivity": productivity_score(f, deep_work_target_seconds).rounded(),
        "attention_stability": attention_stability_score(f).rounded(),
    }


# --- Concentration Trend Analysis -----------------------------------------


def linear_trend(values: list[float]) -> float:
    """Least-squares slope of `values` against their index.

    Written out rather than pulled from numpy so the trend maths stays visible
    and the module has no hard numeric dependency.
    """
    n = len(values)
    if n < 2:
        return 0.0
    xs = list(range(n))
    mean_x = statistics.fmean(xs)
    mean_y = statistics.fmean(values)
    denominator = sum((x - mean_x) ** 2 for x in xs)
    if denominator == 0:
        return 0.0
    numerator = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, values))
    return numerator / denominator


def concentration_trend(scores: list[float], recent_window: int = 7) -> dict:
    """Direction and magnitude of the user's focus over the scored period."""
    if not scores:
        return {
            "direction": "unknown",
            "slope_per_day": 0.0,
            "recent_avg": 0.0,
            "previous_avg": 0.0,
            "change": 0.0,
            "days_scored": 0,
        }

    slope = linear_trend(scores)
    recent = scores[-recent_window:]
    previous = scores[-2 * recent_window : -recent_window] or recent

    recent_avg = statistics.fmean(recent)
    previous_avg = statistics.fmean(previous)
    change = recent_avg - previous_avg

    # A 0.3 pt/day slope is ~2 pts a week — below that is noise, not a trend.
    if slope > 0.3:
        direction = "improving"
    elif slope < -0.3:
        direction = "declining"
    else:
        direction = "stable"

    return {
        "direction": direction,
        "slope_per_day": round(slope, 3),
        "recent_avg": round(recent_avg, 1),
        "previous_avg": round(previous_avg, 1),
        "change": round(change, 1),
        "days_scored": len(scores),
    }

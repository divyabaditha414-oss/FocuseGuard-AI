"""Per user-day behavioural feature extraction.

This is the only module in the analytics package that touches the database.
Everything downstream consumes `DailyFeatures` dataclasses, which keeps the
scoring and insight logic unit-testable without a Postgres instance.
"""
from __future__ import annotations

import statistics
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, time, timedelta

from sqlalchemy.orm import Session

from ..models import ActivityLog, FocusSession, NotificationEvent

# A visit only counts as "deep work" past this length. Below it, the context
# reload cost dominates and it is not really a focus block.
DEEP_WORK_THRESHOLD_SECONDS = 25 * 60

# Activity starting at or after this hour counts as late-night usage, which
# correlates with next-day attention fatigue.
LATE_NIGHT_HOUR = 22


@dataclass
class DailyFeatures:
    """Everything the scoring, detection and prediction layers need for one day."""

    user_id: int
    day: date

    # --- Volume ---
    total_seconds: int = 0
    productive_seconds: int = 0
    nonproductive_seconds: int = 0
    activity_count: int = 0
    distinct_apps: int = 0

    # --- Fragmentation ---
    tab_switches: int = 0
    switches_per_hour: float = 0.0
    # Transitions between a productive and a non-productive app, which cost
    # far more attention than switching between two productive tabs.
    context_switches: int = 0
    context_switches_per_hour: float = 0.0
    avg_visit_seconds: float = 0.0
    median_visit_seconds: float = 0.0
    visit_duration_cv: float = 0.0  # coefficient of variation

    # --- Depth ---
    deep_work_seconds: int = 0
    deep_work_blocks: int = 0
    longest_focus_seconds: int = 0

    # --- Sessions ---
    session_count: int = 0
    session_completion_rate: float = 0.0
    avg_session_seconds: float = 0.0

    # --- Interruptions ---
    notifications: int = 0
    notifications_during_focus: int = 0
    interruptions_per_hour: float = 0.0

    # --- Rhythm ---
    first_activity_hour: float = 0.0
    last_activity_hour: float = 0.0
    late_night_seconds: int = 0
    hourly_productive_ratio: dict[int, float] = field(default_factory=dict)

    @property
    def productive_ratio(self) -> float:
        return self.productive_seconds / self.total_seconds if self.total_seconds else 0.0

    @property
    def hours(self) -> float:
        return self.total_seconds / 3600

    def as_dict(self) -> dict:
        d = asdict(self)
        d["day"] = self.day.isoformat()
        d["productive_ratio"] = round(self.productive_ratio, 4)
        d["hours"] = round(self.hours, 2)
        # JSON object keys must be strings.
        d["hourly_productive_ratio"] = {
            str(k): round(v, 4) for k, v in self.hourly_productive_ratio.items()
        }
        return d


# The feature vector handed to the sklearn models. Order is fixed and must
# match what ml/train.py persists alongside each artifact.
MODEL_FEATURE_NAMES: list[str] = [
    "total_seconds",
    "productive_seconds",
    "nonproductive_seconds",
    "activity_count",
    "distinct_apps",
    "tab_switches",
    "switches_per_hour",
    "context_switches",
    "context_switches_per_hour",
    "avg_visit_seconds",
    "median_visit_seconds",
    "visit_duration_cv",
    "deep_work_seconds",
    "deep_work_blocks",
    "longest_focus_seconds",
    "session_count",
    "session_completion_rate",
    "avg_session_seconds",
    "notifications",
    "notifications_during_focus",
    "interruptions_per_hour",
    "first_activity_hour",
    "last_activity_hour",
    "late_night_seconds",
]


def to_model_vector(f: DailyFeatures) -> list[float]:
    return [float(getattr(f, name)) for name in MODEL_FEATURE_NAMES]


def _safe_cv(values: list[float]) -> float:
    """Coefficient of variation, guarding the n<2 and mean==0 cases."""
    if len(values) < 2:
        return 0.0
    mean = statistics.fmean(values)
    if mean == 0:
        return 0.0
    return statistics.stdev(values) / mean


def extract_daily_features(
    db: Session, user_id: int, days: int = 30, end_day: date | None = None
) -> list[DailyFeatures]:
    """Build one DailyFeatures per day that has activity, oldest first.

    Days with no activity are skipped rather than emitted as zeros: a day the
    user did not use their devices is missing data, not a day of zero focus,
    and averaging zeros in would drag every trend downwards.
    """
    end_day = end_day or date.today()
    start_day = end_day - timedelta(days=days - 1)
    window_start = datetime.combine(start_day, time.min)
    window_end = datetime.combine(end_day, time.max)

    logs = (
        db.query(ActivityLog)
        .filter(
            ActivityLog.user_id == user_id,
            ActivityLog.opened_at >= window_start,
            ActivityLog.opened_at <= window_end,
        )
        .order_by(ActivityLog.opened_at)
        .all()
    )
    if not logs:
        return []

    sessions = (
        db.query(FocusSession)
        .filter(
            FocusSession.user_id == user_id,
            FocusSession.started_at >= window_start,
            FocusSession.started_at <= window_end,
        )
        .all()
    )
    notifications = (
        db.query(NotificationEvent)
        .filter(
            NotificationEvent.user_id == user_id,
            NotificationEvent.received_at >= window_start,
            NotificationEvent.received_at <= window_end,
        )
        .all()
    )

    logs_by_day: dict[date, list[ActivityLog]] = defaultdict(list)
    for log in logs:
        logs_by_day[log.opened_at.date()].append(log)

    sessions_by_day: dict[date, list[FocusSession]] = defaultdict(list)
    for session in sessions:
        sessions_by_day[session.started_at.date()].append(session)

    notifs_by_day: dict[date, list[NotificationEvent]] = defaultdict(list)
    for notif in notifications:
        notifs_by_day[notif.received_at.date()].append(notif)

    return [
        _build_day(
            user_id,
            day,
            logs_by_day[day],
            sessions_by_day.get(day, []),
            notifs_by_day.get(day, []),
        )
        for day in sorted(logs_by_day)
    ]


def _build_day(
    user_id: int,
    day: date,
    logs: list[ActivityLog],
    sessions: list[FocusSession],
    notifications: list[NotificationEvent],
) -> DailyFeatures:
    f = DailyFeatures(user_id=user_id, day=day)
    logs = sorted(logs, key=lambda x: x.opened_at)
    durations = [float(x.duration_seconds) for x in logs]

    f.total_seconds = sum(x.duration_seconds for x in logs)
    f.productive_seconds = sum(
        x.duration_seconds for x in logs if x.productivity == "Productive"
    )
    f.nonproductive_seconds = f.total_seconds - f.productive_seconds
    f.activity_count = len(logs)
    f.distinct_apps = len({x.app_name for x in logs})
    f.tab_switches = sum(x.tab_switch_count for x in logs)

    f.avg_visit_seconds = statistics.fmean(durations) if durations else 0.0
    f.median_visit_seconds = statistics.median(durations) if durations else 0.0
    f.visit_duration_cv = _safe_cv(durations)

    # Context switches: consecutive visits that cross the productive boundary.
    f.context_switches = sum(
        1
        for prev, curr in zip(logs, logs[1:])
        if prev.productivity != curr.productivity
    )

    hours = f.total_seconds / 3600
    if hours > 0:
        f.switches_per_hour = f.tab_switches / hours
        f.context_switches_per_hour = f.context_switches / hours

    # Depth: runs of consecutive productive visits.
    run_seconds = 0
    for log in logs + [None]:
        if log is not None and log.productivity == "Productive":
            run_seconds += log.duration_seconds
            continue
        if run_seconds:
            f.longest_focus_seconds = max(f.longest_focus_seconds, run_seconds)
            if run_seconds >= DEEP_WORK_THRESHOLD_SECONDS:
                f.deep_work_seconds += run_seconds
                f.deep_work_blocks += 1
        run_seconds = 0

    f.session_count = len(sessions)
    if sessions:
        f.session_completion_rate = sum(1 for s in sessions if s.completed) / len(sessions)
        f.avg_session_seconds = statistics.fmean([float(s.actual_seconds) for s in sessions])

    f.notifications = len(notifications)
    f.notifications_during_focus = sum(1 for n in notifications if n.session_id is not None)
    if hours > 0:
        f.interruptions_per_hour = f.notifications / hours

    f.first_activity_hour = logs[0].opened_at.hour + logs[0].opened_at.minute / 60
    f.last_activity_hour = logs[-1].closed_at.hour + logs[-1].closed_at.minute / 60
    f.late_night_seconds = sum(
        x.duration_seconds for x in logs if x.opened_at.hour >= LATE_NIGHT_HOUR
    )

    # Hourly productive ratio drives the within-day fatigue curve.
    per_hour: dict[int, list[int]] = defaultdict(lambda: [0, 0])  # [productive, total]
    for log in logs:
        bucket = per_hour[log.opened_at.hour]
        bucket[1] += log.duration_seconds
        if log.productivity == "Productive":
            bucket[0] += log.duration_seconds
    f.hourly_productive_ratio = {
        hour: (prod / total if total else 0.0) for hour, (prod, total) in sorted(per_hour.items())
    }

    return f

"""Distraction Detection System.

Four detectors, each answering a different question:

    frequent interruptions  -> which days/hours were abnormally interrupted?
    context switching       -> when does the user flip between work and noise?
    notification impact     -> do notifications measurably degrade sessions?
    focus loss              -> what actually broke each productive block?

Detectors return evidence, not verdicts. The insight layer decides what is
worth telling the user; keeping that split means a threshold change never
silently rewrites the wording of an insight.
"""
from __future__ import annotations

import statistics
from collections import Counter, defaultdict
from datetime import date, datetime, time, timedelta

from sqlalchemy.orm import Session

from ..models import ActivityLog, FocusSession, NotificationEvent
from .features import DailyFeatures

# A productive block ending within this window of a notification is treated as
# plausibly caused by it. Wide enough to catch the "check phone, then scroll"
# pattern, narrow enough that unrelated events do not get blamed.
FOCUS_LOSS_WINDOW = timedelta(minutes=5)

# Flag a day as abnormally interrupted at this many standard deviations above
# the user's own mean — a personal baseline, not a population one.
INTERRUPTION_Z_THRESHOLD = 1.0


def frequent_interruption_detection(features: list[DailyFeatures]) -> dict:
    """Days where interruption rate ran well above this user's own norm."""
    rates = [f.interruptions_per_hour for f in features if f.total_seconds > 0]
    if len(rates) < 3:
        return {
            "baseline_per_hour": round(statistics.fmean(rates), 2) if rates else 0.0,
            "threshold_per_hour": 0.0,
            "flagged_days": [],
            "note": "Not enough scored days to establish a personal baseline.",
        }

    mean = statistics.fmean(rates)
    stdev = statistics.stdev(rates)
    threshold = mean + INTERRUPTION_Z_THRESHOLD * stdev

    flagged = [
        {
            "day": f.day.isoformat(),
            "interruptions": f.notifications,
            "per_hour": round(f.interruptions_per_hour, 2),
            "during_focus": f.notifications_during_focus,
        }
        for f in features
        if f.total_seconds > 0 and f.interruptions_per_hour > threshold
    ]

    return {
        "baseline_per_hour": round(mean, 2),
        "threshold_per_hour": round(threshold, 2),
        "flagged_days": sorted(flagged, key=lambda d: d["per_hour"], reverse=True),
    }


def context_switching_analysis(
    db: Session, user_id: int, features: list[DailyFeatures], days: int = 30
) -> dict:
    """Where and when the user crosses the productive/distraction boundary."""
    if not features:
        return {"total_switches": 0, "per_hour": 0.0, "peak_hours": [], "top_triggers": []}

    end_day = features[-1].day
    start_day = end_day - timedelta(days=days - 1)

    logs = (
        db.query(ActivityLog)
        .filter(
            ActivityLog.user_id == user_id,
            ActivityLog.opened_at >= datetime.combine(start_day, time.min),
            ActivityLog.opened_at <= datetime.combine(end_day, time.max),
        )
        .order_by(ActivityLog.opened_at)
        .all()
    )

    # Group by day first: the gap between the last visit of one day and the
    # first of the next is sleep, not a context switch.
    by_day: dict[date, list[ActivityLog]] = defaultdict(list)
    for log in logs:
        by_day[log.opened_at.date()].append(log)

    hour_counter: Counter[int] = Counter()
    trigger_counter: Counter[str] = Counter()
    total = 0

    for day_logs in by_day.values():
        for prev, curr in zip(day_logs, day_logs[1:]):
            if prev.productivity == curr.productivity:
                continue
            total += 1
            hour_counter[curr.opened_at.hour] += 1
            # Only a switch *into* distraction names a trigger app.
            if curr.productivity == "NonProductive":
                trigger_counter[curr.app_name] += 1

    total_hours = sum(f.hours for f in features)
    peak = [
        {"hour": hour, "switches": count} for hour, count in hour_counter.most_common(5)
    ]
    triggers = [
        {"app_name": app, "switches_into_distraction": count}
        for app, count in trigger_counter.most_common(8)
    ]

    return {
        "total_switches": total,
        "per_hour": round(total / total_hours, 2) if total_hours else 0.0,
        "peak_hours": peak,
        "top_triggers": triggers,
    }


def notification_impact_assessment(db: Session, user_id: int, days: int = 30) -> dict:
    """Compare focus sessions that were interrupted against those that were not.

    This is an observational comparison, not a controlled one — sessions are
    not randomly assigned to be interrupted, so the difference is an
    association. The wording downstream reflects that.
    """
    since = datetime.utcnow() - timedelta(days=days)
    sessions = (
        db.query(FocusSession)
        .filter(FocusSession.user_id == user_id, FocusSession.started_at >= since)
        .all()
    )
    if not sessions:
        return {"sessions": 0, "note": "No focus sessions in the window."}

    interrupted = [s for s in sessions if s.interruption_count > 0]
    clean = [s for s in sessions if s.interruption_count == 0]

    def summarise(group: list[FocusSession]) -> dict:
        if not group:
            return {"count": 0, "avg_minutes": 0.0, "completion_rate": 0.0, "avg_switches": 0.0}
        return {
            "count": len(group),
            "avg_minutes": round(
                statistics.fmean([s.actual_seconds for s in group]) / 60, 1
            ),
            "completion_rate": round(
                sum(1 for s in group if s.completed) / len(group), 3
            ),
            "avg_switches": round(
                statistics.fmean([float(s.tab_switch_count) for s in group]), 1
            ),
        }

    interrupted_stats = summarise(interrupted)
    clean_stats = summarise(clean)

    completion_gap = clean_stats["completion_rate"] - interrupted_stats["completion_rate"]
    switch_gap = interrupted_stats["avg_switches"] - clean_stats["avg_switches"]

    # Which apps do the interrupting.
    notifs = (
        db.query(NotificationEvent)
        .filter(
            NotificationEvent.user_id == user_id,
            NotificationEvent.received_at >= since,
            NotificationEvent.session_id.isnot(None),
        )
        .all()
    )
    worst = Counter(n.source_app for n in notifs).most_common(5)

    return {
        "sessions": len(sessions),
        "interrupted": interrupted_stats,
        "uninterrupted": clean_stats,
        "completion_rate_gap": round(completion_gap, 3),
        "extra_switches_when_interrupted": round(switch_gap, 1),
        "top_interrupting_apps": [
            {"source_app": app, "interruptions": count} for app, count in worst
        ],
        "comparable": bool(interrupted and clean),
    }


def focus_loss_identification(db: Session, user_id: int, days: int = 30) -> dict:
    """What ended each productive run — a notification, or a self-initiated drift.

    Distinguishing the two matters: notification-driven losses are fixed by
    muting something, self-initiated drift is a habit problem.
    """
    end_day = date.today()
    start_day = end_day - timedelta(days=days - 1)

    logs = (
        db.query(ActivityLog)
        .filter(
            ActivityLog.user_id == user_id,
            ActivityLog.opened_at >= datetime.combine(start_day, time.min),
        )
        .order_by(ActivityLog.opened_at)
        .all()
    )
    notifs = (
        db.query(NotificationEvent)
        .filter(
            NotificationEvent.user_id == user_id,
            NotificationEvent.received_at >= datetime.combine(start_day, time.min),
        )
        .all()
    )
    notif_times = sorted(n.received_at for n in notifs)

    def preceded_by_notification(moment: datetime) -> bool:
        return any(moment - FOCUS_LOSS_WINDOW <= t <= moment for t in notif_times)

    by_day: dict[date, list[ActivityLog]] = defaultdict(list)
    for log in logs:
        by_day[log.opened_at.date()].append(log)

    events: list[dict] = []
    for day_logs in by_day.values():
        run_seconds = 0
        for prev, curr in zip(day_logs, day_logs[1:]):
            if prev.productivity == "Productive":
                run_seconds += prev.duration_seconds
            if prev.productivity == "Productive" and curr.productivity == "NonProductive":
                events.append(
                    {
                        "at": curr.opened_at.isoformat(),
                        "broken_by": curr.app_name,
                        "focus_seconds_lost": run_seconds,
                        "notification_triggered": preceded_by_notification(curr.opened_at),
                    }
                )
                run_seconds = 0
            elif curr.productivity == "NonProductive":
                run_seconds = 0

    triggered = sum(1 for e in events if e["notification_triggered"])
    breakers = Counter(e["broken_by"] for e in events).most_common(8)

    return {
        "focus_loss_events": len(events),
        "notification_triggered": triggered,
        "self_initiated": len(events) - triggered,
        "notification_triggered_share": round(triggered / len(events), 3) if events else 0.0,
        "top_breakers": [
            {"app_name": app, "times_broke_focus": count} for app, count in breakers
        ],
        # Longest interruptions first — the costly ones, not just the frequent ones.
        "worst_events": sorted(
            events, key=lambda e: e["focus_seconds_lost"], reverse=True
        )[:10],
    }

"""Weeks 3-4: AI-Based Attention Analysis & Distraction Detection Engine.

Layered so each stage is independently testable:

    features   -> per user-day behavioural feature vectors (the only SQL layer)
    scoring    -> focus / productivity / attention-stability scores + trends
    distraction-> interruption, context-switching and focus-loss detection
    predictive -> trained sklearn models for degradation / risk / fatigue
    insights   -> attention leaks and human-readable daily summaries

Everything downstream of `features` operates on plain dataclasses, so the
scoring and insight logic can be unit-tested without a database.
"""

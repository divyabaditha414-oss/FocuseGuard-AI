"""Predictive Analytics — focus degradation, productivity risk, attention fatigue.

Two of the three predictors are trained sklearn models loaded from
`backend/ml/artifacts`. If no artifact is present the module falls back to a
transparent heuristic and *says so* via `model_version="heuristic"`, so a
prediction is never presented as model output when no model ran.

Attention fatigue is deliberately not a learned model: it is a within-day
measurement (does the productive ratio decay across the working hours?), and
there is no future label to train against.
"""
from __future__ import annotations

import statistics
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

from ..core.config import ML_ARTIFACT_DIR
from .features import DailyFeatures, MODEL_FEATURE_NAMES, to_model_vector
from .scoring import focus_score, linear_trend

# How many prior days of features the models consume.
LOOKBACK_DAYS = 3
# A predicted drop of this many focus points counts as degradation.
DEGRADATION_POINTS = 5.0
# Below this productive ratio, the next day is flagged as at risk.
RISK_RATIO_THRESHOLD = 0.60

_CACHE: dict[str, object] = {}


@dataclass
class PredictionResult:
    kind: str
    predicted_value: float
    label: str
    confidence: float
    model_version: str
    detail: dict


def _load_artifact(name: str):
    """Load and memoise a joblib artifact; return None when absent."""
    if name in _CACHE:
        return _CACHE[name]

    path = Path(ML_ARTIFACT_DIR) / f"{name}.joblib"
    if not path.is_file():
        _CACHE[name] = None
        return None

    try:
        import joblib

        artifact = joblib.load(path)
    except Exception:
        # A corrupt or version-mismatched artifact must degrade to the
        # heuristic, not take the whole analytics API down.
        artifact = None

    _CACHE[name] = artifact
    return artifact


def clear_model_cache() -> None:
    """Called after training so a freshly written artifact is picked up."""
    _CACHE.clear()


def build_lookback_vector(window: list[DailyFeatures]) -> list[float]:
    """Flatten the last LOOKBACK_DAYS of features into one row.

    Shared by training and inference so the column order can never drift
    between the two.
    """
    if len(window) < LOOKBACK_DAYS:
        raise ValueError(f"Need {LOOKBACK_DAYS} days, got {len(window)}")
    vector: list[float] = []
    for day in window[-LOOKBACK_DAYS:]:
        vector.extend(to_model_vector(day))
    return vector


def lookback_feature_names() -> list[str]:
    return [
        f"d-{LOOKBACK_DAYS - i}_{name}"
        for i in range(LOOKBACK_DAYS)
        for name in MODEL_FEATURE_NAMES
    ]


# --- Focus Degradation Prediction ----------------------------------------


def predict_focus_degradation(features: list[DailyFeatures]) -> PredictionResult:
    """Forecast tomorrow's focus score and flag a meaningful drop."""
    scores = [focus_score(f).score for f in features]
    recent_avg = statistics.fmean(scores[-7:]) if scores else 0.0
    target_day = (features[-1].day + timedelta(days=1)) if features else date.today()

    artifact = _load_artifact("focus_degradation")
    predicted: float | None = None
    version = "heuristic"

    if artifact and len(features) >= LOOKBACK_DAYS:
        try:
            model = artifact["model"]
            row = build_lookback_vector(features)
            predicted = float(model.predict([row])[0])
            version = artifact.get("version", "trained")
        except Exception:
            predicted = None

    if predicted is None:
        # Heuristic: extend the recent trend one day forward.
        slope = linear_trend(scores[-7:]) if len(scores) >= 2 else 0.0
        predicted = recent_avg + slope

    predicted = max(0.0, min(100.0, predicted))
    drop = recent_avg - predicted
    degrading = drop >= DEGRADATION_POINTS

    return PredictionResult(
        kind="focus_degradation",
        predicted_value=round(predicted, 1),
        label="degrading" if degrading else "stable",
        # Confidence scales with how far the prediction sits from the decision
        # boundary — a 0.1-point drop should not read as a confident call.
        confidence=round(min(1.0, abs(drop) / (2 * DEGRADATION_POINTS)), 2),
        model_version=version,
        detail={
            "target_date": target_day.isoformat(),
            "recent_avg_focus": round(recent_avg, 1),
            "predicted_focus": round(predicted, 1),
            "expected_change": round(-drop, 1),
            "days_of_history": len(features),
        },
    )


# --- Productivity Risk Detection -----------------------------------------


def predict_productivity_risk(features: list[DailyFeatures]) -> PredictionResult:
    """Probability that tomorrow's productive ratio falls below target."""
    ratios = [f.productive_ratio for f in features]
    recent = statistics.fmean(ratios[-7:]) if ratios else 0.0
    target_day = (features[-1].day + timedelta(days=1)) if features else date.today()

    artifact = _load_artifact("productivity_risk")
    probability: float | None = None
    version = "heuristic"

    if artifact and len(features) >= LOOKBACK_DAYS:
        try:
            model = artifact["model"]
            row = build_lookback_vector(features)
            probability = float(model.predict_proba([row])[0][1])
            version = artifact.get("version", "trained")
        except Exception:
            probability = None

    if probability is None:
        # Heuristic: how far the recent ratio sits below the threshold,
        # scaled into a 0-1 pseudo-probability.
        gap = RISK_RATIO_THRESHOLD - recent
        probability = max(0.0, min(1.0, 0.5 + gap * 2))

    at_risk = probability >= 0.5
    return PredictionResult(
        kind="productivity_risk",
        predicted_value=round(probability, 3),
        label="at_risk" if at_risk else "on_track",
        confidence=round(abs(probability - 0.5) * 2, 2),
        model_version=version,
        detail={
            "target_date": target_day.isoformat(),
            "risk_probability": round(probability, 3),
            "recent_productive_ratio": round(recent, 3),
            "threshold": RISK_RATIO_THRESHOLD,
            "days_of_history": len(features),
        },
    )


# --- Attention Fatigue Analysis ------------------------------------------


def analyse_attention_fatigue(features: list[DailyFeatures]) -> PredictionResult:
    """Measure within-day decay of productive attention across working hours.

    Computed, not predicted: this describes the shape of the day just lived.
    A negative slope means concentration thinned out as the day wore on.
    """
    recent = [f for f in features[-7:] if f.hourly_productive_ratio]
    if not recent:
        return PredictionResult(
            kind="attention_fatigue",
            predicted_value=0.0,
            label="unknown",
            confidence=0.0,
            model_version="computed",
            detail={"note": "No hourly activity available."},
        )

    # Average the productive ratio per clock hour across the recent days, then
    # measure its slope over the working window.
    per_hour: dict[int, list[float]] = {}
    for day in recent:
        for hour, ratio in day.hourly_productive_ratio.items():
            per_hour.setdefault(hour, []).append(ratio)

    working = sorted(h for h in per_hour if 6 <= h <= 23)
    curve = [statistics.fmean(per_hour[h]) for h in working]
    slope = linear_trend(curve) if len(curve) >= 2 else 0.0

    # Compare the first and last third of the working day.
    third = max(1, len(curve) // 3)
    morning = statistics.fmean(curve[:third])
    evening = statistics.fmean(curve[-third:])
    decay = morning - evening

    if slope < -0.02:
        label = "fatiguing"
    elif slope > 0.02:
        label = "warming_up"
    else:
        label = "steady"

    # Late-night usage compounds fatigue; surface it alongside.
    late_night_minutes = statistics.fmean([f.late_night_seconds for f in recent]) / 60

    return PredictionResult(
        kind="attention_fatigue",
        predicted_value=round(decay, 3),
        label=label,
        confidence=round(min(1.0, abs(slope) / 0.05), 2),
        model_version="computed",
        detail={
            "slope_per_hour": round(slope, 4),
            "morning_productive_ratio": round(morning, 3),
            "evening_productive_ratio": round(evening, 3),
            "decay": round(decay, 3),
            "avg_late_night_minutes": round(late_night_minutes, 1),
            "hours_analysed": working,
            "curve": [round(v, 3) for v in curve],
            "days_analysed": len(recent),
        },
    )


def predict_all(features: list[DailyFeatures]) -> list[PredictionResult]:
    return [
        predict_focus_degradation(features),
        predict_productivity_risk(features),
        analyse_attention_fatigue(features),
    ]

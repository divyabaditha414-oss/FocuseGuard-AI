"""Insight Generation — attention leaks, personalised insights, daily summary.

Turns the detector output into sentences a user can act on. Every insight
carries the evidence it was derived from, so nothing asserted here is
unfalsifiable: if the number moves, the sentence moves with it.
"""
from __future__ import annotations

import statistics
from collections import defaultdict
from datetime import date, datetime, time, timedelta

from sqlalchemy.orm import Session

from ..models import ActivityLog
from .distraction import (
    context_switching_analysis,
    focus_loss_identification,
    frequent_interruption_detection,
    notification_impact_assessment,
)
from .features import DailyFeatures
from .predictive import analyse_attention_fatigue, predict_focus_degradation
from .scoring import concentration_trend, focus_score

# An app must cost at least this much daily time before it is worth naming.
LEAK_MIN_MINUTES_PER_DAY = 10.0


def _fmt_minutes(seconds: float) -> str:
    minutes = seconds / 60
    if minutes < 60:
        return f"{minutes:.0f} min"
    return f"{minutes / 60:.1f} h"


# --- Attention Leak Identification ---------------------------------------


def identify_attention_leaks(
    db: Session, user_id: int, features: list[DailyFeatures], days: int = 30, limit: int = 8
) -> list[dict]:
    """Rank non-productive apps by the attention they actually cost.

    Time alone is the wrong ranking: an app open for 40 minutes once a week is
    cheaper than one opened 30 times a day for 90 seconds, because each of
    those 30 openings also costs a context reload. The leak score combines
    both, weighted by how often the app broke a productive run.
    """
    if not features:
        return []

    end_day = features[-1].day
    start_day = end_day - timedelta(days=days - 1)
    day_count = len({f.day for f in features}) or 1

    logs = (
        db.query(ActivityLog)
        .filter(
            ActivityLog.user_id == user_id,
            ActivityLog.productivity == "NonProductive",
            ActivityLog.opened_at >= datetime.combine(start_day, time.min),
            ActivityLog.opened_at <= datetime.combine(end_day, time.max),
        )
        .all()
    )
    if not logs:
        return []

    breakers = {
        b["app_name"]: b["times_broke_focus"]
        for b in focus_loss_identification(db, user_id, days)["top_breakers"]
    }

    by_app: dict[str, dict] = defaultdict(
        lambda: {"seconds": 0, "visits": 0, "switches": 0, "category": "Other"}
    )
    for log in logs:
        entry = by_app[log.app_name]
        entry["seconds"] += log.duration_seconds
        entry["visits"] += 1
        entry["switches"] += log.tab_switch_count
        entry["category"] = log.category

    leaks = []
    for app, entry in by_app.items():
        minutes_per_day = entry["seconds"] / 60 / day_count
        if minutes_per_day < LEAK_MIN_MINUTES_PER_DAY:
            continue

        visits_per_day = entry["visits"] / day_count
        focus_breaks = breakers.get(app, 0)

        # Time cost + re-entry cost + the cost of breaking real work.
        leak_score = (
            minutes_per_day
            + visits_per_day * 3
            + focus_breaks * 2
        )

        leaks.append(
            {
                "app_name": app,
                "category": entry["category"],
                "total_seconds": entry["seconds"],
                "minutes_per_day": round(minutes_per_day, 1),
                "visits_per_day": round(visits_per_day, 1),
                "tab_switches": entry["switches"],
                "times_broke_focus": focus_breaks,
                "leak_score": round(leak_score, 1),
            }
        )

    return sorted(leaks, key=lambda x: x["leak_score"], reverse=True)[:limit]


# --- Personalised insights -----------------------------------------------


def _insight(kind: str, severity: str, title: str, message: str, evidence: dict) -> dict:
    return {
        "kind": kind,
        "severity": severity,
        "title": title,
        "message": message,
        "evidence": evidence,
    }


def generate_insights(
    db: Session, user_id: int, features: list[DailyFeatures], days: int = 30
) -> list[dict]:
    """Produce the ranked list of findings for this user."""
    if not features:
        return [
            _insight(
                "summary",
                "info",
                "Not enough data yet",
                "No activity has been recorded in this window, so no attention "
                "analysis is possible. Start tracking to build a baseline.",
                {},
            )
        ]

    insights: list[dict] = []
    latest = features[-1]
    scores = [focus_score(f).score for f in features]

    # --- Attention leaks ---
    leaks = identify_attention_leaks(db, user_id, features, days)
    if leaks:
        worst = leaks[0]
        insights.append(
            _insight(
                "attention_leak",
                "warning" if worst["minutes_per_day"] >= 30 else "info",
                f"{worst['app_name']} is your biggest attention leak",
                f"{worst['app_name']} takes about {worst['minutes_per_day']:.0f} minutes "
                f"a day across {worst['visits_per_day']:.1f} visits, and broke a "
                f"productive stretch {worst['times_broke_focus']} times. Closing it "
                f"during work blocks is the single highest-value change available.",
                worst,
            )
        )

    # --- Context switching ---
    switching = context_switching_analysis(db, user_id, features, days)
    if switching["peak_hours"]:
        peak = switching["peak_hours"][0]
        insights.append(
            _insight(
                "context_switching",
                "warning" if switching["per_hour"] > 4 else "info",
                f"Attention fragments most around {peak['hour']:02d}:00",
                f"You cross between focused work and distraction "
                f"{switching['per_hour']:.1f} times an hour on average, peaking at "
                f"{peak['hour']:02d}:00 with {peak['switches']} switches in this window. "
                f"Scheduling your hardest task away from that hour costs nothing "
                f"and removes the most contested slot in your day.",
                switching,
            )
        )

    # --- Notification impact ---
    impact = notification_impact_assessment(db, user_id, days)
    if impact.get("comparable"):
        gap = impact["completion_rate_gap"]
        if gap > 0.05:
            insights.append(
                _insight(
                    "notification_impact",
                    "warning" if gap > 0.15 else "info",
                    "Interrupted sessions complete less often",
                    f"Focus sessions that received a notification completed "
                    f"{gap * 100:.0f} percentage points less often than uninterrupted "
                    f"ones, and carried {impact['extra_switches_when_interrupted']:.0f} "
                    f"more tab switches. Sessions are not randomly assigned to be "
                    f"interrupted, so this is an association rather than proof of cause "
                    f"— but muting the top offenders is a cheap thing to test.",
                    impact,
                )
            )

    # --- Focus loss ---
    loss = focus_loss_identification(db, user_id, days)
    if loss["focus_loss_events"]:
        share = loss["notification_triggered_share"]
        if share >= 0.4:
            message = (
                f"{share * 100:.0f}% of your {loss['focus_loss_events']} focus breaks "
                f"followed a notification within five minutes. This is an external "
                f"problem: muting notifications during focus blocks addresses most of it."
            )
        else:
            message = (
                f"Only {share * 100:.0f}% of your {loss['focus_loss_events']} focus "
                f"breaks followed a notification — the rest were self-initiated. "
                f"Blocking notifications will not fix this; the habit of reaching for "
                f"a distraction mid-task is what to work on."
            )
        insights.append(
            _insight(
                "focus_loss",
                "warning" if loss["focus_loss_events"] > 3 * len(features) else "info",
                "What actually breaks your focus",
                message,
                {
                    k: loss[k]
                    for k in (
                        "focus_loss_events",
                        "notification_triggered",
                        "self_initiated",
                        "notification_triggered_share",
                        "top_breakers",
                    )
                },
            )
        )

    # --- Interruption spikes ---
    interruptions = frequent_interruption_detection(features)
    if interruptions.get("flagged_days"):
        worst_day = interruptions["flagged_days"][0]
        insights.append(
            _insight(
                "interruption_spike",
                "info",
                f"{len(interruptions['flagged_days'])} unusually interrupted days",
                f"On {worst_day['day']} you took {worst_day['interruptions']} "
                f"notifications ({worst_day['per_hour']:.1f}/hour) against your normal "
                f"{interruptions['baseline_per_hour']:.1f}/hour. Days like this are "
                f"worth a look — something scheduled, not something habitual.",
                interruptions,
            )
        )

    # --- Fatigue ---
    fatigue = analyse_attention_fatigue(features)
    if fatigue.label == "fatiguing":
        d = fatigue.detail
        insights.append(
            _insight(
                "fatigue",
                "warning",
                "Your attention thins out as the day goes on",
                f"Productive share drops from {d['morning_productive_ratio'] * 100:.0f}% "
                f"in your first working hours to {d['evening_productive_ratio'] * 100:.0f}% "
                f"in your last. Move your most demanding work earlier, and treat the "
                f"late block as admin time rather than fighting it.",
                d,
            )
        )

    # --- Trend ---
    trend = concentration_trend(scores)
    if trend["direction"] != "stable":
        improving = trend["direction"] == "improving"
        insights.append(
            _insight(
                "trend",
                "info" if improving else "warning",
                f"Concentration is {trend['direction']}",
                f"Your focus score has moved {trend['change']:+.1f} points between the "
                f"previous week ({trend['previous_avg']:.0f}) and the most recent one "
                f"({trend['recent_avg']:.0f}), a slope of "
                f"{trend['slope_per_day']:+.2f} points per day.",
                trend,
            )
        )

    # --- Forward look ---
    degradation = predict_focus_degradation(features)
    if degradation.label == "degrading":
        insights.append(
            _insight(
                "prediction",
                "warning",
                "Tomorrow looks like a weaker focus day",
                f"Based on the last {min(len(features), 7)} days, tomorrow's focus score "
                f"is projected at {degradation.predicted_value:.0f} against a recent "
                f"average of {degradation.detail['recent_avg_focus']:.0f}. "
                f"Source: {degradation.model_version}.",
                degradation.detail,
            )
        )

    severity_rank = {"critical": 0, "warning": 1, "info": 2}
    insights.sort(key=lambda i: severity_rank.get(i["severity"], 3))

    # Always close with the plain summary of the most recent day.
    insights.append(daily_performance_summary(latest, scores))
    return insights


# --- Daily Performance Summary -------------------------------------------


def daily_performance_summary(f: DailyFeatures, all_scores: list[float]) -> dict:
    """One-paragraph account of the most recent day, in context."""
    today_score = focus_score(f).score
    average = statistics.fmean(all_scores) if all_scores else today_score
    delta = today_score - average

    if delta > 5:
        verdict = "better than your usual"
    elif delta < -5:
        verdict = "below your usual"
    else:
        verdict = "in line with your usual"

    message = (
        f"On {f.day.isoformat()} you tracked {_fmt_minutes(f.total_seconds)} of screen "
        f"time, {f.productive_ratio * 100:.0f}% of it productive, across {f.activity_count} "
        f"app visits and {f.distinct_apps} distinct apps. Your longest unbroken focus "
        f"block was {_fmt_minutes(f.longest_focus_seconds)}, with {f.tab_switches} tab "
        f"switches ({f.switches_per_hour:.1f}/hour) and {f.notifications} notifications. "
        f"That is a focus score of {today_score:.0f}, {verdict} "
        f"({average:.0f} average over {len(all_scores)} days)."
    )

    return _insight(
        "summary",
        "info",
        f"Daily summary — {f.day.isoformat()}",
        message,
        {
            "day": f.day.isoformat(),
            "focus_score": round(today_score, 1),
            "average_focus_score": round(average, 1),
            "delta": round(delta, 1),
            "total_seconds": f.total_seconds,
            "productive_ratio": round(f.productive_ratio, 3),
            "longest_focus_seconds": f.longest_focus_seconds,
            "tab_switches": f.tab_switches,
            "notifications": f.notifications,
        },
    )

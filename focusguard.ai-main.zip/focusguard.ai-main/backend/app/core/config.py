"""Application configuration.

Reads settings from environment variables so the same code runs locally and in
production. The project targets PostgreSQL (Weeks 1-2: "PostgreSQL Database
Design"), which is what the bundled docker-compose.yml brings up.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

# Locate the repo root by looking for a marker file rather than counting ".."
# hops. A relative hop breaks silently the moment this module moves, and the
# only symptom is connecting to the wrong port with default credentials.
_HERE = Path(__file__).resolve()
REPO_ROOT = next(
    (p for p in _HERE.parents if (p / "docker-compose.yml").is_file()),
    _HERE.parents[3],
)
load_dotenv(REPO_ROOT / ".env")

# --- Database -------------------------------------------------------------
POSTGRES_USER = os.getenv("POSTGRES_USER", "focusguard")
POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD", "focusguard")
POSTGRES_HOST = os.getenv("POSTGRES_HOST", "localhost")
# 5433 matches docker-compose.yml's host mapping.
POSTGRES_PORT = os.getenv("POSTGRES_PORT", "5433")
POSTGRES_DB = os.getenv("POSTGRES_DB", "focusguard")

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    f"postgresql+psycopg2://{POSTGRES_USER}:{POSTGRES_PASSWORD}"
    f"@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}",
)

# --- Auth / JWT -----------------------------------------------------------
# IMPORTANT: override SECRET_KEY in production with a long random value.
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440"))  # 24h

# --- CORS -----------------------------------------------------------------
# Origins allowed to call the API. Add your deployed frontend origin here.
# "null" covers pages opened directly via file:// in a browser.
CORS_ORIGINS = os.getenv(
    "CORS_ORIGINS",
    "http://localhost:5500,http://127.0.0.1:5500,http://localhost:8000,null",
).split(",")

# --- Machine learning (Weeks 3-4) -----------------------------------------
# Where ml/train.py writes model artifacts and the API loads them from.
ML_ARTIFACT_DIR = Path(
    os.getenv("ML_ARTIFACT_DIR", str(REPO_ROOT / "backend" / "ml" / "artifacts"))
)

"""Cross-cutting infrastructure: settings, DB session, auth, app catalogue."""

"""App/website catalogue and the Productive / NonProductive classification.

Single source of truth shared by the ingestion API and the mock-data generator,
so a seeded row and a live-tracked row are labelled the same way.
"""

# (name, url, category, productivity)
APP_CATALOG: list[tuple[str, str, str, str]] = [
    # --- Productive ---------------------------------------------------------
    ("CodeChef", "codechef.com", "Coding Practice", "Productive"),
    ("LeetCode", "leetcode.com", "Coding Practice", "Productive"),
    ("HackerRank", "hackerrank.com", "Coding Practice", "Productive"),
    ("GeeksforGeeks", "geeksforgeeks.org", "Learning", "Productive"),
    ("Coursera", "coursera.org", "Learning", "Productive"),
    ("Udemy", "udemy.com", "Learning", "Productive"),
    ("NPTEL", "nptel.ac.in", "Learning", "Productive"),
    ("Khan Academy", "khanacademy.org", "Learning", "Productive"),
    ("Stack Overflow", "stackoverflow.com", "Reference", "Productive"),
    ("GitHub", "github.com", "Development", "Productive"),
    ("GitLab", "gitlab.com", "Development", "Productive"),
    ("Visual Studio Code", "app://code", "Development", "Productive"),
    ("PyCharm", "app://pycharm", "Development", "Productive"),
    ("Jupyter Notebook", "localhost:8888", "Development", "Productive"),
    ("Google Colab", "colab.research.google.com", "Development", "Productive"),
    ("Postman", "app://postman", "Development", "Productive"),
    ("Docker Desktop", "app://docker", "Development", "Productive"),
    ("Google Docs", "docs.google.com", "Documents", "Productive"),
    ("Google Sheets", "sheets.google.com", "Documents", "Productive"),
    ("Microsoft Word", "app://winword", "Documents", "Productive"),
    ("Microsoft Excel", "app://excel", "Documents", "Productive"),
    ("Microsoft PowerPoint", "app://powerpnt", "Documents", "Productive"),
    ("Notion", "notion.so", "Notes", "Productive"),
    ("Obsidian", "app://obsidian", "Notes", "Productive"),
    ("Google Scholar", "scholar.google.com", "Research", "Productive"),
    ("arXiv", "arxiv.org", "Research", "Productive"),
    ("IEEE Xplore", "ieeexplore.ieee.org", "Research", "Productive"),
    ("Overleaf", "overleaf.com", "Research", "Productive"),
    ("Gmail", "mail.google.com", "Communication", "Productive"),
    ("Outlook", "outlook.office.com", "Communication", "Productive"),
    ("Microsoft Teams", "teams.microsoft.com", "Communication", "Productive"),
    ("Zoom", "app://zoom", "Communication", "Productive"),
    ("Google Meet", "meet.google.com", "Communication", "Productive"),
    ("Slack", "app://slack", "Communication", "Productive"),
    ("Jira", "atlassian.net", "Project Management", "Productive"),
    ("Trello", "trello.com", "Project Management", "Productive"),
    ("Asana", "asana.com", "Project Management", "Productive"),
    ("Google Calendar", "calendar.google.com", "Planning", "Productive"),
    ("Figma", "figma.com", "Design", "Productive"),
    ("Kaggle", "kaggle.com", "Research", "Productive"),
    # --- NonProductive ------------------------------------------------------
    ("YouTube", "youtube.com", "Video", "NonProductive"),
    ("Netflix", "netflix.com", "Video", "NonProductive"),
    ("Prime Video", "primevideo.com", "Video", "NonProductive"),
    ("Hotstar", "hotstar.com", "Video", "NonProductive"),
    ("Instagram", "instagram.com", "Social Media", "NonProductive"),
    ("Facebook", "facebook.com", "Social Media", "NonProductive"),
    ("X (Twitter)", "x.com", "Social Media", "NonProductive"),
    ("Snapchat", "app://snapchat", "Social Media", "NonProductive"),
    ("Reddit", "reddit.com", "Social Media", "NonProductive"),
    ("Pinterest", "pinterest.com", "Social Media", "NonProductive"),
    ("LinkedIn Feed", "linkedin.com/feed", "Social Media", "NonProductive"),
    ("WhatsApp Web", "web.whatsapp.com", "Messaging", "NonProductive"),
    ("Telegram", "app://telegram", "Messaging", "NonProductive"),
    ("Discord", "app://discord", "Messaging", "NonProductive"),
    ("Spotify", "app://spotify", "Music", "NonProductive"),
    ("Steam", "app://steam", "Gaming", "NonProductive"),
    ("Epic Games", "app://epicgames", "Gaming", "NonProductive"),
    ("BGMI", "app://bgmi", "Gaming", "NonProductive"),
    ("Amazon", "amazon.in", "Shopping", "NonProductive"),
    ("Flipkart", "flipkart.com", "Shopping", "NonProductive"),
    ("Myntra", "myntra.com", "Shopping", "NonProductive"),
    ("Swiggy", "swiggy.com", "Food Delivery", "NonProductive"),
    ("Zomato", "zomato.com", "Food Delivery", "NonProductive"),
    ("Times of India", "timesofindia.com", "News", "NonProductive"),
    ("9GAG", "9gag.com", "Entertainment", "NonProductive"),
]

_BY_NAME = {name.lower(): (name, url, category, prod) for name, url, category, prod in APP_CATALOG}

PRODUCTIVE_APPS = [row for row in APP_CATALOG if row[3] == "Productive"]
NONPRODUCTIVE_APPS = [row for row in APP_CATALOG if row[3] == "NonProductive"]


def classify(app_name: str) -> tuple[str, str]:
    """Return (category, productivity) for an app name.

    Unknown apps default to Other/Productive rather than penalising the user
    for software the catalogue has not been taught about yet.
    """
    entry = _BY_NAME.get(app_name.lower().strip())
    if entry:
        return entry[2], entry[3]
    return "Other", "Productive"


def default_url(app_name: str) -> str | None:
    entry = _BY_NAME.get(app_name.lower().strip())
    return entry[1] if entry else None

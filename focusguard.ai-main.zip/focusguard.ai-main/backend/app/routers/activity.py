"""Activity Tracking + Activity Log Management routes."""
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import case, func
from sqlalchemy.orm import Session

from ..core.catalog import classify, default_url
from ..core.database import get_db
from ..models import ActivityLog, User
from ..schemas import (
    ActivityLogCreate,
    ActivityLogOut,
    ActivityPage,
    DailySummary,
    TopApp,
)
from .auth import get_current_user

router = APIRouter(prefix="/activity", tags=["activity"])

# Reused by both aggregate endpoints so Productive/NonProductive splits are
# always defined identically.
_PRODUCTIVE_SECS = func.sum(
    case((ActivityLog.productivity == "Productive", ActivityLog.duration_seconds), else_=0)
)
_NONPRODUCTIVE_SECS = func.sum(
    case((ActivityLog.productivity == "NonProductive", ActivityLog.duration_seconds), else_=0)
)


def _build_log(user: User, payload: ActivityLogCreate) -> ActivityLog:
    category, productivity = classify(payload.app_name)
    return ActivityLog(
        user_id=user.id,
        user_type=user.user_type,
        app_name=payload.app_name.strip(),
        url=payload.url or default_url(payload.app_name),
        category=payload.category or category,
        opened_at=payload.opened_at,
        closed_at=payload.closed_at,
        # Derived server-side — the client never sets duration directly.
        duration_seconds=int((payload.closed_at - payload.opened_at).total_seconds()),
        productivity=payload.productivity or productivity,
        tab_switch_count=payload.tab_switch_count,
        device=payload.device,
        session_id=payload.session_id,
    )


@router.post("/logs", response_model=ActivityLogOut, status_code=status.HTTP_201_CREATED)
def create_log(
    payload: ActivityLogCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    log = _build_log(current_user, payload)
    db.add(log)
    db.commit()
    db.refresh(log)
    return log


@router.post("/logs/bulk", response_model=dict, status_code=status.HTTP_201_CREATED)
def create_logs_bulk(
    payloads: list[ActivityLogCreate],
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Batch ingestion endpoint for the desktop/mobile tracker agent.

    Trackers buffer events offline, so they arrive in bursts rather than one
    request per visit.
    """
    if not payloads:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="No records supplied."
        )
    if len(payloads) > 5000:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail="Send at most 5000 records per batch.",
        )

    db.add_all([_build_log(current_user, p) for p in payloads])
    db.commit()
    return {"inserted": len(payloads)}


@router.get("/logs", response_model=ActivityPage)
def list_logs(
    start: datetime | None = None,
    end: datetime | None = None,
    app_name: str | None = None,
    productivity: str | None = Query(None, pattern="^(Productive|NonProductive)$"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Activity Log Management — paginated, filterable history."""
    query = db.query(ActivityLog).filter(ActivityLog.user_id == current_user.id)

    if start:
        query = query.filter(ActivityLog.opened_at >= start)
    if end:
        query = query.filter(ActivityLog.opened_at <= end)
    if app_name:
        query = query.filter(ActivityLog.app_name.ilike(f"%{app_name}%"))
    if productivity:
        query = query.filter(ActivityLog.productivity == productivity)

    total = query.count()
    items = (
        query.order_by(ActivityLog.opened_at.desc()).offset(offset).limit(limit).all()
    )
    return ActivityPage(total=total, limit=limit, offset=offset, items=items)


@router.get("/summary/daily", response_model=list[DailySummary])
def daily_summary(
    days: int = Query(14, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Screen Time Tracking rolled up per day — raw inputs for Weeks 3-4."""
    since = datetime.utcnow() - timedelta(days=days)
    day = func.date(ActivityLog.opened_at).label("day")

    rows = (
        db.query(
            day,
            func.sum(ActivityLog.duration_seconds).label("total_seconds"),
            _PRODUCTIVE_SECS.label("productive_seconds"),
            _NONPRODUCTIVE_SECS.label("nonproductive_seconds"),
            func.sum(ActivityLog.tab_switch_count).label("tab_switches"),
            func.count(ActivityLog.id).label("activity_count"),
        )
        .filter(ActivityLog.user_id == current_user.id, ActivityLog.opened_at >= since)
        .group_by(day)
        .order_by(day)
        .all()
    )

    return [
        DailySummary(
            day=r.day if isinstance(r.day, date) else date.fromisoformat(str(r.day)),
            total_seconds=int(r.total_seconds or 0),
            productive_seconds=int(r.productive_seconds or 0),
            nonproductive_seconds=int(r.nonproductive_seconds or 0),
            productive_ratio=round((r.productive_seconds or 0) / r.total_seconds, 4)
            if r.total_seconds
            else 0.0,
            tab_switches=int(r.tab_switches or 0),
            activity_count=int(r.activity_count or 0),
        )
        for r in rows
    ]


@router.get("/summary/top-apps", response_model=list[TopApp])
def top_apps(
    days: int = Query(7, ge=1, le=365),
    limit: int = Query(10, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Application Usage Monitoring — where the time actually went."""
    since = datetime.utcnow() - timedelta(days=days)
    total = func.sum(ActivityLog.duration_seconds).label("total_seconds")

    rows = (
        db.query(
            ActivityLog.app_name,
            ActivityLog.productivity,
            total,
            func.count(ActivityLog.id).label("visits"),
            func.sum(ActivityLog.tab_switch_count).label("tab_switches"),
        )
        .filter(ActivityLog.user_id == current_user.id, ActivityLog.opened_at >= since)
        .group_by(ActivityLog.app_name, ActivityLog.productivity)
        .order_by(total.desc())
        .limit(limit)
        .all()
    )

    return [
        TopApp(
            app_name=r.app_name,
            productivity=r.productivity,
            total_seconds=int(r.total_seconds or 0),
            visits=int(r.visits or 0),
            tab_switches=int(r.tab_switches or 0),
        )
        for r in rows
    ]

"""Focus Session Recording routes."""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..core.database import get_db
from ..models import FocusSession, User
from ..schemas import FocusSessionEnd, FocusSessionOut, FocusSessionStart
from .auth import get_current_user

router = APIRouter(prefix="/sessions", tags=["focus-sessions"])


@router.post("/start", response_model=FocusSessionOut, status_code=status.HTTP_201_CREATED)
def start_session(
    payload: FocusSessionStart,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # A user can only be in one focus session at a time; overlapping sessions
    # would double-count screen time in every downstream aggregate.
    open_session = (
        db.query(FocusSession)
        .filter(FocusSession.user_id == current_user.id, FocusSession.ended_at.is_(None))
        .first()
    )
    if open_session:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Focus session {open_session.id} is still running.",
        )

    session = FocusSession(
        user_id=current_user.id,
        label=payload.label,
        planned_minutes=payload.planned_minutes,
        started_at=datetime.utcnow(),
    )
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


@router.post("/{session_id}/end", response_model=FocusSessionOut)
def end_session(
    session_id: int,
    payload: FocusSessionEnd,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    session = (
        db.query(FocusSession)
        .filter(FocusSession.id == session_id, FocusSession.user_id == current_user.id)
        .first()
    )
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Session not found."
        )
    if session.ended_at:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail="Session already ended."
        )

    session.ended_at = datetime.utcnow()
    session.actual_seconds = int((session.ended_at - session.started_at).total_seconds())
    session.interruption_count = payload.interruption_count
    session.tab_switch_count = payload.tab_switch_count
    session.completed = session.actual_seconds >= session.planned_minutes * 60

    db.commit()
    db.refresh(session)
    return session


@router.get("", response_model=list[FocusSessionOut])
def list_sessions(
    limit: int = 50,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return (
        db.query(FocusSession)
        .filter(FocusSession.user_id == current_user.id)
        .order_by(FocusSession.started_at.desc())
        .limit(min(limit, 200))
        .all()
    )


@router.get("/active", response_model=FocusSessionOut | None)
def active_session(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return (
        db.query(FocusSession)
        .filter(FocusSession.user_id == current_user.id, FocusSession.ended_at.is_(None))
        .first()
    )

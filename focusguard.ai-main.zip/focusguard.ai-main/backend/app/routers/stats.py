"""Device Usage Statistics + Historical Data Storage routes."""
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, Query
from sqlalchemy import case, func
from sqlalchemy.orm import Session

from ..core.database import get_db
from ..models import ActivityLog, DeviceUsageStat, FocusSession, NotificationEvent, User
from ..schemas import DeviceUsageStatOut
from .auth import get_current_user

router = APIRouter(prefix="/stats", tags=["stats"])


@router.post("/rebuild", response_model=dict)
def rebuild_device_stats(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Recompute the per-day/per-device rollup from raw activity logs.

    Kept as an explicit job rather than a trigger: ingestion is bursty, and
    recomputing a whole day on every inserted row would dominate write cost.
    """
    since = datetime.utcnow() - timedelta(days=days)
    day = func.date(ActivityLog.opened_at).label("day")

    rows = (
        db.query(
            day,
            ActivityLog.device,
            func.sum(ActivityLog.duration_seconds).label("total_seconds"),
            func.sum(
                case(
                    (ActivityLog.productivity == "Productive", ActivityLog.duration_seconds),
                    else_=0,
                )
            ).label("productive_seconds"),
            func.sum(
                case(
                    (
                        ActivityLog.productivity == "NonProductive",
                        ActivityLog.duration_seconds,
                    ),
                    else_=0,
                )
            ).label("nonproductive_seconds"),
            func.sum(ActivityLog.tab_switch_count).label("app_switch_count"),
            func.count(ActivityLog.id).label("unlock_count"),
        )
        .filter(ActivityLog.user_id == current_user.id, ActivityLog.opened_at >= since)
        .group_by(day, ActivityLog.device)
        .all()
    )

    written = 0
    for r in rows:
        stat_date = r.day if isinstance(r.day, date) else date.fromisoformat(str(r.day))
        stat = (
            db.query(DeviceUsageStat)
            .filter(
                DeviceUsageStat.user_id == current_user.id,
                DeviceUsageStat.stat_date == stat_date,
                DeviceUsageStat.device == r.device,
            )
            .first()
        )
        if not stat:
            stat = DeviceUsageStat(
                user_id=current_user.id, stat_date=stat_date, device=r.device
            )
            db.add(stat)

        stat.total_screen_seconds = int(r.total_seconds or 0)
        stat.productive_seconds = int(r.productive_seconds or 0)
        stat.nonproductive_seconds = int(r.nonproductive_seconds or 0)
        stat.app_switch_count = int(r.app_switch_count or 0)
        stat.unlock_count = int(r.unlock_count or 0)
        written += 1

    db.commit()
    return {"rows_written": written, "days": days}


@router.get("/devices", response_model=list[DeviceUsageStatOut])
def device_stats(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    since = date.today() - timedelta(days=days)
    return (
        db.query(DeviceUsageStat)
        .filter(
            DeviceUsageStat.user_id == current_user.id,
            DeviceUsageStat.stat_date >= since,
        )
        .order_by(DeviceUsageStat.stat_date.desc())
        .all()
    )


@router.get("/overview", response_model=dict)
def overview(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Data Repository snapshot — what has been collected for this user so far."""
    since = datetime.utcnow() - timedelta(days=days)
    base = db.query(ActivityLog).filter(
        ActivityLog.user_id == current_user.id, ActivityLog.opened_at >= since
    )

    totals = base.with_entities(
        func.count(ActivityLog.id),
        func.coalesce(func.sum(ActivityLog.duration_seconds), 0),
        func.coalesce(func.sum(ActivityLog.tab_switch_count), 0),
        func.coalesce(
            func.sum(
                case(
                    (ActivityLog.productivity == "Productive", ActivityLog.duration_seconds),
                    else_=0,
                )
            ),
            0,
        ),
    ).one()
    activity_count, total_seconds, tab_switches, productive_seconds = totals

    session_count = (
        db.query(func.count(FocusSession.id))
        .filter(FocusSession.user_id == current_user.id, FocusSession.started_at >= since)
        .scalar()
    )
    notification_count = (
        db.query(func.count(NotificationEvent.id))
        .filter(
            NotificationEvent.user_id == current_user.id,
            NotificationEvent.received_at >= since,
        )
        .scalar()
    )

    return {
        "window_days": days,
        "activity_count": int(activity_count),
        "total_screen_seconds": int(total_seconds),
        "total_screen_hours": round(int(total_seconds) / 3600, 2),
        "productive_seconds": int(productive_seconds),
        "productive_ratio": round(int(productive_seconds) / int(total_seconds), 4)
        if total_seconds
        else 0.0,
        "tab_switches": int(tab_switches),
        "focus_sessions": int(session_count or 0),
        "notifications": int(notification_count or 0),
    }

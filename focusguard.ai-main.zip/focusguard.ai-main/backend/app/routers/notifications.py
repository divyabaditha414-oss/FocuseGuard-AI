"""Notification Activity Tracking routes."""
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy import case, func
from sqlalchemy.orm import Session

from ..core.database import get_db
from ..models import NotificationEvent, User
from ..schemas import NotificationCreate, NotificationOut
from .auth import get_current_user

router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.post("", response_model=NotificationOut, status_code=status.HTTP_201_CREATED)
def record_notification(
    payload: NotificationCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    event = NotificationEvent(user_id=current_user.id, **payload.model_dump())
    db.add(event)
    db.commit()
    db.refresh(event)
    return event


@router.get("", response_model=list[NotificationOut])
def list_notifications(
    days: int = Query(7, ge=1, le=365),
    limit: int = Query(100, ge=1, le=1000),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    since = datetime.utcnow() - timedelta(days=days)
    return (
        db.query(NotificationEvent)
        .filter(
            NotificationEvent.user_id == current_user.id,
            NotificationEvent.received_at >= since,
        )
        .order_by(NotificationEvent.received_at.desc())
        .limit(limit)
        .all()
    )


@router.get("/by-app", response_model=list[dict])
def notifications_by_app(
    days: int = Query(7, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Which apps interrupt this user most — input to Weeks 3-4 impact scoring."""
    since = datetime.utcnow() - timedelta(days=days)
    count = func.count(NotificationEvent.id).label("count")

    rows = (
        db.query(
            NotificationEvent.source_app,
            count,
            func.sum(
                case((NotificationEvent.session_id.isnot(None), 1), else_=0)
            ).label("during_focus"),
        )
        .filter(
            NotificationEvent.user_id == current_user.id,
            NotificationEvent.received_at >= since,
        )
        .group_by(NotificationEvent.source_app)
        .order_by(count.desc())
        .all()
    )
    return [
        {
            "source_app": r.source_app,
            "count": int(r.count or 0),
            "during_focus": int(r.during_focus or 0),
        }
        for r in rows
    ]

"""Profile Management routes."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..core.database import get_db
from ..models import User, UserProfile
from ..schemas import ProfileOut, ProfileUpdate, UserOut
from .auth import get_current_user

router = APIRouter(prefix="/users", tags=["users"])


def _get_or_create_profile(db: Session, user_id: int) -> UserProfile:
    """Users registered before profiles existed have no row yet."""
    profile = db.query(UserProfile).filter(UserProfile.user_id == user_id).first()
    if not profile:
        profile = UserProfile(user_id=user_id)
        db.add(profile)
        db.commit()
        db.refresh(profile)
    return profile


@router.get("/me/profile", response_model=ProfileOut)
def get_profile(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return _get_or_create_profile(db, current_user.id)


@router.put("/me/profile", response_model=ProfileOut)
def update_profile(
    payload: ProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    profile = _get_or_create_profile(db, current_user.id)

    updates = payload.model_dump(exclude_unset=True)
    for field, value in updates.items():
        setattr(profile, field, value)

    if profile.work_end_hour <= profile.work_start_hour:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="work_end_hour must be later than work_start_hour.",
        )

    db.commit()
    db.refresh(profile)
    return profile


@router.get("", response_model=list[UserOut])
def list_users(
    limit: int = 50,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Admin-only user listing (feeds the Week 7-8 admin portal)."""
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Admin access required."
        )
    return db.query(User).order_by(User.id).limit(min(limit, 200)).all()

"""Weeks 5-6 routes: recommendations, smart planner, goal management,
notification intelligence and weekly reporting."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..analytics.features import DailyFeatures, extract_daily_features
from ..analytics.insights import identify_attention_leaks
from ..coaching.alerts import generate_alerts, persist_alerts
from ..coaching.habits import (
    persist_goal_progress,
    suggest_goal_adjustments,
    track_goals,
)
from ..coaching.planner import build_daily_plan, prioritise_goals
from ..coaching.recommendations import (
    generate_recommendations,
    persist_recommendations,
)
from ..coaching.reports import (
    goal_achievement_summary,
    improvement_trends,
    weekly_report,
)
from ..core.database import get_db
from ..models import Recommendation, User
from ..schemas import (
    AlertOut,
    CoachingDashboard,
    DailyPlanOut,
    GoalTrackingOut,
    RecommendationOut,
    RecommendationStatusUpdate,
)
from .auth import get_current_user

router = APIRouter(prefix="/coaching", tags=["coaching"])


def _load(db: Session, user_id: int, days: int) -> list[DailyFeatures]:
    return extract_daily_features(db, user_id, days=days)


def _require_data(features: list[DailyFeatures]) -> None:
    if not features:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No activity recorded in this window — nothing to coach on.",
        )


def _plan(db: Session, user_id: int, features: list[DailyFeatures]) -> dict:
    plan = build_daily_plan(db, user_id, features)
    plan["task_priorities"] = prioritise_goals(db, user_id, plan)
    return plan


# --- Recommendation Engine -----------------------------------------------


@router.get("/recommendations", response_model=list[RecommendationOut])
def recommendations(
    days: int = Query(30, ge=1, le=365),
    category: str | None = Query(
        None,
        pattern="^(focus_improvement|productivity_tip|attention_recovery|work_pattern)$",
    ),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Ranked, evidence-backed suggestions. Dismissed ones are not re-shown."""
    features = _load(db, current_user.id, days)
    leaks = identify_attention_leaks(db, current_user.id, features, days)
    recos = generate_recommendations(db, current_user.id, features, leaks, days)
    if category:
        recos = [r for r in recos if r["category"] == category]
    return [RecommendationOut(**r) for r in recos]


@router.patch("/recommendations/{key}", response_model=RecommendationOut)
def update_recommendation(
    key: str,
    payload: RecommendationStatusUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Accept, dismiss or complete a recommendation.

    Self-sufficient: the read endpoints generate recommendations without
    persisting them, so a user can dismiss something that has no row yet. In
    that case the current set is materialised first rather than returning a 404
    the caller cannot act on.
    """
    row = (
        db.query(Recommendation)
        .filter(Recommendation.user_id == current_user.id, Recommendation.key == key)
        .order_by(Recommendation.generated_date.desc())
        .first()
    )

    if not row:
        features = _load(db, current_user.id, days=30)
        leaks = identify_attention_leaks(db, current_user.id, features, 30)
        current = generate_recommendations(db, current_user.id, features, leaks, 30)
        if any(r["key"] == key for r in current):
            persist_recommendations(db, current_user.id, current)
            row = (
                db.query(Recommendation)
                .filter(
                    Recommendation.user_id == current_user.id,
                    Recommendation.key == key,
                )
                .order_by(Recommendation.generated_date.desc())
                .first()
            )

    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No recommendation with key '{key}' for this user.",
        )

    row.status = payload.status
    db.commit()
    db.refresh(row)
    return RecommendationOut(
        key=row.key,
        category=row.category,
        title=row.title,
        action=row.action,
        rationale=row.rationale,
        expected_gain_minutes=row.expected_gain_minutes,
        confidence=row.confidence,
        priority=row.priority,
        evidence=row.evidence,
        status=row.status,
    )


# --- Smart Focus Planner --------------------------------------------------


@router.get("/plan", response_model=DailyPlanOut)
def daily_plan(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Tomorrow's focus blocks, breaks and task priorities."""
    features = _load(db, current_user.id, days)
    _require_data(features)
    return DailyPlanOut(**_plan(db, current_user.id, features))


@router.get("/high-focus-hours", response_model=list[dict])
def focus_hours(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """The clock hours where this user is measurably most productive."""
    from ..coaching.planner import high_focus_hours

    return high_focus_hours(_load(db, current_user.id, days))


# --- Goal Management ------------------------------------------------------


@router.get("/goals", response_model=list[GoalTrackingOut])
def goal_tracking(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Per-goal progress, streaks and habit-formation stage."""
    features = _load(db, current_user.id, days)
    return [GoalTrackingOut(**g) for g in track_goals(db, current_user.id, features)]


@router.get("/goals/adjustments", response_model=list[dict])
def goal_adjustments(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Goals that look mis-set — unreachable, or no longer a stretch."""
    features = _load(db, current_user.id, days)
    return suggest_goal_adjustments(track_goals(db, current_user.id, features))


# --- Notification Intelligence -------------------------------------------


@router.get("/alerts", response_model=list[AlertOut])
def alerts(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Smart reminders, session nudges and distraction warnings, capped per day."""
    features = _load(db, current_user.id, days)
    tracked = track_goals(db, current_user.id, features)
    return [
        AlertOut(**a) for a in generate_alerts(db, current_user.id, features, tracked)
    ]


# --- Reporting ------------------------------------------------------------


@router.get("/reports/weekly", response_model=dict)
def weekly(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """This week against last week across every headline metric."""
    return weekly_report(_load(db, current_user.id, days))


@router.get("/reports/trends", response_model=dict)
def trends(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Attention improvement trends and the metrics moving most."""
    return improvement_trends(_load(db, current_user.id, days))


# --- Dashboard + persistence ---------------------------------------------


@router.get("/dashboard", response_model=CoachingDashboard)
def dashboard(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Everything the coaching UI needs in one round trip."""
    features = _load(db, current_user.id, days)
    _require_data(features)

    leaks = identify_attention_leaks(db, current_user.id, features, days)
    tracked = track_goals(db, current_user.id, features)

    return CoachingDashboard(
        user_id=current_user.id,
        window_days=days,
        days_analysed=len(features),
        plan=DailyPlanOut(**_plan(db, current_user.id, features)),
        recommendations=[
            RecommendationOut(**r)
            for r in generate_recommendations(db, current_user.id, features, leaks, days)
        ],
        goals=[GoalTrackingOut(**g) for g in tracked],
        goal_summary=goal_achievement_summary(tracked),
        goal_adjustments=suggest_goal_adjustments(tracked),
        alerts=[
            AlertOut(**a)
            for a in generate_alerts(db, current_user.id, features, tracked)
        ],
        weekly_report=weekly_report(features),
        improvement_trends=improvement_trends(features),
    )


@router.post("/compute", response_model=dict)
def compute_and_store(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Persist recommendations, goal progress and alerts.

    Recommendation `status` set by the user is preserved across runs — a
    dismissal that evaporated on the next compute would be worse than useless.
    """
    features = _load(db, current_user.id, days)
    _require_data(features)

    leaks = identify_attention_leaks(db, current_user.id, features, days)
    recos = generate_recommendations(db, current_user.id, features, leaks, days)
    tracked = track_goals(db, current_user.id, features)
    alerts_generated = generate_alerts(db, current_user.id, features, tracked)

    return {
        "days_analysed": len(features),
        "recommendations_written": persist_recommendations(db, current_user.id, recos),
        "goal_progress_rows": persist_goal_progress(db, current_user.id, features),
        "alerts_written": persist_alerts(db, current_user.id, alerts_generated),
        "generated_on": date.today().isoformat(),
    }

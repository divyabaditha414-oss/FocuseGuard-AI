"""Weeks 3-4 routes: attention analysis, distraction detection, scoring,
predictive analytics and insight generation."""
from __future__ import annotations

import statistics
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..analytics.distraction import (
    context_switching_analysis,
    focus_loss_identification,
    frequent_interruption_detection,
    notification_impact_assessment,
)
from ..analytics.features import DailyFeatures, extract_daily_features
from ..analytics.insights import generate_insights, identify_attention_leaks
from ..analytics.predictive import predict_all
from ..analytics.scoring import concentration_trend, focus_score, score_day
from ..core.database import get_db
from ..models import DailyScore, Goal, Insight, Prediction, User
from ..schemas import (
    AnalyticsDashboard,
    AttentionLeakOut,
    DailyScoreOut,
    InsightOut,
    PredictionOut,
    TrendOut,
)
from .auth import get_current_user

router = APIRouter(prefix="/analytics", tags=["analytics"])


def _deep_work_target(db: Session, user_id: int) -> int | None:
    """The user's own daily focus goal, in seconds, if they set one."""
    goal = (
        db.query(Goal)
        .filter(
            Goal.user_id == user_id,
            Goal.goal_type == "focus_minutes",
            Goal.status == "active",
        )
        .order_by(Goal.created_at.desc())
        .first()
    )
    return int(goal.target_value * 60) if goal else None


def _score_row(f: DailyFeatures, target: int | None) -> DailyScoreOut:
    scores = score_day(f, target)
    return DailyScoreOut(
        score_date=f.day,
        focus_score=scores["focus"].score,
        productivity_score=scores["productivity"].score,
        attention_stability_score=scores["attention_stability"].score,
        productive_ratio=round(f.productive_ratio, 4),
        total_seconds=f.total_seconds,
        deep_work_seconds=f.deep_work_seconds,
        longest_focus_seconds=f.longest_focus_seconds,
        switches_per_hour=round(f.switches_per_hour, 2),
        context_switches=f.context_switches,
        interruptions=f.notifications,
        components={k: v.components for k, v in scores.items()},
    )


def _load(db: Session, user_id: int, days: int) -> list[DailyFeatures]:
    return extract_daily_features(db, user_id, days=days)


def _require_data(features: list[DailyFeatures]) -> None:
    if not features:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No activity recorded in this window — nothing to analyse.",
        )


# --- Behavioural Analytics Engine ----------------------------------------


@router.get("/features", response_model=list[dict])
def daily_features(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Raw per-day behavioural feature vectors (the model's inputs)."""
    return [f.as_dict() for f in _load(db, current_user.id, days)]


@router.get("/scores", response_model=list[DailyScoreOut])
def daily_scores(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Daily focus, productivity and attention-stability scores."""
    features = _load(db, current_user.id, days)
    target = _deep_work_target(db, current_user.id)
    return [_score_row(f, target) for f in features]


@router.get("/trend", response_model=TrendOut)
def trend(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Concentration Trend Analysis over the window."""
    features = _load(db, current_user.id, days)
    return TrendOut(**concentration_trend([focus_score(f).score for f in features]))


# --- Distraction Detection System ----------------------------------------


@router.get("/distraction", response_model=dict)
def distraction_report(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """All four detectors in one response."""
    features = _load(db, current_user.id, days)
    _require_data(features)
    return {
        "window_days": days,
        "frequent_interruptions": frequent_interruption_detection(features),
        "context_switching": context_switching_analysis(db, current_user.id, features, days),
        "notification_impact": notification_impact_assessment(db, current_user.id, days),
        "focus_loss": focus_loss_identification(db, current_user.id, days),
    }


@router.get("/attention-leaks", response_model=list[AttentionLeakOut])
def attention_leaks(
    days: int = Query(30, ge=1, le=365),
    limit: int = Query(8, ge=1, le=50),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Attention Leak Identification — ranked by combined time and re-entry cost."""
    features = _load(db, current_user.id, days)
    return [
        AttentionLeakOut(**leak)
        for leak in identify_attention_leaks(db, current_user.id, features, days, limit)
    ]


# --- Predictive Analytics ------------------------------------------------


@router.get("/predictions", response_model=list[PredictionOut])
def predictions(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Focus degradation, productivity risk and attention fatigue."""
    features = _load(db, current_user.id, days)
    _require_data(features)
    return [PredictionOut(**vars(p)) for p in predict_all(features)]


# --- Insight Generation --------------------------------------------------


@router.get("/insights", response_model=list[InsightOut])
def insights(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Personalised, evidence-carrying findings, most severe first."""
    features = _load(db, current_user.id, days)
    return [InsightOut(**i) for i in generate_insights(db, current_user.id, features, days)]


# --- Dashboard + persistence ---------------------------------------------


@router.get("/dashboard", response_model=AnalyticsDashboard)
def dashboard(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Everything the analytics UI needs in one round trip."""
    features = _load(db, current_user.id, days)
    _require_data(features)

    target = _deep_work_target(db, current_user.id)
    history = [_score_row(f, target) for f in features]

    return AnalyticsDashboard(
        user_id=current_user.id,
        window_days=days,
        days_analysed=len(features),
        latest=history[-1],
        averages={
            "focus_score": round(statistics.fmean([h.focus_score for h in history]), 1),
            "productivity_score": round(
                statistics.fmean([h.productivity_score for h in history]), 1
            ),
            "attention_stability_score": round(
                statistics.fmean([h.attention_stability_score for h in history]), 1
            ),
            "productive_ratio": round(
                statistics.fmean([h.productive_ratio for h in history]), 4
            ),
        },
        trend=TrendOut(**concentration_trend([h.focus_score for h in history])),
        history=history,
        predictions=[PredictionOut(**vars(p)) for p in predict_all(features)],
        attention_leaks=[
            AttentionLeakOut(**leak)
            for leak in identify_attention_leaks(db, current_user.id, features, days)
        ],
        insights=[
            InsightOut(**i) for i in generate_insights(db, current_user.id, features, days)
        ],
    )


@router.post("/compute", response_model=dict)
def compute_and_store(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Persist scores, insights and predictions for this user.

    The read endpoints above compute on demand. This one materialises the
    results so the mobile app and weekly reports can read history cheaply
    without re-deriving weeks of features on every request.
    """
    features = _load(db, current_user.id, days)
    _require_data(features)
    target = _deep_work_target(db, current_user.id)

    scores_written = 0
    for f in features:
        row = _score_row(f, target)
        existing = (
            db.query(DailyScore)
            .filter(DailyScore.user_id == current_user.id, DailyScore.score_date == f.day)
            .first()
        )
        if not existing:
            existing = DailyScore(user_id=current_user.id, score_date=f.day)
            db.add(existing)

        existing.focus_score = row.focus_score
        existing.productivity_score = row.productivity_score
        existing.attention_stability_score = row.attention_stability_score
        existing.total_seconds = f.total_seconds
        existing.productive_seconds = f.productive_seconds
        existing.deep_work_seconds = f.deep_work_seconds
        existing.productive_ratio = round(f.productive_ratio, 4)
        existing.switches_per_hour = round(f.switches_per_hour, 2)
        existing.context_switches = f.context_switches
        existing.interruptions = f.notifications
        existing.longest_focus_seconds = f.longest_focus_seconds
        existing.components = row.components
        scores_written += 1

    # Insights are regenerated wholesale for the window: a stale insight is
    # worse than none, and they are cheap to rebuild.
    today = date.today()
    db.query(Insight).filter(
        Insight.user_id == current_user.id, Insight.insight_date == today
    ).delete(synchronize_session=False)

    generated = generate_insights(db, current_user.id, features, days)
    db.add_all(
        [
            Insight(
                user_id=current_user.id,
                insight_date=today,
                kind=i["kind"],
                severity=i["severity"],
                title=i["title"],
                message=i["message"],
                evidence=i["evidence"],
            )
            for i in generated
        ]
    )

    predictions_written = 0
    for p in predict_all(features):
        target_date_str = p.detail.get("target_date")
        target_date = date.fromisoformat(target_date_str) if target_date_str else today

        existing_pred = (
            db.query(Prediction)
            .filter(
                Prediction.user_id == current_user.id,
                Prediction.target_date == target_date,
                Prediction.kind == p.kind,
            )
            .first()
        )
        if not existing_pred:
            existing_pred = Prediction(
                user_id=current_user.id, target_date=target_date, kind=p.kind
            )
            db.add(existing_pred)

        existing_pred.predicted_value = p.predicted_value
        existing_pred.label = p.label
        existing_pred.confidence = p.confidence
        existing_pred.model_version = p.model_version
        predictions_written += 1

    db.commit()
    return {
        "days_analysed": len(features),
        "scores_written": scores_written,
        "insights_written": len(generated),
        "predictions_written": predictions_written,
    }


@router.get("/stored/scores", response_model=list[DailyScoreOut])
def stored_scores(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Read back what /analytics/compute persisted."""
    return (
        db.query(DailyScore)
        .filter(DailyScore.user_id == current_user.id)
        .order_by(DailyScore.score_date.desc())
        .limit(days)
        .all()
    )

"""Pydantic request/response schemas."""
from datetime import date, datetime
from typing import Literal, Optional

from pydantic import BaseModel, EmailStr, Field, model_validator

UserType = Literal["Student", "Professional", "Researcher", "Freelancer", "Educator"]
Productivity = Literal["Productive", "NonProductive"]


# --- Auth / users ---------------------------------------------------------
class UserRegister(BaseModel):
    username: str = Field(..., min_length=3, max_length=40, pattern=r"^[A-Za-z0-9_.]+$")
    first_name: str = Field(..., min_length=1, max_length=80)
    last_name: str = Field(..., min_length=1, max_length=80)
    email: EmailStr
    user_type: UserType = "Student"
    password: str = Field(..., min_length=8, max_length=128)


class UserLogin(BaseModel):
    # Accepts either an email address or a username.
    identifier: str = Field(..., min_length=1)
    password: str


class UserOut(BaseModel):
    id: int
    username: str
    first_name: str
    last_name: str
    email: EmailStr
    user_type: str
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# --- Profile --------------------------------------------------------------
class ProfileUpdate(BaseModel):
    occupation: Optional[str] = Field(None, max_length=120)
    organization: Optional[str] = Field(None, max_length=120)
    timezone: Optional[str] = Field(None, max_length=64)
    work_start_hour: Optional[int] = Field(None, ge=0, le=23)
    work_end_hour: Optional[int] = Field(None, ge=0, le=23)
    bio: Optional[str] = None


class ProfileOut(BaseModel):
    user_id: int
    occupation: Optional[str] = None
    organization: Optional[str] = None
    timezone: str
    work_start_hour: int
    work_end_hour: int
    bio: Optional[str] = None
    updated_at: datetime

    class Config:
        from_attributes = True


# --- Goals ----------------------------------------------------------------
GoalType = Literal["focus_minutes", "productive_ratio", "max_tab_switches", "max_screen_time"]


class GoalCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=160)
    goal_type: GoalType
    target_value: float = Field(..., gt=0)
    unit: str = Field("minutes", max_length=20)
    period: Literal["daily", "weekly"] = "daily"
    start_date: date
    end_date: Optional[date] = None

    @model_validator(mode="after")
    def _end_after_start(self):
        if self.end_date and self.end_date < self.start_date:
            raise ValueError("end_date must be on or after start_date")
        return self


class GoalUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=160)
    target_value: Optional[float] = Field(None, gt=0)
    period: Optional[Literal["daily", "weekly"]] = None
    end_date: Optional[date] = None
    status: Optional[Literal["active", "paused", "done"]] = None


class GoalOut(BaseModel):
    id: int
    user_id: int
    title: str
    goal_type: str
    target_value: float
    unit: str
    period: str
    start_date: date
    end_date: Optional[date] = None
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


# --- Activity logs --------------------------------------------------------
class ActivityLogCreate(BaseModel):
    """Ingestion payload from the tracker agent.

    duration_seconds is derived server-side from closed_at - opened_at so the
    stored value can never disagree with the timestamps.
    """

    app_name: str = Field(..., min_length=1, max_length=120)
    url: Optional[str] = Field(None, max_length=255)
    category: Optional[str] = Field(None, max_length=60)
    opened_at: datetime
    closed_at: datetime
    productivity: Optional[Productivity] = None
    tab_switch_count: int = Field(0, ge=0)
    device: str = Field("Desktop", max_length=40)
    session_id: Optional[int] = None

    @model_validator(mode="after")
    def _closed_after_opened(self):
        if self.closed_at <= self.opened_at:
            raise ValueError("closed_at must be after opened_at")
        return self


class ActivityLogOut(BaseModel):
    id: int
    user_id: int
    user_type: str
    app_name: str
    url: Optional[str] = None
    category: str
    opened_at: datetime
    closed_at: datetime
    duration_seconds: int
    duration_minutes: float
    productivity: str
    tab_switch_count: int
    device: str
    session_id: Optional[int] = None

    class Config:
        from_attributes = True


class ActivityPage(BaseModel):
    total: int
    limit: int
    offset: int
    items: list[ActivityLogOut]


# --- Focus sessions -------------------------------------------------------
class FocusSessionStart(BaseModel):
    label: Optional[str] = Field(None, max_length=160)
    planned_minutes: int = Field(25, ge=1, le=480)


class FocusSessionEnd(BaseModel):
    interruption_count: int = Field(0, ge=0)
    tab_switch_count: int = Field(0, ge=0)


class FocusSessionOut(BaseModel):
    id: int
    user_id: int
    label: Optional[str] = None
    started_at: datetime
    ended_at: Optional[datetime] = None
    planned_minutes: int
    actual_seconds: int
    interruption_count: int
    tab_switch_count: int
    completed: bool

    class Config:
        from_attributes = True


# --- Notifications --------------------------------------------------------
class NotificationCreate(BaseModel):
    source_app: str = Field(..., min_length=1, max_length=120)
    received_at: datetime
    acknowledged_at: Optional[datetime] = None
    was_dismissed: bool = False
    session_id: Optional[int] = None


class NotificationOut(BaseModel):
    id: int
    user_id: int
    source_app: str
    received_at: datetime
    acknowledged_at: Optional[datetime] = None
    was_dismissed: bool
    session_id: Optional[int] = None

    class Config:
        from_attributes = True


# --- Device stats / summaries --------------------------------------------
class DeviceUsageStatOut(BaseModel):
    stat_date: date
    device: str
    total_screen_seconds: int
    productive_seconds: int
    nonproductive_seconds: int
    app_switch_count: int
    unlock_count: int

    class Config:
        from_attributes = True


class DailySummary(BaseModel):
    """Raw daily aggregates. Weeks 3-4 turn these into focus scores."""

    day: date
    total_seconds: int
    productive_seconds: int
    nonproductive_seconds: int
    productive_ratio: float
    tab_switches: int
    activity_count: int


class TopApp(BaseModel):
    app_name: str
    productivity: str
    total_seconds: int
    visits: int
    tab_switches: int


# --- Weeks 3-4: analytics -------------------------------------------------
class ScoreComponent(BaseModel):
    score: float
    components: dict[str, float]


class DailyScoreOut(BaseModel):
    score_date: date
    focus_score: float
    productivity_score: float
    attention_stability_score: float
    productive_ratio: float
    total_seconds: int
    deep_work_seconds: int
    longest_focus_seconds: int
    switches_per_hour: float
    context_switches: int
    interruptions: int
    components: dict

    class Config:
        from_attributes = True


class TrendOut(BaseModel):
    direction: str
    slope_per_day: float
    recent_avg: float
    previous_avg: float
    change: float
    days_scored: int


class InsightOut(BaseModel):
    kind: str
    severity: str
    title: str
    message: str
    evidence: dict


class PredictionOut(BaseModel):
    kind: str
    predicted_value: float
    label: str
    confidence: float
    # "heuristic" when no trained artifact was loaded — surfaced so a fallback
    # is never mistaken for model output.
    model_version: str
    detail: dict


class AttentionLeakOut(BaseModel):
    app_name: str
    category: str
    total_seconds: int
    minutes_per_day: float
    visits_per_day: float
    tab_switches: int
    times_broke_focus: int
    leak_score: float


# --- Weeks 5-6: coaching --------------------------------------------------
class RecommendationOut(BaseModel):
    key: str
    category: str
    title: str
    action: str
    rationale: str
    expected_gain_minutes: float
    confidence: float
    priority: float
    evidence: dict
    status: str = "suggested"

    class Config:
        from_attributes = True


class RecommendationStatusUpdate(BaseModel):
    status: Literal["suggested", "accepted", "dismissed", "completed"]


class PlanBlock(BaseModel):
    kind: str
    start: str
    end: str
    minutes: int
    expected_productive_ratio: Optional[float] = None


class DailyPlanOut(BaseModel):
    date: str
    blocks: list[PlanBlock]
    total_focus_minutes: int = 0
    session: dict
    rhythm: dict
    high_focus_hours: list[dict] = []
    task_priorities: list[dict] = []
    note: Optional[str] = None


class GoalTrackingOut(BaseModel):
    goal_id: int
    title: str
    goal_type: str
    period: str
    target_value: float
    unit: str
    status: str
    days_tracked: int
    days_met: int
    consistency: float
    current_streak: int
    longest_streak: int
    avg_attainment: float
    recent_avg_attainment: float
    habit_stage: str
    on_track: bool
    daily: list[dict]


class AlertOut(BaseModel):
    kind: str
    severity: str
    title: str
    message: str
    scheduled_for: datetime
    evidence: dict

    class Config:
        from_attributes = True


class CoachingDashboard(BaseModel):
    """Everything the Weeks 5-6 coaching UI needs in one round trip."""

    user_id: int
    window_days: int
    days_analysed: int
    plan: DailyPlanOut
    recommendations: list[RecommendationOut]
    goals: list[GoalTrackingOut]
    goal_summary: dict
    goal_adjustments: list[dict]
    alerts: list[AlertOut]
    weekly_report: dict
    improvement_trends: dict


class AnalyticsDashboard(BaseModel):
    """Everything the Weeks 3-4 dashboard needs in a single round trip."""

    user_id: int
    window_days: int
    days_analysed: int
    latest: Optional[DailyScoreOut] = None
    averages: dict[str, float]
    trend: TrendOut
    history: list[DailyScoreOut]
    predictions: list[PredictionOut]
    attention_leaks: list[AttentionLeakOut]
    insights: list[InsightOut]

"""SQLAlchemy ORM models — Weeks 1-2 data repository.

Covers User Management, Activity Tracking, the Data Collection Framework and
the Data Repository described in the project plan. Weeks 3-4 (AI scoring) read
from these tables; nothing here computes scores.
"""
from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship

from .core.database import Base


class User(Base):
    """Registered platform user (Weeks 1-2: User Management)."""

    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(40), unique=True, index=True, nullable=False)
    first_name = Column(String(80), nullable=False)
    last_name = Column(String(80), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    # user_type drives the "UserType" column on every activity row.
    user_type = Column(String(40), nullable=False, default="Student")
    role = Column(String(40), nullable=False, default="user")  # user | admin
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    profile = relationship(
        "UserProfile", back_populates="user", uselist=False, cascade="all, delete-orphan"
    )
    goals = relationship("Goal", back_populates="user", cascade="all, delete-orphan")
    activity_logs = relationship(
        "ActivityLog", back_populates="user", cascade="all, delete-orphan"
    )
    focus_sessions = relationship(
        "FocusSession", back_populates="user", cascade="all, delete-orphan"
    )


class UserProfile(Base):
    """Profile Management — editable details kept out of the auth table."""

    __tablename__ = "user_profiles"

    id = Column(Integer, primary_key=True)
    user_id = Column(
        Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    occupation = Column(String(120))
    organization = Column(String(120))
    timezone = Column(String(64), nullable=False, default="Asia/Kolkata")
    # Work window used later to label "high focus time".
    work_start_hour = Column(Integer, nullable=False, default=9)
    work_end_hour = Column(Integer, nullable=False, default=18)
    bio = Column(Text)
    updated_at = Column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    user = relationship("User", back_populates="profile")


class Goal(Base):
    """Goal Configuration — targets the user sets for themselves."""

    __tablename__ = "goals"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(160), nullable=False)
    # focus_minutes | productive_ratio | max_tab_switches | max_screen_time
    goal_type = Column(String(40), nullable=False)
    target_value = Column(Float, nullable=False)
    unit = Column(String(20), nullable=False, default="minutes")
    period = Column(String(20), nullable=False, default="daily")  # daily | weekly
    start_date = Column(Date, nullable=False)
    end_date = Column(Date)
    status = Column(String(20), nullable=False, default="active")  # active | paused | done
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship("User", back_populates="goals")


class Application(Base):
    """Catalogue of apps/websites and their default productivity label.

    Keeps the Productive/NonProductive classification in one place so activity
    rows stay consistent and the label can be retuned without a data migration.
    """

    __tablename__ = "applications"
    __table_args__ = (UniqueConstraint("name", name="uq_applications_name"),)

    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False, index=True)
    url = Column(String(255))
    category = Column(String(60), nullable=False, default="Other")
    default_productivity = Column(String(20), nullable=False, default="Productive")


class ActivityLog(Base):
    """One app/website visit — the core Activity Tracking record.

    Mirrors the required dataset columns:
        UserType | App/Website Name | URL | OpenedDateTime | ClosedTime |
        Duration (Closed-Opened) | Productive/NonProductive | tab switches
    """

    __tablename__ = "activity_logs"
    __table_args__ = (
        Index("ix_activity_user_opened", "user_id", "opened_at"),
        Index("ix_activity_productivity", "productivity"),
    )

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    # Denormalised so an exported activity row is self-describing.
    user_type = Column(String(40), nullable=False, default="Student")
    app_name = Column(String(120), nullable=False, index=True)
    url = Column(String(255))
    category = Column(String(60), nullable=False, default="Other")
    opened_at = Column(DateTime, nullable=False, index=True)
    closed_at = Column(DateTime, nullable=False)
    # Stored rather than computed: it is queried far more often than written.
    duration_seconds = Column(Integer, nullable=False)
    productivity = Column(String(20), nullable=False, default="Productive")
    tab_switch_count = Column(Integer, nullable=False, default=0)
    device = Column(String(40), nullable=False, default="Desktop")
    session_id = Column(
        Integer, ForeignKey("focus_sessions.id", ondelete="SET NULL"), nullable=True
    )
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship("User", back_populates="activity_logs")
    focus_session = relationship("FocusSession", back_populates="activity_logs")

    @property
    def duration_minutes(self) -> float:
        return round(self.duration_seconds / 60, 2)


class FocusSession(Base):
    """Focus Session Recording — a deliberate block of work."""

    __tablename__ = "focus_sessions"
    __table_args__ = (Index("ix_session_user_started", "user_id", "started_at"),)

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    label = Column(String(160))
    started_at = Column(DateTime, nullable=False, index=True)
    ended_at = Column(DateTime)
    planned_minutes = Column(Integer, nullable=False, default=25)
    actual_seconds = Column(Integer, nullable=False, default=0)
    interruption_count = Column(Integer, nullable=False, default=0)
    tab_switch_count = Column(Integer, nullable=False, default=0)
    completed = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship("User", back_populates="focus_sessions")
    activity_logs = relationship("ActivityLog", back_populates="focus_session")


class NotificationEvent(Base):
    """Notification Activity Tracking — an interruption arriving at the user."""

    __tablename__ = "notification_events"
    __table_args__ = (Index("ix_notif_user_received", "user_id", "received_at"),)

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    source_app = Column(String(120), nullable=False)
    received_at = Column(DateTime, nullable=False, index=True)
    acknowledged_at = Column(DateTime)
    was_dismissed = Column(Boolean, nullable=False, default=False)
    # Non-null when the notification landed inside an active focus session.
    session_id = Column(
        Integer, ForeignKey("focus_sessions.id", ondelete="SET NULL"), nullable=True
    )


class DeviceUsageStat(Base):
    """Device Usage Statistics — one rolled-up row per user/device/day."""

    __tablename__ = "device_usage_stats"
    __table_args__ = (
        UniqueConstraint("user_id", "stat_date", "device", name="uq_device_stat_day"),
    )

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    stat_date = Column(Date, nullable=False, index=True)
    device = Column(String(40), nullable=False, default="Desktop")
    total_screen_seconds = Column(Integer, nullable=False, default=0)
    productive_seconds = Column(Integer, nullable=False, default=0)
    nonproductive_seconds = Column(Integer, nullable=False, default=0)
    app_switch_count = Column(Integer, nullable=False, default=0)
    unlock_count = Column(Integer, nullable=False, default=0)


# ---------------------------------------------------------------------------
# Weeks 3-4: AI-Based Attention Analysis & Distraction Detection Engine
# ---------------------------------------------------------------------------


class DailyScore(Base):
    """One row per user per day of computed attention scores.

    Persisted rather than computed on every request: the trend and prediction
    endpoints read weeks of history at once, and recomputing the full feature
    set per request would make those queries quadratic in the window size.
    """

    __tablename__ = "daily_scores"
    __table_args__ = (
        UniqueConstraint("user_id", "score_date", name="uq_daily_score_user_date"),
        Index("ix_daily_score_user_date", "user_id", "score_date"),
    )

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    score_date = Column(Date, nullable=False)

    # The three headline scores, all 0-100.
    focus_score = Column(Float, nullable=False)
    productivity_score = Column(Float, nullable=False)
    attention_stability_score = Column(Float, nullable=False)

    # Raw features kept alongside the scores so an insight can cite the number
    # it was derived from without recomputing anything.
    total_seconds = Column(Integer, nullable=False, default=0)
    productive_seconds = Column(Integer, nullable=False, default=0)
    deep_work_seconds = Column(Integer, nullable=False, default=0)
    productive_ratio = Column(Float, nullable=False, default=0.0)
    switches_per_hour = Column(Float, nullable=False, default=0.0)
    context_switches = Column(Integer, nullable=False, default=0)
    interruptions = Column(Integer, nullable=False, default=0)
    longest_focus_seconds = Column(Integer, nullable=False, default=0)

    # Per-score component breakdown, so the UI can explain how a score was built.
    components = Column(JSON, nullable=False, default=dict)
    computed_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class Insight(Base):
    """A generated, human-readable finding about the user's attention."""

    __tablename__ = "insights"
    __table_args__ = (Index("ix_insight_user_date", "user_id", "insight_date"),)

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    insight_date = Column(Date, nullable=False)
    # attention_leak | context_switching | notification_impact | focus_loss |
    # fatigue | trend | summary
    kind = Column(String(40), nullable=False, index=True)
    severity = Column(String(20), nullable=False, default="info")  # info | warning | critical
    title = Column(String(200), nullable=False)
    message = Column(Text, nullable=False)
    # The numbers behind the sentence — kept so the claim stays auditable.
    evidence = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class Prediction(Base):
    """A model's forecast for a future day."""

    __tablename__ = "predictions"
    __table_args__ = (
        UniqueConstraint("user_id", "target_date", "kind", name="uq_prediction_slot"),
    )

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    target_date = Column(Date, nullable=False, index=True)
    # focus_degradation | productivity_risk | attention_fatigue
    kind = Column(String(40), nullable=False)
    predicted_value = Column(Float, nullable=False)
    label = Column(String(40), nullable=False)  # e.g. "at_risk" / "stable"
    confidence = Column(Float, nullable=False, default=0.0)
    # "heuristic" when no trained artifact was available — never silently
    # pretend a fallback came from the model.
    model_version = Column(String(40), nullable=False, default="heuristic")
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


# ---------------------------------------------------------------------------
# Weeks 5-6: Personalised Focus Improvement & Recommendation Platform
# ---------------------------------------------------------------------------


class Recommendation(Base):
    """An actionable suggestion, with the evidence and expected payoff.

    Stored (rather than only generated on read) so acceptance can be tracked:
    a recommendation the user dismissed twice should stop being surfaced, and
    that requires remembering it was shown.
    """

    __tablename__ = "recommendations"
    __table_args__ = (
        UniqueConstraint("user_id", "generated_date", "key", name="uq_reco_slot"),
        Index("ix_reco_user_date", "user_id", "generated_date"),
    )

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    generated_date = Column(Date, nullable=False)
    # Stable identifier for "the same advice" across days, e.g.
    # "leak:Instagram" — this is what makes dismissal stick.
    key = Column(String(120), nullable=False)
    # focus_improvement | productivity_tip | attention_recovery | work_pattern
    category = Column(String(40), nullable=False, index=True)
    title = Column(String(200), nullable=False)
    action = Column(Text, nullable=False)
    rationale = Column(Text, nullable=False)
    # Minutes of attention per day this change could plausibly recover.
    expected_gain_minutes = Column(Float, nullable=False, default=0.0)
    confidence = Column(Float, nullable=False, default=0.5)
    priority = Column(Float, nullable=False, default=0.0)
    evidence = Column(JSON, nullable=False, default=dict)
    # suggested | accepted | dismissed | completed
    status = Column(String(20), nullable=False, default="suggested")
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class GoalProgress(Base):
    """One row per goal per day — the substrate for streaks and habit tracking."""

    __tablename__ = "goal_progress"
    __table_args__ = (
        UniqueConstraint("goal_id", "progress_date", name="uq_goal_progress_day"),
        Index("ix_goal_progress_user_date", "user_id", "progress_date"),
    )

    id = Column(Integer, primary_key=True)
    goal_id = Column(Integer, ForeignKey("goals.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    progress_date = Column(Date, nullable=False)
    actual_value = Column(Float, nullable=False, default=0.0)
    target_value = Column(Float, nullable=False, default=0.0)
    attainment = Column(Float, nullable=False, default=0.0)  # actual / target
    met = Column(Boolean, nullable=False, default=False)
    computed_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class Alert(Base):
    """A smart reminder, focus-session nudge, or distraction warning."""

    __tablename__ = "alerts"
    __table_args__ = (Index("ix_alert_user_scheduled", "user_id", "scheduled_for"),)

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    # smart_reminder | focus_session | distraction | goal
    kind = Column(String(40), nullable=False, index=True)
    severity = Column(String(20), nullable=False, default="info")
    title = Column(String(200), nullable=False)
    message = Column(Text, nullable=False)
    scheduled_for = Column(DateTime, nullable=False)
    evidence = Column(JSON, nullable=False, default=dict)
    delivered = Column(Boolean, nullable=False, default=False)
    dismissed = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

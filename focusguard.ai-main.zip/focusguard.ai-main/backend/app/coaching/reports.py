"""Weekly Focus Reports and Attention Improvement Trends.

Reports compare a period against the one before it. Where a comparison is not
possible — fewer than a full prior week of data — that is stated rather than
silently comparing against a stub and reporting a meaningless delta.
"""
from __future__ import annotations

import statistics
from datetime import date, timedelta

from ..analytics.features import DailyFeatures
from ..analytics.scoring import (
    attention_stability_score,
    concentration_trend,
    focus_score,
    productivity_score,
)

MIN_DAYS_FOR_COMPARISON = 3


def _period_stats(features: list[DailyFeatures]) -> dict:
    if not features:
        return {}
    return {
        "days": len(features),
        "focus_score": round(statistics.fmean([focus_score(f).score for f in features]), 1),
        "productivity_score": round(
            statistics.fmean([productivity_score(f).score for f in features]), 1
        ),
        "attention_stability_score": round(
            statistics.fmean([attention_stability_score(f).score for f in features]), 1
        ),
        "total_hours": round(sum(f.total_seconds for f in features) / 3600, 1),
        "productive_hours": round(
            sum(f.productive_seconds for f in features) / 3600, 1
        ),
        "productive_ratio": round(
            statistics.fmean([f.productive_ratio for f in features]), 3
        ),
        "deep_work_blocks": round(
            statistics.fmean([f.deep_work_blocks for f in features]), 2
        ),
        "avg_switches_per_hour": round(
            statistics.fmean([f.switches_per_hour for f in features]), 2
        ),
        "interruptions": sum(f.notifications for f in features),
        "longest_focus_minutes": round(
            max(f.longest_focus_seconds for f in features) / 60, 1
        ),
    }


def _delta(current: dict, previous: dict, key: str) -> float | None:
    if not previous or key not in current or key not in previous:
        return None
    return round(current[key] - previous[key], 2)


def weekly_report(features: list[DailyFeatures], end_day: date | None = None) -> dict:
    """This week against last week, across every headline metric."""
    if not features:
        return {"available": False, "reason": "No activity recorded."}

    end_day = end_day or features[-1].day
    this_week_start = end_day - timedelta(days=6)
    last_week_start = this_week_start - timedelta(days=7)

    this_week = [f for f in features if this_week_start <= f.day <= end_day]
    last_week = [f for f in features if last_week_start <= f.day < this_week_start]

    if not this_week:
        return {"available": False, "reason": "No activity in the last seven days."}

    current = _period_stats(this_week)
    comparable = len(last_week) >= MIN_DAYS_FOR_COMPARISON
    previous = _period_stats(last_week) if comparable else {}

    changes = {
        key: _delta(current, previous, key)
        for key in (
            "focus_score",
            "productivity_score",
            "attention_stability_score",
            "productive_hours",
            "productive_ratio",
            "deep_work_blocks",
            "avg_switches_per_hour",
            "interruptions",
        )
    }

    best = max(this_week, key=lambda f: focus_score(f).score)
    worst = min(this_week, key=lambda f: focus_score(f).score)

    if not comparable:
        headline = (
            f"Focus score averaged {current['focus_score']:.0f} across "
            f"{current['days']} days. Not enough history yet for a week-on-week "
            f"comparison — that arrives once you have a full prior week."
        )
    else:
        change = changes["focus_score"]
        direction = "up" if change > 0 else "down" if change < 0 else "level"
        headline = (
            f"Focus score averaged {current['focus_score']:.0f} this week, "
            f"{direction} {abs(change):.1f} points on last week's "
            f"{previous['focus_score']:.0f}. You logged "
            f"{current['productive_hours']:.1f} productive hours "
            f"({current['productive_ratio'] * 100:.0f}% of screen time)."
        )

    return {
        "available": True,
        "period_start": this_week_start.isoformat(),
        "period_end": end_day.isoformat(),
        "comparable": comparable,
        "headline": headline,
        "current": current,
        "previous": previous,
        "changes": changes,
        "best_day": {
            "day": best.day.isoformat(),
            "focus_score": round(focus_score(best).score, 1),
            "productive_ratio": round(best.productive_ratio, 3),
        },
        "worst_day": {
            "day": worst.day.isoformat(),
            "focus_score": round(focus_score(worst).score, 1),
            "productive_ratio": round(worst.productive_ratio, 3),
        },
    }


def improvement_trends(features: list[DailyFeatures]) -> dict:
    """Direction of travel on each score, plus the metrics moving most."""
    if len(features) < 2:
        return {"available": False, "reason": "Need at least two scored days."}

    series = {
        "focus_score": [focus_score(f).score for f in features],
        "productivity_score": [productivity_score(f).score for f in features],
        "attention_stability_score": [
            attention_stability_score(f).score for f in features
        ],
        "productive_ratio": [f.productive_ratio * 100 for f in features],
        "switches_per_hour": [f.switches_per_hour for f in features],
        "deep_work_blocks": [float(f.deep_work_blocks) for f in features],
    }

    trends = {}
    for name, values in series.items():
        t = concentration_trend(values)
        # For switch rate, down is good — invert the label so "improving"
        # always means "better", never just "larger".
        if name == "switches_per_hour" and t["direction"] != "stable":
            t = {
                **t,
                "direction": "improving" if t["direction"] == "declining" else "declining",
            }
        trends[name] = t

    movers = sorted(
        ({"metric": k, **v} for k, v in trends.items()),
        key=lambda t: abs(t["change"]),
        reverse=True,
    )

    return {
        "available": True,
        "days_analysed": len(features),
        "trends": trends,
        "biggest_movers": movers[:3],
    }


def goal_achievement_summary(tracked: list[dict]) -> dict:
    """Roll the per-goal detail up into a single achievement picture."""
    if not tracked:
        return {"goals": 0, "note": "No goals configured."}

    return {
        "goals": len(tracked),
        "goals_on_track_today": sum(1 for g in tracked if g["on_track"]),
        "avg_consistency": round(
            statistics.fmean([g["consistency"] for g in tracked]), 3
        ),
        "longest_active_streak": max(g["current_streak"] for g in tracked),
        "established_habits": sum(1 for g in tracked if g["habit_stage"] == "established"),
        "by_stage": {
            stage: sum(1 for g in tracked if g["habit_stage"] == stage)
            for stage in ("inconsistent", "forming", "establishing", "established")
        },
    }

"""Smart Focus Planner.

Derives the user's own working rhythm from history rather than prescribing a
textbook one: the best session length is whichever length *this* user actually
finishes, and the best focus window is whenever their productive share is
genuinely highest.
"""
from __future__ import annotations

import statistics
from collections import defaultdict
from datetime import date, datetime, time, timedelta

from sqlalchemy.orm import Session

from ..analytics.features import DailyFeatures
from ..analytics.predictive import analyse_attention_fatigue
from ..models import FocusSession, Goal

# An hour needs this much observed time before its productive ratio is
# trustworthy — one 4-minute visit at 06:00 should not crown it your peak hour.
MIN_HOUR_SAMPLE_SECONDS = 45 * 60

# Candidate session lengths, in minutes. Evaluated against the user's own
# completion history; the fallback order is deliberate (Pomodoro-ish upward).
SESSION_LENGTH_BUCKETS = [25, 45, 60, 90]
DEFAULT_SESSION_MINUTES = 45
# Break length as a share of the work block, bounded to something humane.
BREAK_RATIO = 0.2
MIN_BREAK_MINUTES, MAX_BREAK_MINUTES = 5, 20


def high_focus_hours(features: list[DailyFeatures], top_n: int = 4) -> list[dict]:
    """Rank clock hours by how productive this user actually is in them."""
    totals: dict[int, list[float]] = defaultdict(list)
    seconds: dict[int, float] = defaultdict(float)

    for day in features:
        for hour, ratio in day.hourly_productive_ratio.items():
            totals[hour].append(ratio)
            # Approximate observed seconds per hour from the day's total.
            seconds[hour] += day.total_seconds / max(1, len(day.hourly_productive_ratio))

    ranked = [
        {
            "hour": hour,
            "productive_ratio": round(statistics.fmean(ratios), 3),
            "days_observed": len(ratios),
            "confidence": round(min(1.0, len(ratios) / 10), 2),
        }
        for hour, ratios in totals.items()
        if seconds[hour] >= MIN_HOUR_SAMPLE_SECONDS and len(ratios) >= 3
    ]
    ranked.sort(key=lambda h: (h["productive_ratio"], h["days_observed"]), reverse=True)
    return ranked[:top_n]


def recommend_session_length(db: Session, user_id: int, days: int = 60) -> dict:
    """Pick the session length this user finishes most reliably.

    Completion rate alone would favour trivially short sessions, so candidates
    are scored on completed *minutes* — a 90-minute block finished half the
    time still beats a 25-minute block finished always.
    """
    since = datetime.utcnow() - timedelta(days=days)
    sessions = (
        db.query(FocusSession)
        .filter(
            FocusSession.user_id == user_id,
            FocusSession.started_at >= since,
            FocusSession.ended_at.isnot(None),
        )
        .all()
    )

    if len(sessions) < 5:
        return {
            "recommended_minutes": DEFAULT_SESSION_MINUTES,
            "basis": "default",
            "note": "Not enough completed sessions yet to personalise this.",
            "buckets": [],
        }

    buckets = []
    for length in SESSION_LENGTH_BUCKETS:
        # Sessions whose planned length is nearest this bucket.
        group = [
            s
            for s in sessions
            if min(SESSION_LENGTH_BUCKETS, key=lambda b: abs(b - s.planned_minutes)) == length
        ]
        if not group:
            continue
        completion = sum(1 for s in group if s.completed) / len(group)
        buckets.append(
            {
                "minutes": length,
                "sessions": len(group),
                "completion_rate": round(completion, 3),
                "expected_completed_minutes": round(completion * length, 1),
                "avg_interruptions": round(
                    statistics.fmean([float(s.interruption_count) for s in group]), 2
                ),
            }
        )

    if not buckets:
        return {
            "recommended_minutes": DEFAULT_SESSION_MINUTES,
            "basis": "default",
            "note": "No sessions matched the candidate lengths.",
            "buckets": [],
        }

    best = max(buckets, key=lambda b: b["expected_completed_minutes"])
    return {
        "recommended_minutes": best["minutes"],
        "basis": "history",
        "note": (
            f"You complete {best['completion_rate'] * 100:.0f}% of "
            f"{best['minutes']}-minute blocks, the best expected yield of the "
            f"lengths you have tried."
        ),
        "buckets": sorted(buckets, key=lambda b: b["minutes"]),
    }


def break_schedule(features: list[DailyFeatures], session_minutes: int) -> dict:
    """Work/break rhythm, lengthened when the fatigue curve says to."""
    fatigue = analyse_attention_fatigue(features)
    break_minutes = int(
        max(MIN_BREAK_MINUTES, min(MAX_BREAK_MINUTES, session_minutes * BREAK_RATIO))
    )

    # A fatiguing profile earns a longer reset between blocks.
    if fatigue.label == "fatiguing":
        break_minutes = min(MAX_BREAK_MINUTES, break_minutes + 5)

    # A long break after this many consecutive blocks.
    blocks_before_long_break = 3 if session_minutes <= 45 else 2

    return {
        "work_minutes": session_minutes,
        "short_break_minutes": break_minutes,
        "long_break_minutes": break_minutes * 3,
        "blocks_before_long_break": blocks_before_long_break,
        "fatigue_profile": fatigue.label,
        "rationale": (
            "Breaks extended because productive share decays across your day."
            if fatigue.label == "fatiguing"
            else "Standard break ratio; your attention holds steady through the day."
        ),
    }


def build_daily_plan(
    db: Session, user_id: int, features: list[DailyFeatures], plan_date: date | None = None
) -> dict:
    """Lay concrete focus blocks over tomorrow's best hours."""
    plan_date = plan_date or (date.today() + timedelta(days=1))
    peaks = high_focus_hours(features)
    session = recommend_session_length(db, user_id)
    rhythm = break_schedule(features, session["recommended_minutes"])

    if not peaks:
        return {
            "date": plan_date.isoformat(),
            "blocks": [],
            "session": session,
            "rhythm": rhythm,
            "note": "Not enough hourly history to place focus blocks yet.",
        }

    # Plan from the earliest peak hour so the day builds forward rather than
    # scattering blocks across disconnected slots.
    start_hours = sorted(p["hour"] for p in peaks)
    ratio_by_hour = {p["hour"]: p["productive_ratio"] for p in peaks}

    blocks: list[dict] = []
    cursor = datetime.combine(plan_date, time(hour=start_hours[0]))
    work = timedelta(minutes=rhythm["work_minutes"])
    short_break = timedelta(minutes=rhythm["short_break_minutes"])
    long_break = timedelta(minutes=rhythm["long_break_minutes"])

    for i in range(len(start_hours)):
        end = cursor + work
        blocks.append(
            {
                "kind": "focus",
                "start": cursor.strftime("%H:%M"),
                "end": end.strftime("%H:%M"),
                "minutes": rhythm["work_minutes"],
                # Expected quality drives which task belongs here.
                "expected_productive_ratio": ratio_by_hour.get(
                    cursor.hour, round(statistics.fmean(list(ratio_by_hour.values())), 3)
                ),
            }
        )
        cursor = end

        is_long = (i + 1) % rhythm["blocks_before_long_break"] == 0
        gap = long_break if is_long else short_break
        if i < len(start_hours) - 1:
            blocks.append(
                {
                    "kind": "long_break" if is_long else "break",
                    "start": cursor.strftime("%H:%M"),
                    "end": (cursor + gap).strftime("%H:%M"),
                    "minutes": int(gap.total_seconds() / 60),
                    "expected_productive_ratio": None,
                }
            )
            cursor += gap

    focus_blocks = [b for b in blocks if b["kind"] == "focus"]
    return {
        "date": plan_date.isoformat(),
        "blocks": blocks,
        "total_focus_minutes": sum(b["minutes"] for b in focus_blocks),
        "session": session,
        "rhythm": rhythm,
        "high_focus_hours": peaks,
    }


def prioritise_goals(db: Session, user_id: int, plan: dict) -> list[dict]:
    """Task Prioritization Assistance — match goals to the strongest blocks.

    The hardest work belongs in the block with the highest expected productive
    ratio. Without real task objects, the user's active goals stand in for the
    work to be scheduled.
    """
    goals = (
        db.query(Goal)
        .filter(Goal.user_id == user_id, Goal.status == "active")
        .order_by(Goal.created_at.desc())
        .all()
    )
    focus_blocks = sorted(
        [b for b in plan.get("blocks", []) if b["kind"] == "focus"],
        key=lambda b: b["expected_productive_ratio"] or 0,
        reverse=True,
    )
    if not goals or not focus_blocks:
        return []

    # Demanding goal types earn the better slots.
    difficulty = {
        "focus_minutes": 3,
        "productive_ratio": 2,
        "max_tab_switches": 1,
        "max_screen_time": 1,
    }
    ranked = sorted(goals, key=lambda g: difficulty.get(g.goal_type, 0), reverse=True)

    return [
        {
            "goal_id": goal.id,
            "goal": goal.title,
            "goal_type": goal.goal_type,
            "assigned_block": f"{block['start']}-{block['end']}",
            "expected_productive_ratio": block["expected_productive_ratio"],
            "rationale": (
                f"Highest-demand goal placed in your strongest block "
                f"({(block['expected_productive_ratio'] or 0) * 100:.0f}% "
                f"historical productive share)."
                if i == 0
                else "Assigned to the next-best available focus block."
            ),
        }
        for i, (goal, block) in enumerate(zip(ranked, focus_blocks))
    ]

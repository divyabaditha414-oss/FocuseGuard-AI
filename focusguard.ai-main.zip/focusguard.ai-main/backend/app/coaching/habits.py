"""Goal Management — progress tracking, streaks and habit formation.

Evaluates each active goal against the day's measured features, then reports
consistency rather than just a pass/fail count: a habit is defined by how
reliably it happens, not by how often it has ever happened.
"""
from __future__ import annotations

import statistics
from datetime import date

from sqlalchemy.orm import Session

from ..analytics.features import DailyFeatures
from ..models import Goal, GoalProgress

# Days of consistent adherence before a behaviour is treated as established.
FORMING_DAYS = 7
ESTABLISHING_DAYS = 21
# Attainment at or above this counts the day as "met".
MET_THRESHOLD = 1.0
# Consistency needed to advance a habit stage.
CONSISTENCY_THRESHOLD = 0.7


def _actual_for_goal(goal: Goal, f: DailyFeatures) -> float:
    """Measure a goal's metric from one day of features."""
    if goal.goal_type == "focus_minutes":
        return f.productive_seconds / 60
    if goal.goal_type == "productive_ratio":
        return f.productive_ratio * 100  # goals store this as a percentage
    if goal.goal_type == "max_tab_switches":
        return f.tab_switches
    if goal.goal_type == "max_screen_time":
        return f.total_seconds / 60
    return 0.0


def _is_ceiling_goal(goal: Goal) -> bool:
    """True when a *lower* number is better (a cap rather than a target)."""
    return goal.goal_type in {"max_tab_switches", "max_screen_time"}


def evaluate_goal_day(goal: Goal, f: DailyFeatures) -> dict:
    """Attainment for one goal on one day, in the direction that goal points."""
    actual = _actual_for_goal(goal, f)
    target = goal.target_value or 1.0

    if _is_ceiling_goal(goal):
        # Under the cap is good; attainment >= 1 means the cap was respected.
        attainment = target / actual if actual > 0 else 1.0
    else:
        attainment = actual / target

    return {
        "day": f.day,
        "actual_value": round(actual, 2),
        "target_value": round(target, 2),
        "attainment": round(attainment, 3),
        "met": attainment >= MET_THRESHOLD,
    }


def _streaks(met_flags: list[bool]) -> tuple[int, int]:
    """(current streak, longest streak) over a chronological list."""
    longest = run = 0
    for met in met_flags:
        run = run + 1 if met else 0
        longest = max(longest, run)

    current = 0
    for met in reversed(met_flags):
        if not met:
            break
        current += 1
    return current, longest


def _habit_stage(days_tracked: int, consistency: float) -> str:
    """Where this behaviour sits on the way to being automatic.

    Consistency gates progression: thirty days at 30% adherence is not a habit
    taking hold, it is thirty days of not doing the thing.
    """
    if consistency < CONSISTENCY_THRESHOLD:
        return "inconsistent"
    if days_tracked < FORMING_DAYS:
        return "forming"
    if days_tracked < ESTABLISHING_DAYS:
        return "establishing"
    return "established"


def track_goals(
    db: Session, user_id: int, features: list[DailyFeatures]
) -> list[dict]:
    """Per-goal progress, streaks and habit stage over the window."""
    goals = (
        db.query(Goal)
        .filter(Goal.user_id == user_id, Goal.status.in_(["active", "done"]))
        .order_by(Goal.created_at)
        .all()
    )
    if not goals or not features:
        return []

    results = []
    for goal in goals:
        # Only count days on or after the goal started — crediting a streak to
        # days before the goal existed would be meaningless.
        relevant = [f for f in features if f.day >= goal.start_date]
        if goal.end_date:
            relevant = [f for f in relevant if f.day <= goal.end_date]
        if not relevant:
            continue

        daily = [evaluate_goal_day(goal, f) for f in relevant]
        met_flags = [d["met"] for d in daily]
        current_streak, longest_streak = _streaks(met_flags)
        consistency = sum(met_flags) / len(met_flags)
        recent = daily[-7:]

        results.append(
            {
                "goal_id": goal.id,
                "title": goal.title,
                "goal_type": goal.goal_type,
                "period": goal.period,
                "target_value": goal.target_value,
                "unit": goal.unit,
                "status": goal.status,
                "days_tracked": len(daily),
                "days_met": sum(met_flags),
                "consistency": round(consistency, 3),
                "current_streak": current_streak,
                "longest_streak": longest_streak,
                "avg_attainment": round(
                    statistics.fmean([d["attainment"] for d in daily]), 3
                ),
                "recent_avg_attainment": round(
                    statistics.fmean([d["attainment"] for d in recent]), 3
                ),
                "habit_stage": _habit_stage(len(daily), consistency),
                "on_track": bool(recent) and recent[-1]["met"],
                "daily": [
                    {**d, "day": d["day"].isoformat()} for d in daily[-14:]
                ],
            }
        )

    return results


def persist_goal_progress(
    db: Session, user_id: int, features: list[DailyFeatures]
) -> int:
    """Materialise per-goal, per-day progress rows (idempotent)."""
    goals = (
        db.query(Goal).filter(Goal.user_id == user_id, Goal.status == "active").all()
    )
    if not goals:
        return 0

    written = 0
    for goal in goals:
        for f in features:
            if f.day < goal.start_date or (goal.end_date and f.day > goal.end_date):
                continue

            evaluated = evaluate_goal_day(goal, f)
            row = (
                db.query(GoalProgress)
                .filter(
                    GoalProgress.goal_id == goal.id, GoalProgress.progress_date == f.day
                )
                .first()
            )
            if not row:
                row = GoalProgress(
                    goal_id=goal.id, user_id=user_id, progress_date=f.day
                )
                db.add(row)

            row.actual_value = evaluated["actual_value"]
            row.target_value = evaluated["target_value"]
            row.attainment = evaluated["attainment"]
            row.met = evaluated["met"]
            written += 1

    db.commit()
    return written


def suggest_goal_adjustments(tracked: list[dict]) -> list[dict]:
    """Flag goals that are set wrong — too hard to ever hit, or too easy to matter."""
    suggestions = []
    for goal in tracked:
        if goal["days_tracked"] < FORMING_DAYS:
            continue

        if goal["consistency"] < 0.2:
            suggestions.append(
                {
                    "goal_id": goal["goal_id"],
                    "title": goal["title"],
                    "issue": "too_hard",
                    "message": (
                        f"Hit on {goal['days_met']} of {goal['days_tracked']} days "
                        f"({goal['consistency'] * 100:.0f}%). Average attainment is "
                        f"{goal['avg_attainment'] * 100:.0f}% of target — lowering it "
                        f"to roughly that level would make it a goal you can build a "
                        f"streak on."
                    ),
                    "suggested_target": round(
                        goal["target_value"] * max(0.5, goal["avg_attainment"]), 1
                    ),
                }
            )
        elif goal["consistency"] > 0.95 and goal["avg_attainment"] > 1.3:
            suggestions.append(
                {
                    "goal_id": goal["goal_id"],
                    "title": goal["title"],
                    "issue": "too_easy",
                    "message": (
                        f"Hit on {goal['consistency'] * 100:.0f}% of days at "
                        f"{goal['avg_attainment'] * 100:.0f}% of target. This goal is "
                        f"no longer stretching you."
                    ),
                    "suggested_target": round(goal["target_value"] * 1.2, 1),
                }
            )

    return suggestions

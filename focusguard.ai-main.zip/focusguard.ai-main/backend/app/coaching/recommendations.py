"""Recommendation Engine.

Each recommendation is generated from one measured signal and carries the
numbers behind it, an estimated daily gain in minutes, and a confidence. They
are ranked by `priority = expected_gain_minutes * confidence`, so a large but
uncertain win does not automatically outrank a small certain one.

Estimated gains are explicitly *plausible ceilings*, not promises — the
rationale text says which assumption each one rests on.
"""
from __future__ import annotations

import statistics
from datetime import date

from sqlalchemy.orm import Session

from ..analytics.distraction import (
    context_switching_analysis,
    focus_loss_identification,
    notification_impact_assessment,
)
from ..analytics.features import DailyFeatures
from ..analytics.predictive import analyse_attention_fatigue
from ..analytics.scoring import concentration_trend, focus_score
from ..models import Goal, Recommendation
from .planner import high_focus_hours, recommend_session_length

# Assume a user can realistically reclaim this share of a leak's time, not all
# of it. Some of that time is a genuine break and cutting it entirely is not a
# gain.
RECLAIMABLE_LEAK_SHARE = 0.6
# Each avoided focus break costs roughly this long to recover from.
CONTEXT_RELOAD_MINUTES = 3.0
LATE_NIGHT_MINUTES_THRESHOLD = 45


def _reco(
    key: str,
    category: str,
    title: str,
    action: str,
    rationale: str,
    gain: float,
    confidence: float,
    evidence: dict,
) -> dict:
    return {
        "key": key,
        "category": category,
        "title": title,
        "action": action,
        "rationale": rationale,
        "expected_gain_minutes": round(gain, 1),
        "confidence": round(confidence, 2),
        "priority": round(gain * confidence, 2),
        "evidence": evidence,
    }


def generate_recommendations(
    db: Session,
    user_id: int,
    features: list[DailyFeatures],
    leaks: list[dict],
    days: int = 30,
) -> list[dict]:
    """Build the ranked recommendation list for this user."""
    if not features:
        return []

    recos: list[dict] = []
    scores = [focus_score(f).score for f in features]
    avg_focus = statistics.fmean(scores)

    # --- Attention recovery: the biggest leaks --------------------------
    for leak in leaks[:3]:
        gain = leak["minutes_per_day"] * RECLAIMABLE_LEAK_SHARE
        # More visits per day means a more entrenched habit and a more
        # confident call that limiting it helps.
        confidence = min(0.9, 0.45 + leak["visits_per_day"] * 0.06)
        recos.append(
            _reco(
                key=f"leak:{leak['app_name']}",
                category="attention_recovery",
                title=f"Limit {leak['app_name']} during work blocks",
                action=(
                    f"Block or mute {leak['app_name']} during your focus sessions, "
                    f"and give it one deliberate slot instead of "
                    f"{leak['visits_per_day']:.0f} scattered visits a day."
                ),
                rationale=(
                    f"{leak['app_name']} costs about {leak['minutes_per_day']:.0f} "
                    f"minutes a day across {leak['visits_per_day']:.1f} visits and "
                    f"broke a productive stretch {leak['times_broke_focus']} times. "
                    f"The estimate assumes you reclaim "
                    f"{RECLAIMABLE_LEAK_SHARE:.0%} of that time — the rest is a "
                    f"legitimate break."
                ),
                gain=gain,
                confidence=confidence,
                evidence=leak,
            )
        )

    # --- Work pattern: avoid the most contested hour --------------------
    switching = context_switching_analysis(db, user_id, features, days)
    peaks = high_focus_hours(features)
    if switching.get("peak_hours") and peaks:
        worst_hour = switching["peak_hours"][0]
        best = peaks[0]
        if worst_hour["hour"] != best["hour"]:
            daily_switches = worst_hour["switches"] / max(1, len(features))
            gain = daily_switches * CONTEXT_RELOAD_MINUTES
            recos.append(
                _reco(
                    key="pattern:avoid_peak_switch_hour",
                    category="work_pattern",
                    title=f"Move deep work out of {worst_hour['hour']:02d}:00",
                    action=(
                        f"Schedule shallow work (email, admin) at "
                        f"{worst_hour['hour']:02d}:00 and put demanding tasks at "
                        f"{best['hour']:02d}:00, where you run at "
                        f"{best['productive_ratio'] * 100:.0f}% productive."
                    ),
                    rationale=(
                        f"{worst_hour['hour']:02d}:00 is your most fragmented hour "
                        f"({worst_hour['switches']} context switches in {len(features)} "
                        f"days, ~{daily_switches:.1f}/day). Costing each switch "
                        f"{CONTEXT_RELOAD_MINUTES:.0f} minutes of reload gives the "
                        f"estimate."
                    ),
                    gain=gain,
                    confidence=0.6,
                    evidence={"worst_hour": worst_hour, "best_hour": best},
                )
            )

    # --- Focus improvement: notifications -------------------------------
    impact = notification_impact_assessment(db, user_id, days)
    if impact.get("comparable") and impact["completion_rate_gap"] > 0.05:
        top = impact["top_interrupting_apps"][:2]
        names = ", ".join(a["source_app"] for a in top) or "your noisiest apps"
        interrupted = impact["interrupted"]
        gain = interrupted["avg_minutes"] * impact["completion_rate_gap"]
        recos.append(
            _reco(
                key="focus:mute_notifications",
                category="focus_improvement",
                title=f"Mute {names} during focus sessions",
                action=(
                    f"Turn on Do Not Disturb for {names} while a focus session is "
                    f"running. Batch-check them at your scheduled break instead."
                ),
                rationale=(
                    f"Interrupted sessions complete "
                    f"{impact['completion_rate_gap'] * 100:.0f} points less often and "
                    f"carry {impact['extra_switches_when_interrupted']:.0f} more tab "
                    f"switches. Sessions are not randomly assigned to be interrupted, "
                    f"so this is an association — but the fix is cheap to test."
                ),
                gain=gain,
                confidence=0.55,
                evidence=impact,
            )
        )

    # --- Focus improvement: right-size the session ----------------------
    session = recommend_session_length(db, user_id)
    if session["basis"] == "history" and session["buckets"]:
        current = max(session["buckets"], key=lambda b: b["sessions"])
        if current["minutes"] != session["recommended_minutes"]:
            best_bucket = max(
                session["buckets"], key=lambda b: b["expected_completed_minutes"]
            )
            gain = max(
                0.0,
                best_bucket["expected_completed_minutes"]
                - current["expected_completed_minutes"],
            )
            recos.append(
                _reco(
                    key="focus:session_length",
                    category="focus_improvement",
                    title=f"Try {session['recommended_minutes']}-minute focus blocks",
                    action=(
                        f"Switch your default session from {current['minutes']} to "
                        f"{session['recommended_minutes']} minutes."
                    ),
                    rationale=(
                        f"You finish {current['completion_rate'] * 100:.0f}% of "
                        f"{current['minutes']}-minute blocks but "
                        f"{best_bucket['completion_rate'] * 100:.0f}% of "
                        f"{session['recommended_minutes']}-minute ones, a better "
                        f"expected yield per block."
                    ),
                    gain=gain * 2,  # a couple of blocks a day
                    confidence=0.5,
                    evidence=session,
                )
            )

    # --- Attention recovery: fatigue ------------------------------------
    fatigue = analyse_attention_fatigue(features)
    if fatigue.label == "fatiguing":
        d = fatigue.detail
        decay_minutes = d["decay"] * statistics.fmean([f.hours for f in features]) * 60 / 3
        recos.append(
            _reco(
                key="recovery:front_load_day",
                category="attention_recovery",
                title="Front-load demanding work",
                action=(
                    "Move your hardest task into the first two working hours and "
                    "reserve the late block for admin, review and email."
                ),
                rationale=(
                    f"Productive share falls from "
                    f"{d['morning_productive_ratio'] * 100:.0f}% early to "
                    f"{d['evening_productive_ratio'] * 100:.0f}% late. Fighting that "
                    f"decline costs more than working with it."
                ),
                gain=max(0.0, decay_minutes),
                confidence=0.65,
                evidence=d,
            )
        )

    # --- Attention recovery: late-night cutoff --------------------------
    late_minutes = statistics.fmean([f.late_night_seconds for f in features]) / 60
    if late_minutes >= LATE_NIGHT_MINUTES_THRESHOLD:
        recos.append(
            _reco(
                key="recovery:late_night_cutoff",
                category="attention_recovery",
                title="Set a screen cutoff before midnight",
                action=(
                    f"Stop screen use by 22:30. You currently average "
                    f"{late_minutes:.0f} minutes after 22:00."
                ),
                rationale=(
                    f"Late-night usage averages {late_minutes:.0f} minutes a day. "
                    f"In your own history, heavier late-night days are followed by "
                    f"lower next-day productive share — the fatigue term in the "
                    f"model rests on exactly this."
                ),
                gain=late_minutes * 0.4,
                confidence=0.5,
                evidence={"avg_late_night_minutes": round(late_minutes, 1)},
            )
        )

    # --- Productivity tip: goal attainment ------------------------------
    goal = (
        db.query(Goal)
        .filter(
            Goal.user_id == user_id,
            Goal.goal_type == "focus_minutes",
            Goal.status == "active",
        )
        .order_by(Goal.created_at.desc())
        .first()
    )
    if goal:
        avg_productive_minutes = statistics.fmean(
            [f.productive_seconds for f in features]
        ) / 60
        shortfall = goal.target_value - avg_productive_minutes
        if shortfall > 15:
            recos.append(
                _reco(
                    key="tip:close_goal_gap",
                    category="productivity_tip",
                    title=f"You are {shortfall:.0f} min/day short of your focus goal",
                    action=(
                        f"Add one more {session['recommended_minutes']}-minute block, "
                        f"or lower the target to something you will actually hit."
                    ),
                    rationale=(
                        f"Your goal is {goal.target_value:.0f} min/day; you average "
                        f"{avg_productive_minutes:.0f}. A target missed every day "
                        f"stops being motivating."
                    ),
                    gain=min(shortfall, session["recommended_minutes"]),
                    confidence=0.7,
                    evidence={
                        "goal_minutes": goal.target_value,
                        "actual_minutes": round(avg_productive_minutes, 1),
                        "shortfall_minutes": round(shortfall, 1),
                    },
                )
            )

    # --- Productivity tip: deep work blocks -----------------------------
    avg_blocks = statistics.fmean([f.deep_work_blocks for f in features])
    if avg_blocks < 2:
        recos.append(
            _reco(
                key="tip:more_deep_blocks",
                category="productivity_tip",
                title="Build a second deep-work block into your day",
                action=(
                    "Protect one more uninterrupted 25+ minute stretch, ideally "
                    "adjacent to an existing one."
                ),
                rationale=(
                    f"You average {avg_blocks:.1f} deep-work blocks a day. Work split "
                    f"below 25-minute stretches never reaches the depth where the "
                    f"hard problems get solved."
                ),
                gain=25.0,
                confidence=0.5,
                evidence={"avg_deep_work_blocks": round(avg_blocks, 2)},
            )
        )

    # --- Work pattern: focus-loss habit ---------------------------------
    loss = focus_loss_identification(db, user_id, days)
    if loss["focus_loss_events"] and loss["notification_triggered_share"] < 0.4:
        per_day = loss["self_initiated"] / max(1, len(features))
        recos.append(
            _reco(
                key="pattern:self_initiated_drift",
                category="work_pattern",
                title="Most of your focus breaks are self-initiated",
                action=(
                    "When you feel the pull to switch, write the thought down and "
                    "carry on. Handle the list at your next scheduled break."
                ),
                rationale=(
                    f"{loss['self_initiated']} of {loss['focus_loss_events']} focus "
                    f"breaks had no notification before them (~{per_day:.1f}/day). "
                    f"Blocking apps will not fix this one; it is a habit, not an "
                    f"interruption."
                ),
                gain=per_day * CONTEXT_RELOAD_MINUTES,
                confidence=0.55,
                evidence={
                    "self_initiated": loss["self_initiated"],
                    "total_events": loss["focus_loss_events"],
                    "notification_triggered_share": loss["notification_triggered_share"],
                },
            )
        )

    # --- Work pattern: declining trend ----------------------------------
    trend = concentration_trend(scores)
    if trend["direction"] == "declining":
        recos.append(
            _reco(
                key="pattern:reverse_decline",
                category="work_pattern",
                title="Your focus is trending down — reset the basics",
                action=(
                    "For the next week, run one protected block at "
                    f"{peaks[0]['hour']:02d}:00 with notifications off, and nothing else changed."
                    if peaks
                    else "For the next week, protect one notification-free block a day."
                ),
                rationale=(
                    f"Focus score fell {abs(trend['change']):.1f} points week over week "
                    f"({trend['previous_avg']:.0f} to {trend['recent_avg']:.0f}). "
                    f"Changing one thing at a time makes it clear what worked."
                ),
                gain=abs(trend["change"]) * 2,
                confidence=0.45,
                evidence=trend,
            )
        )

    # Suppress anything the user has dismissed — re-showing rejected advice is
    # how a recommendation feed loses credibility.
    dismissed = {
        key
        for (key,) in db.query(Recommendation.key)
        .filter(Recommendation.user_id == user_id, Recommendation.status == "dismissed")
        .distinct()
        .all()
    }
    recos = [r for r in recos if r["key"] not in dismissed]

    recos.sort(key=lambda r: r["priority"], reverse=True)
    return recos


def persist_recommendations(
    db: Session, user_id: int, recos: list[dict], on_date: date | None = None
) -> int:
    """Upsert today's recommendations, preserving any status already set."""
    on_date = on_date or date.today()
    written = 0

    for reco in recos:
        row = (
            db.query(Recommendation)
            .filter(
                Recommendation.user_id == user_id,
                Recommendation.generated_date == on_date,
                Recommendation.key == reco["key"],
            )
            .first()
        )
        if not row:
            row = Recommendation(
                user_id=user_id, generated_date=on_date, key=reco["key"]
            )
            db.add(row)

        row.category = reco["category"]
        row.title = reco["title"]
        row.action = reco["action"]
        row.rationale = reco["rationale"]
        row.expected_gain_minutes = reco["expected_gain_minutes"]
        row.confidence = reco["confidence"]
        row.priority = reco["priority"]
        row.evidence = reco["evidence"]
        written += 1

    db.commit()
    return written

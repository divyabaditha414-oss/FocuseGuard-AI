"""Weeks 5-6: Personalised Focus Improvement & Recommendation Platform.

Consumes the Weeks 3-4 analytics output and turns it into things the user can
actually do:

    planner         -> high-focus hours, session lengths, breaks, a daily plan
    recommendations -> ranked, evidence-backed changes worth making
    habits          -> goal progress, streaks, habit formation stage
    alerts          -> smart reminders, session nudges, distraction warnings
    reports         -> weekly focus report and improvement trends

Every recommendation is derived from a measured signal and carries the numbers
behind it. Generic productivity advice needs no data and helps no one; if a
suggestion cannot cite evidence from this user's own history, it is not made.
"""

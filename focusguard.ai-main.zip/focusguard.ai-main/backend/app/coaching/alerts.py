"""Notification Intelligence — smart reminders, session alerts, distraction alerts.

The platform's whole premise is that notifications fragment attention, so this
module has to hold itself to a higher bar than the apps it critiques: alerts
are capped per day, ranked by usefulness, and each one has to be tied to a
measured signal. An attention tool that spams notifications is self-defeating.
"""
from __future__ import annotations

import statistics
from datetime import date, datetime, time, timedelta

from sqlalchemy.orm import Session

from ..analytics.features import DailyFeatures
from ..models import ActivityLog, Alert, FocusSession
from .planner import high_focus_hours

# Hard ceiling on alerts generated per day. More than this and we become the
# distraction we are trying to remove.
MAX_ALERTS_PER_DAY = 5
# Warn this long before a peak focus window opens.
REMINDER_LEAD_MINUTES = 15
# A distraction alert fires once today's non-productive time exceeds the user's
# own typical daily total by this multiple.
DISTRACTION_OVERRUN_MULTIPLE = 1.3
# Nudge a running session that has overshot its plan by this much.
SESSION_OVERRUN_MINUTES = 15


def _alert(
    kind: str, severity: str, title: str, message: str, when: datetime, evidence: dict
) -> dict:
    return {
        "kind": kind,
        "severity": severity,
        "title": title,
        "message": message,
        "scheduled_for": when,
        "evidence": evidence,
    }


def smart_reminders(
    features: list[DailyFeatures], for_date: date | None = None
) -> list[dict]:
    """Remind the user just before their historically strongest hours."""
    for_date = for_date or (date.today() + timedelta(days=1))
    peaks = high_focus_hours(features, top_n=2)

    reminders = []
    for peak in peaks:
        # Only worth a nudge if the hour is genuinely good and well observed.
        if peak["productive_ratio"] < 0.6 or peak["confidence"] < 0.5:
            continue
        start = datetime.combine(for_date, time(hour=peak["hour"])) - timedelta(
            minutes=REMINDER_LEAD_MINUTES
        )
        reminders.append(
            _alert(
                kind="smart_reminder",
                severity="info",
                title=f"Your best focus window opens at {peak['hour']:02d}:00",
                message=(
                    f"You run at {peak['productive_ratio'] * 100:.0f}% productive at "
                    f"{peak['hour']:02d}:00 across {peak['days_observed']} days. "
                    f"Close what you can and start your hardest task now."
                ),
                when=start,
                evidence=peak,
            )
        )
    return reminders


def focus_session_alerts(db: Session, user_id: int) -> list[dict]:
    """Nudge sessions that are running long, or a break that is overdue."""
    now = datetime.utcnow()
    running = (
        db.query(FocusSession)
        .filter(FocusSession.user_id == user_id, FocusSession.ended_at.is_(None))
        .first()
    )
    if not running:
        return []

    elapsed = (now - running.started_at).total_seconds() / 60
    planned = running.planned_minutes

    if elapsed >= planned + SESSION_OVERRUN_MINUTES:
        return [
            _alert(
                kind="focus_session",
                severity="warning",
                title="Session running long — take the break",
                message=(
                    f"You are {elapsed - planned:.0f} minutes past your "
                    f"{planned}-minute plan. Attention past the planned block is "
                    f"usually cheaper to recover with a break than to push through."
                ),
                when=now,
                evidence={
                    "session_id": running.id,
                    "elapsed_minutes": round(elapsed, 1),
                    "planned_minutes": planned,
                },
            )
        ]

    if elapsed >= planned:
        return [
            _alert(
                kind="focus_session",
                severity="info",
                title="Focus block complete",
                message=f"You have hit your {planned}-minute target. Break now and reset.",
                when=now,
                evidence={"session_id": running.id, "planned_minutes": planned},
            )
        ]

    return []


def distraction_alerts(
    db: Session, user_id: int, features: list[DailyFeatures]
) -> list[dict]:
    """Fire when today's distraction time is running above this user's norm."""
    if len(features) < 5:
        return []

    today = date.today()
    # Baseline excludes today, which is still in progress and would drag the
    # mean down against itself.
    history = [f for f in features if f.day < today]
    if not history:
        return []

    baseline_minutes = statistics.fmean([f.nonproductive_seconds for f in history]) / 60
    if baseline_minutes <= 0:
        return []

    todays_seconds = (
        db.query(ActivityLog)
        .filter(
            ActivityLog.user_id == user_id,
            ActivityLog.productivity == "NonProductive",
            ActivityLog.opened_at >= datetime.combine(today, time.min),
        )
        .with_entities(ActivityLog.duration_seconds)
        .all()
    )
    todays_minutes = sum(s[0] for s in todays_seconds) / 60

    if todays_minutes <= baseline_minutes * DISTRACTION_OVERRUN_MULTIPLE:
        return []

    return [
        _alert(
            kind="distraction",
            severity="warning",
            title=f"{todays_minutes:.0f} minutes lost to distractions today",
            message=(
                f"That is {todays_minutes / baseline_minutes:.1f}x your usual "
                f"{baseline_minutes:.0f} minutes. Worth deciding now whether the rest "
                f"of the day is a write-off or a recovery."
            ),
            when=datetime.utcnow(),
            evidence={
                "today_minutes": round(todays_minutes, 1),
                "baseline_minutes": round(baseline_minutes, 1),
                "multiple": round(todays_minutes / baseline_minutes, 2),
            },
        )
    ]


def goal_alerts(tracked: list[dict]) -> list[dict]:
    """Celebrate streaks worth protecting, warn about ones about to break."""
    alerts = []
    now = datetime.utcnow()

    for goal in tracked:
        if goal["current_streak"] >= 3 and not goal["on_track"]:
            alerts.append(
                _alert(
                    kind="goal",
                    severity="warning",
                    title=f"{goal['current_streak']}-day streak at risk",
                    message=(
                        f"\"{goal['title']}\" is not met yet today and you have a "
                        f"{goal['current_streak']}-day streak going. "
                        f"{goal['target_value']:.0f} {goal['unit']} is the bar."
                    ),
                    when=now,
                    evidence={
                        "goal_id": goal["goal_id"],
                        "current_streak": goal["current_streak"],
                    },
                )
            )
        elif goal["current_streak"] >= 7:
            alerts.append(
                _alert(
                    kind="goal",
                    severity="info",
                    title=f"{goal['current_streak']}-day streak on \"{goal['title']}\"",
                    message=(
                        f"Consistency is {goal['consistency'] * 100:.0f}% and this "
                        f"habit is {goal['habit_stage']}."
                    ),
                    when=now,
                    evidence={
                        "goal_id": goal["goal_id"],
                        "habit_stage": goal["habit_stage"],
                    },
                )
            )
    return alerts


def generate_alerts(
    db: Session, user_id: int, features: list[DailyFeatures], tracked: list[dict]
) -> list[dict]:
    """All alert sources, ranked and capped."""
    alerts = (
        focus_session_alerts(db, user_id)
        + distraction_alerts(db, user_id, features)
        + goal_alerts(tracked)
        + smart_reminders(features)
    )

    # Warnings first, then soonest — and never more than the daily cap.
    severity_rank = {"critical": 0, "warning": 1, "info": 2}
    alerts.sort(key=lambda a: (severity_rank.get(a["severity"], 3), a["scheduled_for"]))
    return alerts[:MAX_ALERTS_PER_DAY]


def persist_alerts(db: Session, user_id: int, alerts: list[dict]) -> int:
    """Store generated alerts, skipping ones already queued and undelivered."""
    pending = {
        (a.kind, a.title)
        for a in db.query(Alert)
        .filter(Alert.user_id == user_id, Alert.delivered.is_(False))
        .all()
    }

    fresh = [
        Alert(
            user_id=user_id,
            kind=a["kind"],
            severity=a["severity"],
            title=a["title"],
            message=a["message"],
            scheduled_for=a["scheduled_for"],
            evidence=a["evidence"],
        )
        for a in alerts
        if (a["kind"], a["title"]) not in pending
    ]
    db.add_all(fresh)
    db.commit()
    return len(fresh)

"""Train the Weeks 3-4 predictive models and write them to ml/artifacts/.

Two supervised tasks, both framed as "given the last 3 days, what happens on
the 4th":

    focus_degradation  regression     -> next day's focus score (0-100)
    productivity_risk  classification -> will next day's productive ratio
                                         fall below RISK_RATIO_THRESHOLD?

The split is chronological, not random. A random split would let the model see
day 30 while predicting day 12 for the same user, which leaks future
information and produces metrics that will not survive deployment.

Run:  python backend/ml/train.py
"""
from __future__ import annotations

import os
import sys
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import joblib  # noqa: E402
import numpy as np  # noqa: E402
from sklearn.dummy import DummyClassifier, DummyRegressor  # noqa: E402
from sklearn.linear_model import LogisticRegression, Ridge  # noqa: E402
from sklearn.metrics import (  # noqa: E402
    accuracy_score,
    f1_score,
    mean_absolute_error,
    precision_score,
    r2_score,
    recall_score,
    roc_auc_score,
    root_mean_squared_error,
)
from sklearn.pipeline import Pipeline  # noqa: E402
from sklearn.preprocessing import StandardScaler  # noqa: E402

from app.analytics.features import extract_daily_features  # noqa: E402
from app.analytics.predictive import (  # noqa: E402
    LOOKBACK_DAYS,
    RISK_RATIO_THRESHOLD,
    build_lookback_vector,
    lookback_feature_names,
)
from app.analytics.scoring import focus_score  # noqa: E402
from app.core.config import ML_ARTIFACT_DIR  # noqa: E402
from app.core.database import SessionLocal  # noqa: E402
from app.models import User  # noqa: E402

TEST_FRACTION = 0.25
VERSION = "v1"


def build_dataset(db):
    """Return (X, y_focus, y_risk, days) — one row per predictable user-day."""
    rows, focus_targets, risk_targets, target_days = [], [], [], []

    for user in db.query(User).order_by(User.id).all():
        features = extract_daily_features(db, user.id, days=365)
        if len(features) <= LOOKBACK_DAYS:
            continue

        for i in range(LOOKBACK_DAYS, len(features)):
            window = features[i - LOOKBACK_DAYS : i]
            target = features[i]

            # Guard against gaps: the window must be consecutive calendar days
            # ending the day before the target, or the "last 3 days" framing
            # silently becomes "3 days from some time last week".
            expected = [
                target.day.toordinal() - k for k in range(LOOKBACK_DAYS, 0, -1)
            ]
            if [d.day.toordinal() for d in window] != expected:
                continue

            rows.append(build_lookback_vector(window))
            focus_targets.append(focus_score(target).score)
            risk_targets.append(int(target.productive_ratio < RISK_RATIO_THRESHOLD))
            target_days.append(target.day)

    return (
        np.array(rows, dtype=float),
        np.array(focus_targets, dtype=float),
        np.array(risk_targets, dtype=int),
        target_days,
    )


def chronological_split(days: list, test_fraction: float) -> tuple[np.ndarray, np.ndarray]:
    """Train on everything before the cutoff date, test on everything after."""
    unique_days = sorted(set(days))
    cutoff_index = int(len(unique_days) * (1 - test_fraction))
    cutoff = unique_days[cutoff_index]
    days_arr = np.array(days)
    return days_arr < cutoff, days_arr >= cutoff


def train_focus_regressor(X_tr, y_tr, X_te, y_te) -> tuple[Pipeline, dict]:
    model = Pipeline(
        [("scale", StandardScaler()), ("ridge", Ridge(alpha=10.0, random_state=0))]
    )
    model.fit(X_tr, y_tr)
    pred = model.predict(X_te)

    baseline = DummyRegressor(strategy="mean").fit(X_tr, y_tr)
    baseline_pred = baseline.predict(X_te)

    metrics = {
        "mae": round(float(mean_absolute_error(y_te, pred)), 3),
        "rmse": round(float(root_mean_squared_error(y_te, pred)), 3),
        "r2": round(float(r2_score(y_te, pred)), 3),
        "baseline_mae": round(float(mean_absolute_error(y_te, baseline_pred)), 3),
        "train_samples": int(len(y_tr)),
        "test_samples": int(len(y_te)),
    }
    metrics["beats_baseline"] = metrics["mae"] < metrics["baseline_mae"]
    return model, metrics


def train_risk_classifier(X_tr, y_tr, X_te, y_te) -> tuple[Pipeline | None, dict]:
    # A single-class training set cannot produce a classifier; say so rather
    # than shipping a model that always predicts the same label.
    if len(set(y_tr)) < 2:
        return None, {"error": "Training split contains a single class.", "positives": int(y_tr.sum())}

    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("logit", LogisticRegression(max_iter=2000, C=0.5, class_weight="balanced")),
        ]
    )
    model.fit(X_tr, y_tr)
    pred = model.predict(X_te)

    baseline = DummyClassifier(strategy="most_frequent").fit(X_tr, y_tr)
    baseline_acc = accuracy_score(y_te, baseline.predict(X_te))

    metrics = {
        "accuracy": round(float(accuracy_score(y_te, pred)), 3),
        "precision": round(float(precision_score(y_te, pred, zero_division=0)), 3),
        "recall": round(float(recall_score(y_te, pred, zero_division=0)), 3),
        "f1": round(float(f1_score(y_te, pred, zero_division=0)), 3),
        "baseline_accuracy": round(float(baseline_acc), 3),
        "train_samples": int(len(y_tr)),
        "test_samples": int(len(y_te)),
        "test_positive_rate": round(float(y_te.mean()), 3),
    }
    if len(set(y_te)) > 1:
        metrics["roc_auc"] = round(
            float(roc_auc_score(y_te, model.predict_proba(X_te)[:, 1])), 3
        )

    # Accuracy is the wrong yardstick here. At-risk days are the minority, and
    # `class_weight="balanced"` deliberately trades accuracy for recall so the
    # model actually raises warnings. A never-warn classifier scores the
    # baseline accuracy and has zero utility, so judge on ranking ability
    # (ROC-AUC) instead — 0.5 is the coin-flip floor.
    metrics["beats_baseline"] = metrics.get("roc_auc", 0.5) > 0.6
    metrics["baseline_note"] = (
        f"A never-warn classifier scores {metrics['baseline_accuracy']} accuracy "
        f"but catches none of the at-risk days; this model catches "
        f"{metrics['recall']:.0%} of them."
    )
    return model, metrics


def main() -> None:
    db = SessionLocal()
    try:
        print("Building dataset from activity history...")
        X, y_focus, y_risk, days = build_dataset(db)
    finally:
        db.close()

    if len(X) < 40:
        raise SystemExit(
            f"Only {len(X)} training rows available — seed the database first "
            f"(python backend/scripts/load_mock_data.py)."
        )

    train_mask, test_mask = chronological_split(days, TEST_FRACTION)
    print(
        f"  {len(X)} samples x {X.shape[1]} features "
        f"({int(train_mask.sum())} train / {int(test_mask.sum())} test, "
        f"split chronologically)\n"
    )

    os.makedirs(ML_ARTIFACT_DIR, exist_ok=True)
    feature_names = lookback_feature_names()
    trained_at = datetime.utcnow().isoformat(timespec="seconds")

    print("focus_degradation (Ridge regression -> next-day focus score)")
    focus_model, focus_metrics = train_focus_regressor(
        X[train_mask], y_focus[train_mask], X[test_mask], y_focus[test_mask]
    )
    for k, v in focus_metrics.items():
        print(f"    {k:18} {v}")
    joblib.dump(
        {
            "model": focus_model,
            "version": f"ridge-{VERSION}",
            "feature_names": feature_names,
            "metrics": focus_metrics,
            "trained_at": trained_at,
        },
        os.path.join(ML_ARTIFACT_DIR, "focus_degradation.joblib"),
    )

    print("\nproductivity_risk (Logistic regression -> next-day ratio below target)")
    risk_model, risk_metrics = train_risk_classifier(
        X[train_mask], y_risk[train_mask], X[test_mask], y_risk[test_mask]
    )
    for k, v in risk_metrics.items():
        print(f"    {k:18} {v}")
    if risk_model is not None:
        joblib.dump(
            {
                "model": risk_model,
                "version": f"logit-{VERSION}",
                "feature_names": feature_names,
                "metrics": risk_metrics,
                "trained_at": trained_at,
            },
            os.path.join(ML_ARTIFACT_DIR, "productivity_risk.joblib"),
        )
    else:
        print("    -> not saved; the API will fall back to the heuristic.")

    print(f"\nArtifacts written to {ML_ARTIFACT_DIR}")
    if not focus_metrics.get("beats_baseline"):
        print(
            "\nNOTE: the regressor did not beat a predict-the-mean baseline on the "
            "held-out split. With ~300 user-days and 72 features this is expected; "
            "treat the forecast as indicative, not authoritative."
        )


if __name__ == "__main__":
    main()

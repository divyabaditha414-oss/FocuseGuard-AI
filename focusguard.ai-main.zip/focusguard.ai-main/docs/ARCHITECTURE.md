# FocusGuard AI — Architecture

## Project layout

```
FocusGuard/
├── backend/
│   ├── app/
│   │   ├── core/            settings, DB session, JWT/bcrypt, app catalogue
│   │   ├── analytics/       Weeks 3-4 engine (see below)
│   │   ├── coaching/        Weeks 5-6 recommendation platform
│   │   ├── routers/         one module per endpoint group
│   │   ├── models.py        14 ORM tables
│   │   ├── schemas.py       Pydantic request/response contracts
│   │   └── main.py          app entrypoint, CORS, router registration
│   ├── ml/
│   │   ├── train.py         trains + persists the predictive models
│   │   └── artifacts/       *.joblib (generated, gitignored)
│   ├── scripts/             mock data generation, loading, smoke test
│   └── api.http             REST Client requests for every endpoint
├── frontend/
│   ├── pages/               login, register, dashboard
│   └── assets/
│       ├── css/theme.css    shared light/dark theme
│       └── js/api.js        shared API client + token store
├── data/                    the generated 2500-row CSV
├── docs/                    this file
└── docker-compose.yml       Postgres 16 (:5433) + pgAdmin (:5050)
```

## Request flow

```
Tracker / browser
      │
      ▼
POST /activity/logs ──► activity_logs ─┐
POST /notifications ──► notification_events ─┤
POST /sessions/start ─► focus_sessions ──────┤
                                             ▼
                              analytics/features.py
                          (the only SQL layer in the engine)
                                             │
                                   DailyFeatures[]
                    ┌────────────────┬───────┴────────┬──────────────┐
                    ▼                ▼                ▼              ▼
              scoring.py      distraction.py    predictive.py   insights.py
              focus /         interruptions,    Ridge +         attention
              productivity /  context switch,   LogisticReg     leaks, daily
              stability       notif. impact,    (+ heuristic    summary
              + trend         focus loss        fallback)
                    └────────────────┴───────┬────────┴──────────────┘
                                             ▼
                                    /analytics/* routes
                                             │
                            ┌────────────────┴────────────────┐
                            ▼                                 ▼
                   computed on demand              POST /analytics/compute
                   (dashboard, insights)           persists to daily_scores,
                                                   insights, predictions
```

The layering matters: only `features.py` issues queries. Everything downstream
takes plain dataclasses, so scoring and insight logic can be tested without a
database, and a schema change touches one file rather than five.

## Database schema (11 tables)

**Weeks 1-2 — collection**

| Table                 | Purpose                                            |
| --------------------- | -------------------------------------------------- |
| `users`               | Accounts, `user_type`, role, credentials           |
| `user_profiles`       | Occupation, timezone, work window                  |
| `goals`               | Focus/productivity targets                         |
| `applications`        | App catalogue + default productivity label         |
| `activity_logs`       | **Core table** — one app/website visit per row     |
| `focus_sessions`      | Work blocks, interruptions, switches               |
| `notification_events` | Interruptions, linked to a session when applicable |
| `device_usage_stats`  | Daily per-device rollup                            |

**Weeks 3-4 — analysis**

| Table           | Purpose                                              |
| --------------- | ---------------------------------------------------- |
| `daily_scores`  | Per user-day scores + component breakdown            |
| `insights`      | Generated findings with the evidence behind each     |
| `predictions`   | Forecasts, tagged with the model version that made them |

**Weeks 5-6 — coaching**

| Table             | Purpose                                                  |
| ----------------- | -------------------------------------------------------- |
| `recommendations` | Suggestions + evidence + user status (accepted/dismissed) |
| `goal_progress`   | One row per goal per day — the substrate for streaks      |
| `alerts`          | Reminders, session nudges, distraction warnings           |

Scores are persisted rather than always recomputed because trend and prediction
endpoints read weeks of history at once; recomputing the full feature set per
request would make those queries quadratic in the window size.

## Scoring model

All three scores are transparent weighted composites in 0-100, and every
response carries its component breakdown so the UI can explain a number rather
than just display it.

**Focus score** — how well attention was *sustained*.

| Component           | Weight | Meaning                                    |
| ------------------- | ------ | ------------------------------------------ |
| `productive_share`  | 0.35   | share of the day on productive apps        |
| `focus_depth`       | 0.25   | longest unbroken block vs a 90-minute ideal |
| `switch_discipline` | 0.22   | tab switches/hour, inverted                |
| `context_stability` | 0.18   | productive↔distraction flips/hour, inverted |

Fragmentation is weighted nearly as heavily as productive share on purpose:
eight hours of work apps consumed in 90-second slices is not a focused day, and
a score that ignored switching would call it one.

**Productivity score** — output against the user's own goal (`focus_minutes`,
falling back to 240 min/day): target attainment 0.40, productive share 0.25,
deep-work blocks 0.20, session completion 0.15.

**Attention stability score** — consistency independent of output: duration
consistency 0.30, interruption resistance 0.28, context stability 0.24, settle
depth 0.18. A user can be productive *and* unstable; the remedy differs, so the
scores are kept separate.

## Predictive models

| Model               | Type                | Target                                      |
| ------------------- | ------------------- | ------------------------------------------- |
| `focus_degradation` | Ridge regression    | next day's focus score (0-100)               |
| `productivity_risk` | Logistic regression | next day's productive ratio below 0.60?      |
| `attention_fatigue` | computed, not learned | within-day decay of productive share       |

Both learned models consume the last 3 days of features flattened into one row
(3 × 24 = 72 features). The train/test split is **chronological**, not random:
a random split would let the model see day 30 while predicting day 12 for the
same user, leaking future information and producing metrics that would not
survive deployment.

Fatigue is deliberately not learned — it describes the day just lived, and
there is no future label to train against.

### Honest limitations

- **~270 training rows against 72 features.** This is a small-data regime.
  Ridge and Logistic Regression with heavy regularisation were chosen over
  gradient boosting for that reason; the reported metrics are indicative, not
  authoritative.
- **The data is synthetic.** The generator gives each user an AR(1) energy
  process, a weekday rhythm, a slow personal trend, and fatigue carried over
  from late-night use. That produces genuine day-to-day autocorrelation for the
  models to learn — but it is autocorrelation *we designed*, so good metrics
  here demonstrate the pipeline works, not that the model would generalise to
  real humans.
- **`productivity_risk` uses `class_weight="balanced"`.** At an ~19% positive
  rate, a never-warn classifier scores ~81% accuracy and is useless. The model
  trades accuracy for recall so it actually raises warnings; judge it on
  ROC-AUC and recall, not accuracy.
- **When no artifact is present**, the API falls back to a transparent
  heuristic and reports `model_version: "heuristic"`. A fallback is never
  presented as model output.

## Weeks 5-6 — coaching layer

`app/coaching/` consumes the analytics output and turns it into actions.

| Module              | Responsibility                                             |
| ------------------- | ---------------------------------------------------------- |
| `planner.py`        | High-focus hours, session length, breaks, daily plan, task priorities |
| `recommendations.py`| Ranked, evidence-backed suggestions                        |
| `habits.py`         | Goal progress, streaks, habit-formation stage              |
| `alerts.py`         | Smart reminders, session nudges, distraction warnings      |
| `reports.py`        | Weekly focus report, improvement trends, goal achievement  |

### Recommendations are ranked, not listed

`priority = expected_gain_minutes × confidence`. A large but uncertain win does
not automatically outrank a small certain one.

Every estimated gain is a **plausible ceiling**, not a promise, and each
rationale names the assumption it rests on. Attention-leak gains assume the
user reclaims 60% of the time — the rest is a legitimate break, and claiming
all of it would be dishonest. Context-switch gains price each avoided switch at
3 minutes of reload.

A recommendation that cannot cite a measured signal from this user's own
history is not generated. Generic productivity advice needs no data and helps
no one.

Dismissal is stored against a stable `key` (e.g. `leak:Instagram`), so
dismissed advice stops being surfaced. A feed that keeps re-suggesting rejected
advice loses credibility fast.

### The planner learns the user's rhythm, not a textbook one

Session length is chosen by **expected completed minutes**, not completion
rate: ranking on completion rate alone would always favour trivially short
sessions. A 90-minute block finished half the time beats a 25-minute block
finished always.

High-focus hours require a minimum observed sample before they can be ranked —
one 4-minute visit at 06:00 should not crown it the peak hour.

### Habit stage is gated on consistency

`inconsistent → forming → establishing → established`, but consistency below
70% pins the stage at `inconsistent` regardless of elapsed days. Thirty days at
30% adherence is not a habit taking hold; it is thirty days of not doing the
thing.

`suggest_goal_adjustments` flags goals that are set wrong in either direction —
never hit (demoralising) or always exceeded (no longer stretching).

### Alerts are capped

The platform's whole premise is that notifications fragment attention, so the
alert generator holds itself to a higher bar than the apps it critiques:
**5 per day maximum**, ranked severity-first. An attention tool that spams
notifications is self-defeating.

## Notification impact is an association, not a cause

Focus sessions are not randomly assigned to be interrupted, so the gap between
interrupted and uninterrupted sessions is observational. The insight wording
says so explicitly rather than claiming causation the data cannot support.

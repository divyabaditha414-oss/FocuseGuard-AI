# FocusGuard AI

Human Attention Preservation & Digital Distraction Intelligence Platform.

**Status: Weeks 1–6 complete.**

- **Weeks 1–2** — User Activity Monitoring & Data Collection System
- **Weeks 3–4** — AI-Based Attention Analysis & Distraction Detection Engine
- **Weeks 5–6** — Personalized Focus Improvement & Recommendation Platform

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the layering, scoring
formulas and model limitations.

---

## Quick start

In VS Code: press **`Ctrl+Shift+B`**. That runs the whole chain — Docker →
generate data → load Postgres → train models → start API → serve frontend →
smoke test. Press **`F5`** to debug any single piece.

From a terminal:

```powershell
cd C:\Users\palem\FocusGuard
docker compose up -d --wait                                  # Postgres + pgAdmin
.\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
.\.venv\Scripts\python.exe backend\scripts\generate_mock_data.py
.\.venv\Scripts\python.exe backend\scripts\load_mock_data.py
.\.venv\Scripts\python.exe backend\ml\train.py

cd backend;  ..\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
cd frontend; ..\.venv\Scripts\python.exe -m http.server 5500  # second terminal
```

| Service       | URL                                       | Credentials                          |
| ------------- | ----------------------------------------- | ------------------------------------ |
| Login         | http://localhost:5500/pages/login.html    | `user1` … `user10` / `FocusGuard@123` |
| Attention dashboard | http://localhost:5500/pages/dashboard.html | scores, leaks, predictions, insights |
| Focus coach   | http://localhost:5500/pages/coach.html    | plan, recommendations, goals, report  |
| API docs      | http://127.0.0.1:8000/docs                | —                                    |
| PostgreSQL    | `localhost:5433`                          | `focusguard` / `focusguard`          |
| pgAdmin       | http://localhost:5050                     | `admin@focusguard.com` / `admin`     |

`user1` has the `admin` role. Host port **5433** avoids colliding with any
locally installed PostgreSQL.

---

## Project layout

```
backend/    app/core (config, db, auth)  ·  app/analytics (Weeks 3-4 engine)
            app/routers  ·  ml/train.py  ·  scripts/  ·  api.http
frontend/   pages/ (login, register, dashboard)  ·  assets/{css,js}
data/       mock_activity_2500.csv
docs/       ARCHITECTURE.md
```

---

## Modules delivered

### Weeks 1–2
User registration/login/profile/goals · application usage, screen time, session
duration, task switching and notification tracking · activity log management,
focus session recording, device statistics, historical storage · FastAPI +
PostgreSQL + JWT.

### Weeks 3–4
**Behavioural analytics** — attention pattern, focus session, productivity
trend and distraction frequency analysis.
**Distraction detection** — frequent interruptions, context switching,
notification impact, focus loss.
**Focus scoring** — daily focus, productivity and attention-stability scores
plus concentration trend.
**Predictive analytics** — focus degradation, productivity risk, attention
fatigue.
**Insight generation** — attention leaks, personalised insights, daily summary.

### Weeks 5–6
**Recommendation engine** — focus improvement, productivity tips, attention
recovery, work pattern optimisation. Ranked by expected daily minutes recovered
× confidence; dismissed advice stops being suggested.
**Smart focus planner** — optimal session length (learned from what this user
actually finishes), break scheduling, high-focus hour identification, task
prioritisation.
**Goal management** — progress tracking, streaks, habit-formation stage, and
flagging of goals set too hard or too easy.
**Notification intelligence** — smart reminders, focus session alerts,
distraction alerts. Capped at 5/day.
**Analytics dashboard** — weekly focus reports, improvement trends,
productivity analytics, goal achievement tracking.

---

## API

Weeks 1–2 live under `/auth`, `/users`, `/goals`, `/activity`, `/sessions`,
`/notifications`, `/stats`.

Weeks 3–4:

| Method | Path                          | Description                              |
| ------ | ----------------------------- | ---------------------------------------- |
| GET    | `/analytics/features`         | Raw per-day feature vectors               |
| GET    | `/analytics/scores`           | Daily focus / productivity / stability    |
| GET    | `/analytics/trend`            | Concentration trend                       |
| GET    | `/analytics/distraction`      | All four detectors                        |
| GET    | `/analytics/attention-leaks`  | Ranked attention leaks                    |
| GET    | `/analytics/predictions`      | Degradation, risk, fatigue                |
| GET    | `/analytics/insights`         | Personalised findings, most severe first  |
| GET    | `/analytics/dashboard`        | Everything in one round trip              |
| POST   | `/analytics/compute`          | Persist scores/insights/predictions       |
| GET    | `/analytics/stored/scores`    | Read back persisted scores                |

Weeks 5–6:

| Method | Path                             | Description                            |
| ------ | -------------------------------- | -------------------------------------- |
| GET    | `/coaching/recommendations`      | Ranked, evidence-backed suggestions    |
| PATCH  | `/coaching/recommendations/{key}`| Accept / dismiss / complete            |
| GET    | `/coaching/plan`                 | Tomorrow's blocks, breaks, priorities  |
| GET    | `/coaching/high-focus-hours`     | Measurably strongest clock hours       |
| GET    | `/coaching/goals`                | Progress, streaks, habit stage         |
| GET    | `/coaching/goals/adjustments`    | Goals set too hard or too easy         |
| GET    | `/coaching/alerts`               | Reminders / nudges / warnings (≤5/day) |
| GET    | `/coaching/reports/weekly`       | This week vs last week                 |
| GET    | `/coaching/reports/trends`       | Attention improvement trends           |
| GET    | `/coaching/dashboard`            | Everything in one round trip           |
| POST   | `/coaching/compute`              | Persist recommendations/progress/alerts |

Open [backend/api.http](backend/api.http) in VS Code and click "Send Request"
on any of them (REST Client extension).

---

## Mock dataset

`data/mock_activity_2500.csv` — exactly 2500 rows, 10 users, 30 days,
~1300 tracked hours, with the spec's columns:

```
User | UserType | App/Website Name | URL | OpenedDateTime | ClosedTime |
Duration (Closed-Opened) | Productive/NonProductive | TabSwitchCount
```

Two properties make it usable rather than merely plausible:

1. **Visits never overlap**, so screen-time and switch aggregates actually sum.
2. **Days are correlated.** Each user carries an AR(1) "energy" level, a weekday
   rhythm, a slow personal trend, and fatigue carried over from late-night use.
   They also have habitual apps rather than sampling uniformly across 65.
   Without that structure there is nothing for a next-day predictor to learn,
   and no single app ever clears the attention-leak threshold.

`load_mock_data.py` is re-runnable — it clears prior seeded rows first, so it
never double-counts.

---

## Verification

```powershell
.\.venv\Scripts\python.exe backend\scripts\smoke_test.py   # server must be running
```

96 checks across all six weeks, covering happy paths and the rejections that
matter: duplicate registration, bad passwords, unauthenticated access,
`closed_at` before `opened_at`, overlapping sessions, double-end, invalid work
windows.

Weeks 3–4 assert scores stay in 0–100, feature totals reconcile, focus-loss
counts partition cleanly, leaks come back ranked, and `/analytics/compute` is
idempotent.

Weeks 5–6 assert plan blocks are contiguous with alternating focus/break,
`total_focus_minutes` matches the blocks, recommendations are ranked and every
one carries evidence with `priority == gain × confidence`, streaks never exceed
their bounds, consistency matches `days_met/days_tracked`, alerts stay under the
daily cap, and **dismissing a recommendation actually suppresses it**.

Both weeks assert an account with no history degrades gracefully rather than
crashing or dividing by zero.

---

## Notes

- Model metrics and their limitations are documented honestly in
  [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md#honest-limitations) — small
  sample, synthetic data, and an explicit accuracy-vs-recall trade-off.
- Predictions report `model_version`; `"heuristic"` means no trained artifact
  was loaded and a fallback produced the number.
- `.env` holds development defaults only. Copy `.env.example` and set a real
  `SECRET_KEY` before deploying.
- Tables are created via `Base.metadata.create_all`. Introduce Alembic
  migrations before production.
- **Ollama** is installed for future LLM-generated coaching; the current
  insight engine is deterministic and needs no model. Pull one with
  `ollama pull llama3.2` when that work starts.
